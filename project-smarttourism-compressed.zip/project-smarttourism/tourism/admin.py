from django.contrib import admin
from .models import Customer, Package, Booking, Hotel, Payment, Contact
from .models import ContactMessage
 
 
# ==========================
# Customer Admin
# ==========================
@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "full_name",
        "email",
        "phone",
        "city",
        "country",
        "created_at",
    )

    search_fields = (
        "full_name",
        "email",
        "phone",
    )

    list_filter = (
        "country",
        "city",
    )

    ordering = ("-created_at",)


# ==========================
# Package Admin
# ==========================
@admin.register(Package)
class PackageAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "package_name",
        "destination",
        "duration",
        "price",
    )

    search_fields = (
        "package_name",
        "destination",
    )

    ordering = ("package_name",)


# ==========================
# Booking Admin
# ==========================
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "customer",
        "package",
        "travel_date",
        "persons",
        "total_amount",
        "status",
        "booked_at",
    )

    list_filter = (
        "status",
        "travel_date",
    )

    search_fields = (
        "customer__full_name",
        "package__package_name",
    )

    ordering = ("-booked_at",)


# ==========================
# Hotel Admin
# ==========================
@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "code",
        "hotel_name",
        "location",
        "rating",
        "price_per_night",
    )

    search_fields = (
        "hotel_name",
        "location",
        "code",
    )

    list_filter = (
        "location",
    )


# ==========================
# Payment Admin
# ==========================
@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "booking",
        "amount",
        "payment_method",
        "payment_date",
        "status",
    )

    list_filter = (
        "status",
        "payment_method",
    )

    search_fields = (
        "booking__customer__full_name",
    )

    ordering = ("-payment_date",)


# ==========================
# Contact Admin
# ==========================
@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "name",
        "email",
        "phone",
        "subject",
        "created_at",
    )

    search_fields = (
        "name",
        "email",
        "subject",
    )

    ordering = ("-created_at",)


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ("ref_id", "name", "email", "subject", "created_at", "is_resolved")
    list_filter = ("is_resolved", "created_at")
    search_fields = ("name", "email", "ref_id", "message")
    readonly_fields = ("ref_id", "created_at")
    ordering = ("-created_at",)
 