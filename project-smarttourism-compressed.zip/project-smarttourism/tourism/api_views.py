from django.contrib.auth import authenticate, login
from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response

from django.contrib.auth.models import User
from .models import *
from .serializers import CustomerSerializer, PackageSerializer, BookingSerializer, HotelSerializer, PaymentSerializer


# -------------------------
# Customer API
# -------------------------
class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer


# -------------------------
# Package API
# -------------------------
class PackageViewSet(viewsets.ModelViewSet):
    queryset = Package.objects.all()
    serializer_class = PackageSerializer


# -------------------------
# Booking API
# -------------------------
class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer


# -------------------------
# Hotel API
# -------------------------
class HotelViewSet(viewsets.ModelViewSet):
    queryset = Hotel.objects.all()
    serializer_class = HotelSerializer


# -------------------------
# Payment API
# -------------------------
class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer


# -------------------------
# Login API
# -------------------------
@api_view(["POST"])
def login_api(request):

    username = request.data.get("username")
    password = request.data.get("password")

    user = authenticate(username=username, password=password)

    if user is not None:
        login(request, user)

        return Response({
            "success": True,
            "username": user.username
        })

    return Response({
        "success": False,
        "message": "Invalid username or password"
    })

@api_view(["POST"])
def signup_api(request):

    username = request.data.get("username")
    email = request.data.get("email")
    password = request.data.get("password")

    first_name = request.data.get("first_name")
    last_name = request.data.get("last_name")

    if User.objects.filter(username=username).exists():
        return Response({
            "success": False,
            "message": "Username already exists"
        })

    if User.objects.filter(email=email).exists():
        return Response({
            "success": False,
            "message": "Email already exists"
        })

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
    )

    return Response({
        "success": True,
        "message": "Account created successfully"
    })

@api_view(["POST"])
def admin_login(request):

    username = request.data.get("username")
    password = request.data.get("password")

    user = authenticate(username=username, password=password)

    if user is not None and user.is_staff:

        login(request, user)

        return Response({
            "success": True
        })

    return Response({
        "success": False,
        "message": "Invalid Admin Credentials"
    })