from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from datetime import date

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework import status

from django.db.models import Sum, Count
from django.utils import timezone
from django.utils.timesince import timesince

from .models import (
    Customer,
    Package,
    Booking,
    Hotel,
    Payment,
    Contact,
    ContactMessage,
)
from .serializers import PackageSerializer, BookingSerializer, ContactMessageSerializer


# ==========================
# HOME PAGE
# ==========================

def home(request):
    return render(request, "home.html")


# ==========================
# USER SIGNUP (template)
# ==========================

def signup_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        if not User.objects.filter(username=username).exists():

            User.objects.create_user(
                username=username,
                email=email,
                password=password
            )

            return redirect('/login/')

    return render(request, "signup.html")


# ==========================
# USER LOGIN (template)
# ==========================

def login_view(request):

    if request.user.is_authenticated:
        logout(request)

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('/dashboard/')

        return render(request, "login.html", {"error": "Invalid Username or Password"})

    return render(request, "login.html")


# ==========================
# LOGOUT (template)
# ==========================

def logout_view(request):
    logout(request)
    return redirect('/login/')


# ==========================
# DASHBOARD
# ==========================

@login_required(login_url='/login/')
def dashboard(request):

    total_revenue = sum(
        booking.total_amount
        for booking in Booking.objects.all()
    )

    context = {
        "customer_count": Customer.objects.count(),
        "package_count": Package.objects.count(),
        "booking_count": Booking.objects.count(),
        "hotel_count": Hotel.objects.count(),
        "payment_count": Payment.objects.count(),
        "total_revenue": total_revenue,
        "customers": Customer.objects.all()[:5],
        "packages": Package.objects.all()[:5],
        "bookings": Booking.objects.all()[:5],
    }

    return render(request, "dashboard.html", context)


# ==========================
# CUSTOMERS
# ==========================

@login_required(login_url='/login/')
def customers(request):
    customers = Customer.objects.all()
    return render(request, "customers.html", {"customers": customers})


# ==========================
# PACKAGES
# ==========================

@login_required(login_url='/login/')
def packages(request):

    search = request.GET.get("search")
    packages = Package.objects.all()

    if search:
        packages = packages.filter(package_name__icontains=search)

    return render(request, "packages.html", {"packages": packages, "search": search})


# ==========================
# BOOKINGS
# ==========================

@login_required(login_url='/login/')
def bookings(request):
    bookings = Booking.objects.all()
    return render(request, "bookings.html", {"bookings": bookings})


# ==========================
# HOTELS
# ==========================

@login_required(login_url='/login/')
def hotels(request):
    hotels = Hotel.objects.all()
    return render(request, "hotels.html", {"hotels": hotels})


# ==========================
# PAYMENTS
# ==========================

@login_required(login_url='/login/')
def payments(request):

    booking_id = request.session.get("booking_id")

    if not booking_id:
        return render(request, "payments.html", {"booking": None})

    booking = get_object_or_404(Booking, id=booking_id)

    return render(request, "payments.html", {"booking": booking})


# ==========================
# PACKAGE BOOKING (template)
# ==========================

def register_booking(request, package_id):

    package = get_object_or_404(Package, id=package_id)

    if request.method == "POST":

        email = request.POST.get("email")

        customer, created = Customer.objects.get_or_create(
            email=email,
            defaults={
                "full_name": request.POST.get("full_name"),
                "phone": request.POST.get("phone"),
                "city": request.POST.get("city"),
                "country": request.POST.get("country")
            }
        )

        if not created:
            customer.full_name = request.POST.get("full_name")
            customer.phone = request.POST.get("phone")
            customer.city = request.POST.get("city")
            customer.country = request.POST.get("country")
            customer.save()

        persons = int(request.POST.get("persons"))

        booking = Booking.objects.create(
            customer=customer,
            package=package,
            travel_date=request.POST.get("travel_date"),
            persons=persons,
            total_amount=package.price * persons,
            status="Pending"
        )

        request.session["booking_id"] = booking.id
        request.session.modified = True

        return redirect("/payments/")

    return render(request, "register_booking.html", {"package": package})


# ==========================
# CONTACT PAGE (template)
# ==========================

def contact(request):

    if request.method == "POST":

        Contact.objects.create(
            name=request.POST.get("name"),
            email=request.POST.get("email"),
            phone=request.POST.get("phone"),
            subject=request.POST.get("subject"),
            message=request.POST.get("message")
        )

        return redirect('/contact_success/')

    return render(request, "contact.html")


def contact_success(request):
    return render(request, "contact_success.html")


def payment_page(request):

    booking_id = request.session.get("booking_id")

    if not booking_id:
        return redirect("/packages/")

    booking = get_object_or_404(Booking, id=booking_id)

    if request.method == "POST":

        Payment.objects.create(
            booking=booking,
            amount=booking.total_amount,
            payment_method=request.POST.get("payment_method"),
            payment_date=date.today(),
            status="Completed"
        )

        booking.status = "Confirmed"
        booking.save()

        request.session.pop("booking_id", None)

        return redirect("/payment_success/")

    return render(request, "payments.html", {"booking": booking})


def payment_success(request):
    return render(request, "payment_success.html")


@login_required(login_url='/login/')
def my_bookings(request):
    bookings = Booking.objects.all().order_by("-id")
    return render(request, "my_bookings.html", {"bookings": bookings})


def about(request):
    return render(request, "about.html")


def services(request):
    return render(request, "services.html")


def gallery(request):
    return render(request, "gallery.html")


def success(request):
    return render(request, 'success.html')


def privacy(request):
    return render(request, 'privacy.html')


def terms(request):
    return render(request, 'terms.html')


def cookies(request):
    return render(request, 'cookies.html')


def react_test(request):
    return JsonResponse({"message": "React Connected Successfully!"})


# ==========================================================
# ================  REACT JSON API VIEWS  ===================
# ==========================================================

# ---- CSRF cookie: React calls this once on app load ----
@ensure_csrf_cookie
@api_view(["GET"])
@permission_classes([AllowAny])
def csrf_api(request):
    return Response({"detail": "CSRF cookie set"})


# ---- Session check: is someone currently logged in? ----
@api_view(["GET"])
@permission_classes([AllowAny])
def me_api(request):
    if request.user.is_authenticated:
        return Response({
            "is_authenticated": True,
            "username": request.user.username,
            "email": request.user.email,
        })
    return Response({"is_authenticated": False})


# ---- Login (JSON) ----
@api_view(["POST"])
@permission_classes([AllowAny])
def login_api(request):
    username = request.data.get("username")
    password = request.data.get("password")

    user = authenticate(request, username=username, password=password)

    if user:
        login(request, user)
        return Response({"success": True, "username": user.username})

    return Response({"success": False, "message": "Invalid username or password"})


# ---- Logout (JSON) ----
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def logout_api(request):
    logout(request)
    return Response({"success": True})


# ---- Signup (JSON) ----
@api_view(["POST"])
@permission_classes([AllowAny])
def signup_api(request):
    username = request.data.get("username")
    email = request.data.get("email")
    password = request.data.get("password")
    first_name = request.data.get("first_name", "")
    last_name = request.data.get("last_name", "")
    phone = request.data.get("phone", "")
    country = request.data.get("country", "")
    role = request.data.get("role", "")

    if not username or not password:
        return Response({"success": False, "message": "Username and password are required."}, status=400)

    if User.objects.filter(username=username).exists():
        return Response({"success": False, "message": "Username already taken."}, status=400)

    if email and User.objects.filter(email=email).exists():
        return Response({"success": False, "message": "Email already registered."}, status=400)

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
    )

    full_name = f"{first_name} {last_name}".strip() or username

    Customer.objects.create(
        user=user,
        full_name=full_name,
        username=username,
        email=email,
        phone=phone,
        country=country,
        role=role,
    )

    login(request, user)

    return Response({"success": True, "username": user.username})


# ---- Contact (JSON, legacy — saves to Contact model) ----
@api_view(["POST"])
@permission_classes([AllowAny])
def contact_api(request):
    Contact.objects.create(
        name=request.data.get("name"),
        email=request.data.get("email"),
        phone=request.data.get("phone"),
        subject=request.data.get("subject"),
        message=request.data.get("message"),
    )
    return Response({"success": True})


# ---- Packages list: feeds the booking form dropdown ----
@api_view(["GET"])
@permission_classes([AllowAny])
def packages_api(request):
    serializer = PackageSerializer(Package.objects.all(), many=True)
    return Response(serializer.data)


# ---- Package booking (JSON) — public, matches the old template flow ----
@api_view(["POST"])
@permission_classes([AllowAny])
def register_booking_api(request):
    package = get_object_or_404(Package, id=request.data.get("package_id"))

    # Anonymous-friendly: if the visitor happens to be logged in, prefer
    # their account email; otherwise fall back to whatever email they typed
    # in the booking form (same behaviour as the old register_booking view).
    if request.user.is_authenticated and request.user.email:
        email = request.user.email
    else:
        email = request.data.get("email")

    if not email:
        return Response(
            {"success": False, "message": "Email is required to book a package."},
            status=400,
        )

    default_full_name = request.data.get("full_name") or (
        request.user.username if request.user.is_authenticated else email
    )
    default_username = (
        request.user.username if request.user.is_authenticated else email
    )

    customer, created = Customer.objects.get_or_create(
        email=email,
        defaults={
            "full_name": default_full_name,
            "username": default_username,
            "phone": request.data.get("phone", ""),
            "city": request.data.get("city", ""),
            "country": request.data.get("country", ""),
        },
    )

    if not created:
        customer.full_name = request.data.get("full_name", customer.full_name)
        customer.phone = request.data.get("phone", customer.phone)
        customer.city = request.data.get("city", customer.city)
        customer.country = request.data.get("country", customer.country)
        customer.save()

    persons = int(request.data.get("persons", 1))

    try:
        booking = Booking.objects.create(
            customer=customer,
            package=package,
            travel_date=request.data.get("travel_date"),
            persons=persons,
            total_amount=package.price * persons,
            status="Pending",
        )
    except Exception as e:
        return Response({"success": False, "message": str(e)}, status=400)

    request.session["booking_id"] = booking.id
    request.session.modified = True

    return Response({"success": True, "booking": BookingSerializer(booking).data})


# ---- Contact (JSON, new — saves to ContactMessage, used by ContactFormSection.jsx) ----
@api_view(["POST"])
@permission_classes([AllowAny])
def submit_contact_message(request):
    """
    POST /api/contact/
    Body: { name, email, phone, subject, message }
    Saves the message and returns the ref_id + created_at so the
    frontend can show them on the Contact_Success page.
    """
    serializer = ContactMessageSerializer(data=request.data)

    if serializer.is_valid():
        instance = serializer.save()
        return Response(
            {
                "success": True,
                "ref_id": instance.ref_id,
                "created_at": instance.created_at,
            },
            status=status.HTTP_201_CREATED,
        )

    # Flatten DRF's field-error dict into one readable message
    first_field, first_errors = next(iter(serializer.errors.items()))
    readable_message = f"{first_field}: {first_errors[0]}"
    return Response(
        {"message": readable_message, "errors": serializer.errors},
        status=status.HTTP_400_BAD_REQUEST,
    )

# ==========================================================
# ============  LIVE DASHBOARD JSON ENDPOINTS  =============
# ==========================================================

@api_view(["GET"])
@permission_classes([AllowAny])
def dashboard_stats_api(request):
    total_revenue = Booking.objects.aggregate(total=Sum("total_amount"))["total"] or 0
    today = timezone.localdate()
    todays_bookings = Booking.objects.filter(booked_at__date=today)
    revenue_today = todays_bookings.aggregate(total=Sum("total_amount"))["total"] or 0

    return Response({
        "customer_count": Customer.objects.count(),
        "package_count": Package.objects.count(),
        "booking_count": Booking.objects.count(),
        "hotel_count": Hotel.objects.count(),
        "total_revenue": f"{total_revenue:,.0f}",
        "revenue_today": f"{revenue_today:,.0f}",
        "bookings_today": todays_bookings.count(),
        "travelers_online": Customer.objects.count(),  # no live presence tracking yet — placeholder
    })


@api_view(["GET"])
@permission_classes([AllowAny])
def revenue_split_api(request):
    total = Booking.objects.aggregate(total=Sum("total_amount"))["total"] or 0
    if not total:
        return Response([])

    rows = (
        Booking.objects
        .values("package__destination")
        .annotate(amount=Sum("total_amount"))
        .order_by("-amount")
    )

    colors = [
        ("#1b4b43", "#4caf93"),
        ("#d97706", "#f7c98f"),
        ("#059669", "#34d399"),
        ("#7c3aed", "#a78bfa"),
        ("#0369a1", "#38bdf8"),
    ]

    data = []
    for i, row in enumerate(rows):
        pct = round((row["amount"] / total) * 100)
        start, end = colors[i % len(colors)]
        data.append({
            "id": i,
            "destination": row["package__destination"] or "Other",
            "pct": pct,
            "color_start": start,
            "color_end": end,
        })
    return Response(data)


@api_view(["GET"])
@permission_classes([AllowAny])
def top_packages_api(request):
    packages = (
        Package.objects
        .annotate(booked=Count("bookings"))
        .order_by("-booked")[:4]
    )
    data = [
        {
            "id": p.id,
            "rank": i + 1,
            "name": p.package_name,
            "sub": f"{p.duration} · {p.booked} booked",
            "price": f"₹{p.price:,.0f}",
            "image": f"https://picsum.photos/seed/pkg-{p.id}/120/120",
        }
        for i, p in enumerate(packages)
    ]
    return Response(data)


@api_view(["GET"])
@permission_classes([AllowAny])
def recent_activity_api(request):
    items = []

    for b in Booking.objects.select_related("package", "customer").order_by("-booked_at")[:5]:
        items.append({
            "type": "booking",
            "text": f"New booking for {b.package.package_name} — {b.customer.full_name}",
            "created_at": b.booked_at,
        })

    for p in Payment.objects.select_related("booking__package").order_by("-payment_date")[:5]:
        items.append({
            "type": "payment",
            "text": f"Payment received ₹{p.amount:,.0f} for {p.booking.package.package_name}",
            "created_at": p.payment_date,
        })

    for c in Customer.objects.order_by("-created_at")[:5]:
        items.append({
            "type": "customer",
            "text": f"New customer registered: {c.full_name}",
            "created_at": c.created_at,
        })

    items.sort(key=lambda x: x["created_at"], reverse=True)
    items = items[:8]

    for item in items:
        item["time_ago"] = f"{timesince(item['created_at'])} ago"
        del item["created_at"]

    return Response(items)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def latest_invoice_api(request):
    """
    GET /api/invoice/latest/
    Returns the logged-in user's most recent booking + its payment,
    shaped exactly like the { booking, payment } state Invoice.jsx expects.
    """
    customer = getattr(request.user, "customer_profile", None)
    if not customer:
        return Response({"detail": "No customer profile found for this account."}, status=404)

    booking = (
        Booking.objects
        .filter(customer=customer)
        .select_related("package", "customer")
        .order_by("-booked_at")
        .first()
    )

    if not booking:
        return Response({"detail": "No bookings found."}, status=404)

    payment = booking.payments.order_by("-payment_date").first()

    data = {
        "booking": {
            "id": booking.id,
            "customer": {
                "full_name": booking.customer.full_name,
                "email": booking.customer.email,
                "phone": booking.customer.phone,
                "city": booking.customer.city,
                "country": booking.customer.country,
            },
            "package": {
                "package_name": booking.package.package_name,
                "destination": booking.package.destination,
                "duration": booking.package.duration,
                "price": str(booking.package.price),
                "description": booking.package.description,
            },
            "travel_date": str(booking.travel_date),
            "persons": booking.persons,
            "status": booking.status,
            "total_amount": str(booking.total_amount),
        },
        "payment": None,
    }

    if payment:
        data["payment"] = {
            "amount": str(payment.amount),
            "payment_method": payment.payment_method,
            "payment_date": payment.payment_date.strftime("%Y-%m-%d"),
            "status": payment.status,
        }

    return Response(data)