"""
Management command: seed_bookings.py

Creates random bookings by pairing existing Customers with existing
Packages. Booking.total_amount is auto-calculated by the model's save()
method (persons * package.price), and travel_date must be in the future
(the model's clean() enforces this), so this script picks random future
dates automatically.

WHERE TO PUT THIS FILE:
  tourism/management/commands/seed_bookings.py

REQUIRES (run these first if you haven't):
  python manage.py seed_data        -> creates 33 Packages + 33 Hotels
  (your existing customer seed)      -> creates the 100 Customers

RUN:
  python manage.py seed_bookings                # creates 40 bookings (default)
  python manage.py seed_bookings --count 100     # or specify how many
"""

import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from tourism.models import Customer, Package, Booking


STATUS_WEIGHTS = [
    ("Confirmed", 55),
    ("Pending", 25),
    ("Completed", 15),
    ("Cancelled", 5),
]


class Command(BaseCommand):
    help = "Seed random Booking records using existing Customers and Packages"

    def add_arguments(self, parser):
        parser.add_argument(
            "--count",
            type=int,
            default=40,
            help="Number of bookings to create (default: 40)",
        )

    def handle(self, *args, **options):
        count = options["count"]

        customers = list(Customer.objects.all())
        packages = list(Package.objects.all())

        if not customers:
            self.stderr.write(self.style.ERROR(
                "No customers found. Seed customers first."
            ))
            return

        if not packages:
            self.stderr.write(self.style.ERROR(
                "No packages found. Run `python manage.py seed_data` first."
            ))
            return

        statuses, weights = zip(*STATUS_WEIGHTS)

        created = 0
        skipped = 0

        for _ in range(count):
            customer = random.choice(customers)
            package = random.choice(packages)
            persons = random.randint(1, 4)
            status = random.choices(statuses, weights=weights, k=1)[0]

            # Random future travel date, 5 to 200 days from now
            travel_date = timezone.localdate() + timedelta(days=random.randint(5, 200))

            booking = Booking(
                customer=customer,
                package=package,
                travel_date=travel_date,
                persons=persons,
                status=status,
            )
            try:
                booking.save()  # save() runs full_clean() + auto-calculates total_amount
                created += 1
            except Exception as e:
                skipped += 1
                self.stderr.write(self.style.WARNING(f"Skipped one booking: {e}"))

        self.stdout.write(self.style.SUCCESS(
            f"Bookings: {created} created, {skipped} skipped."
        ))