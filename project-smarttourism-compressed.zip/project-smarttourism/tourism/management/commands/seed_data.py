"""
Management command: seed_data.py

Seeds the Package and Hotel models with all 33 destinations from the
frontend's packagesData.js / HotelsData.js files, using only the fields
that currently exist on the models:

  Package: package_name, destination, duration, price, description
  Hotel:   code, hotel_name, location, rating, price_per_night, description

WHERE TO PUT THIS FILE:
  <your_app>/management/commands/seed_data.py
  (create the `management` and `management/commands` folders if they
  don't exist yet, each needs an empty __init__.py)

RUN:
  python manage.py seed_data

It's safe to re-run — packages are matched/updated by package_name,
hotels by their unique `code`, so nothing gets duplicated.
"""

import re
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from tourism.models import Package, Hotel


# ---------------------------------------------------------------------------
# Source data (condensed from packagesData.js — only fields the models use)
# ---------------------------------------------------------------------------
PACKAGES_DATA = [
    {"id": "india", "code": "IND", "destination": "India", "package_name": "India Heritage Tour Package", "tagline": "Taj Mahal sunrises to Kerala backwaters", "price": "35,000", "duration": "7 Days 6 Nights", "rating": 4.8, "description": "From the marble domes of Agra to houseboats drifting through Alleppey — a single-traveler journey through colour, craft and centuries of history."},
    {"id": "lakshadweep", "code": "LAK", "destination": "Lakshadweep", "package_name": "Lakshadweep Lagoon Escape", "tagline": "India's best-kept tropical secret", "price": "48,000", "duration": "5 Days 4 Nights", "rating": 4.8, "description": "Drift over untouched lagoons, snorkel reefs far from the crowds, and sleep in island huts on Kavaratti and Agatti."},
    {"id": "mauritius", "code": "MRU", "destination": "Mauritius", "package_name": "Mauritius Tropical Paradise", "tagline": "Catamarans, gorges and powder-white beaches", "price": "1,32,000", "duration": "6 Days 5 Nights", "rating": 4.9, "description": "Catamaran sail past Le Morne, hike Black River Gorges, and unwind on beaches framed by turquoise water."},
    {"id": "tamilnadu", "code": "TML", "destination": "Tamil Nadu", "package_name": "Tamil Nadu Temple & Hills Trail", "tagline": "Temple towers to misty tea estates", "price": "38,000", "duration": "6 Days 5 Nights", "rating": 4.7, "description": "Marvel at Madurai's towering temple, the seaside carvings of Mahabalipuram, and the misty hills of Ooty."},
    {"id": "russia", "code": "RUS", "destination": "Russia", "package_name": "Moscow & St. Petersburg Imperial Trail", "tagline": "Onion domes and gilded palaces", "price": "1,68,000", "duration": "8 Days 7 Nights", "rating": 4.7, "description": "Stand before Red Square's onion domes, then glide through the Hermitage's gilded halls in St. Petersburg."},
    {"id": "saudiarabia", "code": "KSA", "destination": "Saudi Arabia", "package_name": "AlUla & Riyadh Desert Discovery", "tagline": "Rock-cut tombs on travel's newest frontier", "price": "98,000", "duration": "6 Days 5 Nights", "rating": 4.8, "description": "Wander the rock-cut tombs of AlUla, watch Riyadh glow at dusk, and camp beneath desert stars."},
    {"id": "scotland", "code": "SCO", "destination": "Scotland", "package_name": "Scottish Highlands & Edinburgh Castle Trail", "tagline": "Single-track roads and single-malt whisky", "price": "1,42,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Drive misty roads past Loch Ness, tour centuries-old castles, and sample single-malt in the Highlands' oldest distilleries."},
    {"id": "portugal", "code": "POR", "destination": "Portugal", "package_name": "Lisbon & Porto Coastal Charm", "tagline": "Vintage trams and barrel-fresh port wine", "price": "1,08,000", "duration": "7 Days 6 Nights", "rating": 4.8, "description": "Rattle through Lisbon's hills on a vintage tram, taste port straight from the barrel, and finish on the Algarve coast."},
    {"id": "argentina", "code": "ARG", "destination": "Argentina", "package_name": "Buenos Aires & Patagonia Expedition", "tagline": "Tango streets to calving glaciers", "price": "1,88,000", "duration": "9 Days 8 Nights", "rating": 4.9, "description": "Dance tango in Buenos Aires' barrios, then fly south to walk beside glaciers and granite peaks in Patagonia."},
    {"id": "korea", "code": "KOR", "destination": "Korea", "package_name": "Seoul & Busan K-Culture Trail", "tagline": "Royal palaces by day, neon by night", "price": "95,000", "duration": "6 Days 5 Nights", "rating": 4.8, "description": "Wander Seoul's royal palaces by day and neon districts by night, then ride the coast to Busan."},
    {"id": "bali", "code": "BAL", "destination": "Bali", "package_name": "Bali Island Bliss", "tagline": "Rice terraces, waterfalls and sunset cocktails", "price": "62,000", "duration": "6 Days 5 Nights", "rating": 4.8, "description": "Rice terrace sunrises in Ubud, waterfall hikes, temple ceremonies at Uluwatu, and sunset cocktails in Seminyak."},
    {"id": "switzerland", "code": "SWI", "destination": "Switzerland", "package_name": "Swiss Alps Panorama Tour", "tagline": "Glacier trains and the Matterhorn's shadow", "price": "2,15,000", "duration": "8 Days 7 Nights", "rating": 4.9, "description": "Ride the Glacier Express through snow-capped peaks, cruise Lake Lucerne, and stand at the foot of the Matterhorn."},
    {"id": "vietnam", "code": "VIE", "destination": "Vietnam", "package_name": "Vietnam North to South Discovery", "tagline": "Limestone karsts to Mekong river life", "price": "72,000", "duration": "8 Days 7 Nights", "rating": 4.7, "description": "Cruise the limestone karsts of Ha Long Bay, wander Hanoi's Old Quarter, and drift the Mekong Delta by boat."},
    {"id": "kenya", "code": "KEN", "destination": "Kenya", "package_name": "Kenya Safari Adventure", "tagline": "Big Five tracking across the Maasai Mara", "price": "1,55,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Track the Big Five across the Maasai Mara, witness the Great Migration, and end with sundowners over the Rift Valley."},
    {"id": "japan", "code": "JPN", "destination": "Japan", "package_name": "Tokyo & Kyoto Classic Trail", "tagline": "Neon crossings to ancient temple lanes", "price": "1,45,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Neon crossings in Shibuya, ancient temples in Kyoto, and bullet trains gliding past Mount Fuji."},
    {"id": "thailand", "code": "THA", "destination": "Thailand", "package_name": "Bangkok & Phuket Island Trail", "tagline": "Golden temples to turquoise beach coves", "price": "58,000", "duration": "6 Days 5 Nights", "rating": 4.7, "description": "Golden temple spires in Bangkok, island-hopping speedboats, and lantern-lit streets in Phuket Old Town."},
    {"id": "singapore", "code": "SIN", "destination": "Singapore", "package_name": "Singapore City Lights Escape", "tagline": "Gardens by the Bay to Sentosa sunsets", "price": "82,000", "duration": "5 Days 4 Nights", "rating": 4.8, "description": "Supertree light shows, a cable car to Sentosa, and hawker-stall dinners under the Marina Bay skyline."},
    {"id": "dubai", "code": "UAE", "destination": "Dubai", "package_name": "Dubai Desert & Skyline Escape", "tagline": "Burj Khalifa views to dune bashing at dusk", "price": "88,000", "duration": "5 Days 4 Nights", "rating": 4.8, "description": "Observation decks over the world's tallest building, a dune-bashing desert safari, and marina promenades at golden hour."},
    {"id": "maldives", "code": "MDV", "destination": "Maldives", "package_name": "Maldives Overwater Retreat", "tagline": "Overwater villas above living coral", "price": "1,75,000", "duration": "5 Days 4 Nights", "rating": 4.9, "description": "Wake up over the lagoon, snorkel a house reef a few steps from your villa, and picnic on a private sandbank."},
    {"id": "nepal", "code": "NEP", "destination": "Nepal", "package_name": "Kathmandu & Pokhara Himalaya Trail", "tagline": "Ancient stupas beneath snow-capped peaks", "price": "45,000", "duration": "6 Days 5 Nights", "rating": 4.7, "description": "Spinning prayer wheels in Kathmandu, a boat ride on Phewa Lake, and sunrise over the Annapurna range."},
    {"id": "srilanka", "code": "SRI", "destination": "Sri Lanka", "package_name": "Sri Lanka Coast & Culture Trail", "tagline": "Ancient rock fortress to whale-watching coasts", "price": "68,000", "duration": "7 Days 6 Nights", "rating": 4.7, "description": "Climb the Sigiriya rock fortress, visit Kandy's Temple of the Tooth, and watch for blue whales off Mirissa."},
    {"id": "kashmir", "code": "KAS", "destination": "Kashmir", "package_name": "Kashmir Valley & Gulmarg Trail", "tagline": "Houseboats on Dal Lake, snow on Gulmarg's slopes", "price": "42,000", "duration": "6 Days 5 Nights", "rating": 4.8, "description": "Sleep on a houseboat over Dal Lake, ride the world's second-highest gondola in Gulmarg, and stroll Mughal-era gardens."},
    {"id": "andaman", "code": "AND", "destination": "Andaman Islands", "package_name": "Andaman Islands Beach & Reef Trail", "tagline": "Coral reefs and colonial-era history", "price": "52,000", "duration": "6 Days 5 Nights", "rating": 4.7, "description": "White-sand Radhanagar Beach, the Cellular Jail's sound-and-light history show, and reef snorkelling at Elephant Beach."},
    {"id": "turkey", "code": "TUR", "destination": "Turkey", "package_name": "Istanbul & Cappadocia Wonder Trail", "tagline": "Bosphorus sunsets and sunrise hot-air balloons", "price": "1,02,000", "duration": "7 Days 6 Nights", "rating": 4.8, "description": "Domes of the Hagia Sophia, a sunrise hot-air balloon over Cappadocia's fairy chimneys, and haggling in the Grand Bazaar."},
    {"id": "greece", "code": "GRE", "destination": "Greece", "package_name": "Athens & Santorini Aegean Trail", "tagline": "Ancient ruins to whitewashed caldera views", "price": "1,25,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Stand beneath the Parthenon at the Acropolis, then trade ruins for the whitewashed cliffs and sunsets of Santorini."},
    {"id": "italy", "code": "ITA", "destination": "Italy", "package_name": "Rome, Florence & Venice Grand Tour", "tagline": "Ruins, Renaissance art and canal-side sunsets", "price": "1,58,000", "duration": "8 Days 7 Nights", "rating": 4.9, "description": "Walk through the Colosseum's arches, stand before Renaissance masterpieces in the Uffizi, and glide Venice's canals by gondola."},
    {"id": "france", "code": "FRA", "destination": "France", "package_name": "Paris & French Riviera Escape", "tagline": "Eiffel Tower evenings to Riviera coastlines", "price": "1,48,000", "duration": "7 Days 6 Nights", "rating": 4.8, "description": "Champagne toasts under the Eiffel Tower, the Louvre's endless halls, and pastel promenades along the French Riviera."},
    {"id": "iceland", "code": "ICE", "destination": "Iceland", "package_name": "Iceland Ring Road & Northern Lights Trail", "tagline": "Waterfalls, glaciers and dancing auroras", "price": "1,98,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Geysers and waterfalls on the Golden Circle, icebergs drifting through Jökulsárlón, and a chance to chase the Northern Lights."},
    {"id": "newzealand", "code": "NZL", "destination": "New Zealand", "package_name": "New Zealand South Island Adventure", "tagline": "Fiords, glaciers and Middle-earth landscapes", "price": "2,05,000", "duration": "8 Days 7 Nights", "rating": 4.9, "description": "Cruise the cliffs of Milford Sound, chase adrenaline in Queenstown, and walk close to the Franz Josef Glacier."},
    {"id": "egypt", "code": "EGY", "destination": "Egypt", "package_name": "Cairo & Nile Explorer Trail", "tagline": "Pyramids, temples and a felucca on the Nile", "price": "1,12,000", "duration": "7 Days 6 Nights", "rating": 4.8, "description": "Stand before the Great Pyramids and Sphinx, sail the Nile past temple towns, and explore the Valley of the Kings."},
    {"id": "morocco", "code": "MOR", "destination": "Morocco", "package_name": "Marrakech & Sahara Desert Trail", "tagline": "Souk mazes to camel treks under desert stars", "price": "92,000", "duration": "6 Days 5 Nights", "rating": 4.7, "description": "Get lost in Marrakech's souk mazes, cross the Atlas Mountains, and camp in the Sahara after a camel trek at sunset."},
    {"id": "peru", "code": "PER", "destination": "Peru", "package_name": "Cusco & Machu Picchu Explorer", "tagline": "Inca citadels above the clouds", "price": "1,65,000", "duration": "7 Days 6 Nights", "rating": 4.9, "description": "Watch the sun rise over Machu Picchu, wander the Sacred Valley's Inca ruins, and hike the striped slopes of Rainbow Mountain."},
    {"id": "bhutan", "code": "BHU", "destination": "Bhutan", "package_name": "Thimphu & Paro Tiger's Nest Trail", "tagline": "Cliffside monasteries in the Last Shangri-La", "price": "1,05,000", "duration": "6 Days 5 Nights", "rating": 4.8, "description": "Hike to the cliffside Tiger's Nest Monastery, visit the riverside Punakha Dzong, and explore Thimphu's prayer-flag valleys."},
]

# From HotelsData.js — hotel names per destination id
HOTEL_NAMES = {
    "india": "The Leela Palace", "lakshadweep": "Coral Tide Lagoon Retreat",
    "mauritius": "Le Morne Azure Resort & Spa", "tamilnadu": "Taj Coromandel",
    "russia": "Nevsky Imperial Hotel", "saudiarabia": "AlUla Sandstone Lodge",
    "scotland": "Highland Thistle Manor", "portugal": "Ribeira Riverside Hotel",
    "argentina": "Patagonia Fitz Roy Lodge", "korea": "Hanok Myeongdong Suites",
    "bali": "Ubud Rice Terrace Villas", "switzerland": "Matterhorn View Chalet Hotel",
    "vietnam": "Ha Long Pearl Cruise Hotel", "kenya": "Mara Acacia Safari Camp",
    "japan": "Sakura Shibuya Hotel", "thailand": "Andaman Cove Beach Resort",
    "singapore": "Marina Skyline Hotel", "dubai": "Burj Vista Grand Hotel",
    "maldives": "Azure Reef Overwater Resort", "nepal": "Annapurna Lakeside Lodge",
    "srilanka": "Sigiriya Heritage Hotel", "kashmir": "Dal Lake Houseboat Retreat",
    "andaman": "Radhanagar Beachfront Resort", "turkey": "Cappadocia Cave Suites",
    "greece": "Caldera Cliffside Hotel", "italy": "Ponte Vecchio Grand Hotel",
    "france": "Champ de Mars Boutique Hotel", "iceland": "Aurora Glacier Lodge",
    "newzealand": "Queenstown Lakeview Lodge", "egypt": "Nile Pharaoh Cruise Hotel",
    "morocco": "Marrakech Riad Palace", "peru": "Sacred Valley Inca Lodge",
    "bhutan": "Paro Valley Heritage Lodge",
}


def parse_price(price_str):
    """'1,32,000' -> Decimal('132000')"""
    return Decimal(re.sub(r"[^\d]", "", price_str))


def parse_nights(duration):
    match = re.search(r"(\d+)\s*Nights?", duration, re.IGNORECASE)
    return int(match.group(1)) if match else 1


def round_to(num, step=50):
    return round(num / step) * step


class Command(BaseCommand):
    help = "Seed Package and Hotel tables with all 33 destinations from the frontend data"

    @transaction.atomic
    def handle(self, *args, **options):
        pkg_created, pkg_updated = 0, 0
        hotel_created, hotel_updated = 0, 0

        for item in PACKAGES_DATA:
            total_price = parse_price(item["price"])

            # --- Package ---
            pkg, created = Package.objects.update_or_create(
                package_name=item["package_name"],
                defaults={
                    "destination": item["destination"],
                    "duration": item["duration"],
                    "price": total_price,
                    "description": item["description"],
                },
            )
            if created:
                pkg_created += 1
            else:
                pkg_updated += 1

            # --- Hotel ---
            nights = parse_nights(item["duration"])
            per_night = max(Decimal(1500), Decimal(round_to(total_price / nights)))
            hotel_name = HOTEL_NAMES.get(item["id"], f"{item['destination']} Grand Hotel")

            hotel, h_created = Hotel.objects.update_or_create(
                code=item["code"],
                defaults={
                    "hotel_name": hotel_name,
                    "location": item["destination"],
                    "rating": item["rating"],
                    "price_per_night": per_night,
                    "description": item["tagline"],
                },
            )
            if h_created:
                hotel_created += 1
            else:
                hotel_updated += 1

        self.stdout.write(self.style.SUCCESS(
            f"Packages: {pkg_created} created, {pkg_updated} updated. "
            f"Hotels: {hotel_created} created, {hotel_updated} updated."
        ))