from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import CustomerProfile, DashboardStats


@receiver(post_save, sender=User)
def increment_customer_count_on_signup(sender, instance, created, **kwargs):
    """
    Runs every time a User row is created anywhere in the app
    (admin panel, signup API, management command, etc).
    This is what makes "7 customers -> signup -> 8 customers" happen
    automatically, without any view having to remember to do it.
    """
    if not created:
        return

    stats = DashboardStats.get_instance()
    stats.total_customers += 1
    stats.save(update_fields=["total_customers", "updated_at"])

    CustomerProfile.objects.get_or_create(user=instance)