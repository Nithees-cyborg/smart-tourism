from django.urls import path
from rest_framework import routers
from .api_views import admin_login
from .api_views import (
    login_api,
    signup_api,
    CustomerViewSet,
    PackageViewSet,
    BookingViewSet,
    HotelViewSet,
    PaymentViewSet,
)

router = routers.DefaultRouter()

router.register(r'customers', CustomerViewSet)
router.register(r'packages', PackageViewSet)
router.register(r'bookings', BookingViewSet)
router.register(r'hotels', HotelViewSet)
router.register(r'payments', PaymentViewSet)

urlpatterns = [
    path("login/", login_api, name="login_api"),
    path("signup/", signup_api, name="signup_api"),
    path("admin-login/", admin_login),
]

urlpatterns += router.urls
