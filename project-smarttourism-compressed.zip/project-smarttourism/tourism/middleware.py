from django.contrib.auth import logout
from django.conf import settings
from django.shortcuts import redirect
from datetime import datetime


class AutoLogoutMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        if request.user.is_authenticated:

            current_time = datetime.now().timestamp()

            last_activity = request.session.get(
                "last_activity",
                current_time
            )

            if current_time - last_activity > settings.SESSION_COOKIE_AGE:

                logout(request)

                return redirect("/login/")

            request.session["last_activity"] = current_time

        response = self.get_response(request)

        return response