from tourism.models import Customer

for i in range(1, 101):

    Customer.objects.get_or_create(
        email=f"customer{i}@gmail.com",
        defaults={
            "full_name": f"Customer {i}",
            "phone": f"98765{i:05d}",
            "city": [
                "Chennai",
                "Mumbai",
                "Delhi",
                "Bangalore",
                "Hyderabad",
                "Kochi",
                "Pune",
                "Jaipur"
            ][i % 8],
            "country": "India"
        }
    )

print("100 customers inserted")