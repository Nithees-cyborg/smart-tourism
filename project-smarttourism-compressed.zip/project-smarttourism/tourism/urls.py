from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from tourism import views
from .views import submit_contact_message

urlpatterns = [
    path('admin/', admin.site.urls),

    # ---- template pages (unchanged) ----
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup/', views.signup_view, name='signup'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('customers/', views.customers, name='customers'),
    path('packages/', views.packages, name='packages'),
    path('book-package/<int:package_id>/', views.register_booking, name='register_booking'),
    path('bookings/', views.bookings, name='bookings'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('hotels/', views.hotels, name='hotels'),
    path('payments/', views.payment_page, name='payments'),
    path('payment_success/', views.payment_success, name='payment_success'),
    path('contact/', views.contact, name='contact'),
    path('contact_success/', views.contact_success, name='contact_success'),
    path('about/', views.about, name='about'),
    path('services/', views.services, name='services'),
    path('gallery/', views.gallery, name='gallery'),
    path('success/', views.success, name='success'),
    path('privacy/', views.privacy, name='privacy'),
    path('terms/', views.terms, name='terms'),
    path('cookies/', views.cookies, name='cookies'),

    # ---- React JSON API ----
    path("api/test/", views.react_test),
    path("api/csrf/", views.csrf_api),
    path("api/me/", views.me_api),
    path("api/login/", views.login_api),
    path("api/logout/", views.logout_api),
    path("api/signup/", views.signup_api),
    path("api/contact/", views.contact_api),
    path("api/contact-message/", submit_contact_message, name="submit-contact-message"),
    path("api/packages/", views.packages_api),
    path("api/bookings/", views.register_booking_api),

    # ---- Live dashboard JSON API ----
    path("api/dashboard/stats/", views.dashboard_stats_api),
    path("api/dashboard/revenue-split/", views.revenue_split_api),
    path("api/dashboard/packages/top/", views.top_packages_api),
    path("api/dashboard/activity/", views.recent_activity_api),
    path("api/invoice/latest/", views.latest_invoice_api),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

