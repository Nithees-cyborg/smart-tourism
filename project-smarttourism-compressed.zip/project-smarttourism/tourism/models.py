from decimal import Decimal
from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.contrib.auth.models import User


# ==========================
# Customer
# ==========================
class Customer(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="customer_profile", null=True, blank=True
    )
    full_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    city = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    role = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    profile_image = models.ImageField(upload_to="profiles/", blank=True, null=True)

    theme = models.CharField(max_length=20, default="light")

    language = models.CharField(max_length=50, default="English")

    def __str__(self):
        return self.full_name


# ==========================
# Package
# ==========================
class Package(models.Model):
    package_name = models.CharField(max_length=200)
    destination = models.CharField(max_length=100)
    duration = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return self.package_name


# ==========================
# Booking
# ==========================
class Booking(models.Model):

    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Confirmed", "Confirmed"),
        ("Cancelled", "Cancelled"),
        ("Completed", "Completed"),
    ]

    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name="bookings"
    )

    package = models.ForeignKey(
        Package,
        on_delete=models.CASCADE,
        related_name="bookings"
    )

    travel_date = models.DateField()

    persons = models.PositiveIntegerField(default=1)

    total_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        editable=False
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="Pending"
    )

    booked_at = models.DateTimeField(auto_now_add=True)

    # Prevent current and previous dates
    def clean(self):
        if self.travel_date <= timezone.localdate():
            raise ValidationError({
                "travel_date": "Travel date must be a future date."
            })

    # Automatically calculate total amount
    def save(self, *args, **kwargs):

        self.full_clean()

        if self.package:
            self.total_amount = Decimal(self.persons) * self.package.price

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.customer.full_name} - {self.package.package_name}"


# ==========================
# Hotel
# ==========================
class Hotel(models.Model):
    code = models.CharField(max_length=20, unique=True, null=True, blank=True)  # matches "H01", "H02" etc. from the static React list
    hotel_name = models.CharField(max_length=200)
    location = models.CharField(max_length=200)
    rating = models.FloatField(default=0)
    price_per_night = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )
    hotel_image = models.ImageField(
        upload_to="hotels/",
        null=True,
        blank=True
    )
    description = models.TextField(blank=True)
    address = models.TextField(blank=True)

    def __str__(self):
        return self.hotel_name


# ==========================
# Payment
# ==========================
class Payment(models.Model):

    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Completed", "Completed"),
        ("Failed", "Failed"),
    ]

    booking = models.ForeignKey(
        Booking,
        on_delete=models.CASCADE,
        related_name="payments"
    )

    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    payment_method = models.CharField(max_length=50)

    payment_date = models.DateTimeField(auto_now_add=True)

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="Pending"
    )

    def __str__(self):
        return f"Payment #{self.id}"


# ==========================
# Contact
# ==========================
class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

# backend/models.py
# Add this model to whichever Django app handles your contact page
# (e.g. contact/models.py), then run:
#   python manage.py makemigrations
#   python manage.py migrate

class ContactMessage(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    subject = models.CharField(max_length=200, blank=True)
    message = models.TextField()
    ref_id = models.CharField(max_length=20, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    is_resolved = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.ref_id:
            import random
            self.ref_id = f"GST-{random.randint(100000, 999999)}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.ref_id} - {self.name}"

    class Meta:
        ordering = ["-created_at"]