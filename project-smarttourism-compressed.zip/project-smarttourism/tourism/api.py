from django.contrib.auth import authenticate, login
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(["POST"])
def login_api(request):

    username = request.data.get("username")
    password = request.data.get("password")

    user = authenticate(username=username,password=password)

    if user:
        login(request,user)
        return Response({
            "success":True,
            "username":user.username
        })

    return Response({
        "success":False,
        "message":"Invalid credentials"
    })