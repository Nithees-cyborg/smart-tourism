// ==========================================
// GLOBAL SMART TOURISM - CORE ENGINE SCRIPT
// ==========================================

document.addEventListener("DOMContentLoaded", function () {
    console.log("Global Smart Tourism Systems Engine: Loaded");

    // ==========================================
    // MULTI-SLIDE CAROUSEL & HERO CONTROLS
    // ==========================================
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    let slideInterval;

    if (slides.length > 0) {
        // Starts the automatic slider loop
        startSlideShow();

        // Bind enter key press to search bar for ease of access
        const destInput = document.getElementById('dest-input');
        if (destInput) {
            destInput.addEventListener('keypress', function (event) {
                if (event.key === 'Enter') {
                    executeSearch();
                }
            });
        }
    }

    function showSlide(index) {
        slides[currentSlide].classList.remove('active');
        currentSlide = (index + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
    }

    window.nextSlide = function () {
        showSlide(currentSlide + 1);
        resetSlideTimer();
    }

    window.prevSlide = function () {
        showSlide(currentSlide - 1);
        resetSlideTimer();
    }

    function startSlideShow() {
        slideInterval = setInterval(function () {
            showSlide(currentSlide + 1);
        }, 5000); // Transitions exactly every 5 seconds
    }

    function resetSlideTimer() {
        clearInterval(slideInterval);
        startSlideShow();
    }

    // ==========================================
    // INITIALIZE ANIMATED DASHBOARD COUNTERS
    // ==========================================
    animateCounter("customer-counter");
    animateCounter("package-counter");
    animateCounter("booking-counter");
    animateCounter("hotel-counter");
    animateCounter("payment-counter");
});

// Counter Incrementor Animation Mechanics
function animateCounter(id) {
    let element = document.getElementById(id);
    if (!element) return;

    let target = parseInt(element.innerText) || 0;
    if (target === 0) return;

    let count = 0;
    let speed = Math.ceil(target / 50);

    let interval = setInterval(function () {
        count += speed;
        if (count >= target) {
            count = target;
            clearInterval(interval);
        }
        element.innerText = count;
    }, 30);
}

// ==========================================
// DYNAMIC TOUR SEARCH WIDGET LOGIC
// ==========================================
function executeSearch() {
    const destInputField = document.getElementById("dest-input");
    const durationSelect = document.getElementById("duration-select");
    const typeSelect = document.getElementById("type-select");

    if (!destInputField) return;

    const destination = destInputField.value.trim();
    const duration = durationSelect ? durationSelect.value : "any";
    const travelType = typeSelect ? typeSelect.value : "all";

    // Structural Rule validation check
    if (destination === "") {
        alert("Please enter a destination country, region, or city to begin your search.");
        destInputField.focus();
        return;
    }

    // Maps query arrays cleanly to your backend destination path ruleset
    const queryUrl = `/packages/?destination=${encodeURIComponent(destination)}&duration=${encodeURIComponent(duration)}&type=${encodeURIComponent(travelType)}`;
    
    console.log(`Executing redirect array target paths: ${queryUrl}`);
    window.location.href = queryUrl;
}

// ==========================================
// USER VALIDATION CHECKS
// ==========================================

function validateLogin() {
    let username = document.getElementById("username").value.trim();
    let password = document.getElementById("password").value.trim();

    if (username === "") {
        alert("Enter Username");
        return false;
    }
    if (password === "") {
        alert("Enter Password");
        return false;
    }
    return true;
}

function validateSignup() {
    let username = document.getElementById("username").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("confirm_password").value;

    if (username === "") {
        alert("Enter Username");
        return false;
    }
    if (email === "") {
        alert("Enter Email");
        return false;
    }
    if (password.length < 6) {
        alert("Password must be at least 6 characters");
        return false;
    }
    if (password !== confirm) {
        alert("Passwords do not match");
        return false;
    }
    return true;
}

function validateContact() {
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();

    if (name === "") {
        alert("Enter Name");
        return false;
    }
    if (email === "") {
        alert("Enter Email");
        return false;
    }
    if (!email.includes("@")) {
        alert("Enter Valid Email");
        return false;
    }
    if (message === "") {
        alert("Enter Message");
        return false;
    }
    return true;
}

// ==========================================
// LIVE TRANSACTION CALCULATIONS
// ==========================================

function confirmBooking(packageName) {
    return confirm(`Do you want to book the ${packageName} package?`);
}

function calculateAmount() {
    let persons = document.getElementById("persons");
    let price = document.getElementById("price");
    let total = document.getElementById("total");

    if (!persons || !price || !total) return;

    let personCount = parseInt(persons.value) || 0;
    let packagePrice = parseFloat(price.value) || 0;

    total.value = personCount * packagePrice;
}

// ==========================================
// UTILITY ENGINE COMPONENTS
// ==========================================

// Smooth Anchor Scroll Router Actions
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        let target = document.querySelector(this.getAttribute("href"));
        if (target) {
            target.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
});

// Dynamic Back To Top Button Rulesets
window.onscroll = function () {
    let btn = document.getElementById("topBtn");
    if (!btn) return;

    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
};

function topFunction() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}
// Add this inside your DOMContentLoaded block or at the bottom of your script file
document.addEventListener("DOMContentLoaded", function () {
    // Check if we are currently on the packages page
    if (window.location.pathname.includes("/packages/")) {
        filterPackagesFromUrl();
    }
});

// Function running on the Packages Page to read URL filters
function filterPackagesFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchDest = urlParams.get('destination')?.toLowerCase() || "";
    const searchDuration = urlParams.get('duration') || "any";
    const searchType = urlParams.get('type') || "all";

    const cards = document.querySelectorAll('.package-card');
    let foundResults = false;

    cards.forEach(card => {
        const cardDest = card.getAttribute('data-destination')?.toLowerCase() || "";
        const cardDuration = card.getAttribute('data-duration') || "";
        const cardType = card.getAttribute('data-type') || "";

        // Check matching rules
        const matchesDest = searchDest === "" || cardDest.includes(searchDest);
        const matchesDuration = searchDuration === "any" || cardDuration === searchDuration;
        const matchesType = searchType === "all" || cardType === searchType;

        if (matchesDest && matchesDuration && matchesType) {
            card.style.display = "block"; // Show match
            foundResults = true;
        } else {
            card.style.display = "none";  // Hide non-match
        }
    });

    // Handle empty state if nothing matches the filters
    if (!foundResults) {
        const container = document.querySelector('.card-container');
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; grid-column: 1/-1; padding: 40px; color: #64748b;">
                    <i class="fa-solid fa-folder-open" style="font-size: 48px; margin-bottom: 15px;"></i>
                    <h3>No Matching Tours Found</h3>
                    <p>Try searching for another destination like 'Goa' or 'Dubai'.</p>
                    <a href="/packages/" style="color: #2563eb; text-decoration: underline; font-weight: 600;">View All Packages</a>
                </div>`;
        }
    }
}
/* ==========================================
   THEME TOGGLE — Light / Dark Mode
   Drop this on every page (load it EARLY in <head>,
   without "defer", so it runs before the page paints):

     <script src="{% static 'js/theme.js' %}"></script>

   Then anywhere in your navbar add:

     <button class="theme-toggle-btn" data-theme-toggle aria-label="Toggle dark mode">
         <i class="fa-solid fa-moon"></i>
     </button>

   That's it — the choice is remembered (localStorage)
   and applied instantly on every page.
   ========================================== */

/* Runs immediately: sets data-theme on <html> before first paint */
(function () {
    var saved = localStorage.getItem('theme');
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute('data-theme', saved || (prefersDark ? 'dark' : 'light'));
})();

/* Wires up any button with [data-theme-toggle] once the DOM is ready */
document.addEventListener('DOMContentLoaded', function () {
    var toggleBtns = document.querySelectorAll('[data-theme-toggle]');

    function applyIcons(theme) {
        toggleBtns.forEach(function (btn) {
            var icon = btn.querySelector('i');
            if (icon) icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
        });
    }

    applyIcons(document.documentElement.getAttribute('data-theme'));

    toggleBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            var current = document.documentElement.getAttribute('data-theme');
            var next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
            applyIcons(next);
        });
    });
});

/* ═══════════════════════════════════════════
   main.js — Global Smart Tourism
   Theme toggle + micro-interactions
═══════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── 1. THEME TOGGLE ─────────────────────── */
  const btn  = document.getElementById('theme-toggle');
  const icon = document.getElementById('theme-icon');
  const root = document.documentElement;

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    if (icon) {
      icon.className = theme === 'dark'
        ? 'fa-solid fa-sun'
        : 'fa-solid fa-moon';
    }
  }

  // Honour saved preference or OS preference on load
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));

  if (btn) {
    btn.addEventListener('click', () => {
      const current = root.getAttribute('data-theme') || 'light';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  }

  /* ── 2. ANIMATE STAT NUMBERS ON SCROLL ──── */
  function animateCount(el) {
    const text  = el.textContent.trim();
    const num   = parseFloat(text.replace(/[^0-9.]/g, ''));
    const prefix = text.match(/^[^0-9]*/)?.[0] || '';
    const suffix = text.match(/[^0-9.]*$/)?.[0] || '';
    if (isNaN(num) || num === 0) return;

    const duration = 1200;
    const start    = performance.now();

    function step(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased    = 1 - Math.pow(1 - progress, 3);
      const current  = Math.round(eased * num);
      el.textContent = prefix + current.toLocaleString() + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  }

  const statNums = document.querySelectorAll('.stat-num');

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    statNums.forEach(el => io.observe(el));
  }

  /* ── 3. PROGRESS BARS ANIMATE IN ────────── */
  const bars = document.querySelectorAll('.rev-bar-fill');

  if ('IntersectionObserver' in window) {
    const barIO = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const target = entry.target.dataset.width;
          if (target) entry.target.style.width = target;
          barIO.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    bars.forEach(bar => {
      const w = bar.style.width;
      bar.dataset.width = w;
      bar.style.width   = '0%';
      barIO.observe(bar);
    });
  }

  /* ── 4. ACTIVE NAV LINK ──────────────────── */
  const path  = window.location.pathname;
  const links = document.querySelectorAll('.nav-links a');
  links.forEach(a => {
    if (a.href && a.pathname === path) {
      links.forEach(l => l.classList.remove('active'));
      a.classList.add('active');
    }
  });

  /* ── 5. NEWSLETTER SUBSCRIBE ─────────────── */
  const ctaBtn = document.querySelector('.cta-form button');
  const ctaInp = document.querySelector('.cta-form input[type="email"]');

  if (ctaBtn && ctaInp) {
    ctaBtn.addEventListener('click', () => {
      const email = ctaInp.value.trim();
      const re    = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!re.test(email)) {
        ctaInp.style.borderColor = '#ef4444';
        ctaInp.focus();
        return;
      }
      ctaInp.style.borderColor = '';
      ctaBtn.textContent = '✓ Subscribed!';
      ctaBtn.style.background = '#10b981';
      ctaBtn.disabled = true;
      ctaInp.value = '';
    });
  }

  /* ── 6. MOBILE NAV HAMBURGER (if present) ── */
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobile-nav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      const open = mobileNav.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', open);
    });
  }

  /* ── 7. SCROLL-REVEAL PANELS ─────────────── */
  const panels = document.querySelectorAll(
    '.panel, .stat-card, .feat-card, .testi-card, .activity-item'
  );

  if ('IntersectionObserver' in window) {
    const revealIO = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          revealIO.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    panels.forEach(p => {
      p.classList.add('reveal-ready');
      revealIO.observe(p);
    });
  }

  /* ── 8. SMOOTH SCROLL FOR ANCHOR LINKS ───── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const id = a.getAttribute('href').slice(1);
      const el = id ? document.getElementById(id) : null;
      if (el) {
        e.preventDefault();
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

})();
// ==========================================
// GLOBAL SMART TOURISM - CORE ENGINE SCRIPT
// ==========================================

/* ── THEME TOGGLE (single source of truth) ─────────────────────
   Works with EITHER markup convention used across the site:
     1) <button data-theme-toggle> ... </button>  (icon swap handled by CSS)
     2) <button id="theme-toggle"><i id="theme-icon"></i></button> (icon swap handled here)
   Runs once, attaches exactly one listener per button — no double-toggling.
================================================================== */
(function () {
    var saved = localStorage.getItem('theme');
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = saved || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);

    function applyIcon(btn, theme) {
        // Only touch icons for the single-icon convention (#theme-toggle / #theme-icon).
        // Buttons using [data-theme-toggle] with two stacked icons (fa-moon + fa-sun)
        // are animated purely by CSS — leave their markup alone.
        if (btn.id !== 'theme-toggle') return;
        var icon = document.getElementById('theme-icon') || btn.querySelector('i');
        if (icon) icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    }

    function wireToggles() {
        var buttons = new Set();
        document.querySelectorAll('[data-theme-toggle]').forEach(function (b) { buttons.add(b); });
        var legacyBtn = document.getElementById('theme-toggle');
        if (legacyBtn) buttons.add(legacyBtn);

        buttons.forEach(function (btn) {
            applyIcon(btn, document.documentElement.getAttribute('data-theme'));
            btn.addEventListener('click', function () {
                var current = document.documentElement.getAttribute('data-theme') || 'light';
                var next = current === 'dark' ? 'light' : 'dark';
                document.documentElement.setAttribute('data-theme', next);
                try { localStorage.setItem('theme', next); } catch (e) {}
                buttons.forEach(function (b) { applyIcon(b, next); });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', wireToggles);
    } else {
        wireToggles();
    }
})();

document.addEventListener("DOMContentLoaded", function () {
    console.log("Global Smart Tourism Systems Engine: Loaded");

    // ==========================================
    // MULTI-SLIDE CAROUSEL & HERO CONTROLS
    // ==========================================
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    let slideInterval;

    if (slides.length > 0) {
        startSlideShow();

        const destInput = document.getElementById('dest-input');
        if (destInput) {
            destInput.addEventListener('keypress', function (event) {
                if (event.key === 'Enter') {
                    executeSearch();
                }
            });
        }
    }

    function showSlide(index) {
        slides[currentSlide].classList.remove('active');
        currentSlide = (index + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
    }

    window.nextSlide = function () {
        showSlide(currentSlide + 1);
        resetSlideTimer();
    }

    window.prevSlide = function () {
        showSlide(currentSlide - 1);
        resetSlideTimer();
    }

    function startSlideShow() {
        slideInterval = setInterval(function () {
            showSlide(currentSlide + 1);
        }, 5000);
    }

    function resetSlideTimer() {
        clearInterval(slideInterval);
        startSlideShow();
    }

    // ==========================================
    // INITIALIZE ANIMATED DASHBOARD COUNTERS
    // ==========================================
    animateCounter("customer-counter");
    animateCounter("package-counter");
    animateCounter("booking-counter");
    animateCounter("hotel-counter");
    animateCounter("payment-counter");

    // ==========================================
    // ANIMATE STAT NUMBERS ON SCROLL (.stat-num)
    // ==========================================
    const statNums = document.querySelectorAll('.stat-num');
    if ('IntersectionObserver' in window && statNums.length) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateStatNum(entry.target);
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        statNums.forEach(el => io.observe(el));
    }

    // ==========================================
    // PROGRESS BARS ANIMATE IN (.rev-bar-fill)
    // ==========================================
    const bars = document.querySelectorAll('.rev-bar-fill');
    if ('IntersectionObserver' in window && bars.length) {
        const barIO = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = entry.target.dataset.width;
                    if (target) entry.target.style.width = target;
                    barIO.unobserve(entry.target);
                }
            });
        }, { threshold: 0.4 });

        bars.forEach(bar => {
            const w = bar.style.width;
            bar.dataset.width = w;
            bar.style.width = '0%';
            barIO.observe(bar);
        });
    }

    // ==========================================
    // ACTIVE NAV LINK (.nav-links a)
    // ==========================================
    const path = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(a => {
        if (a.pathname === path) {
            navLinks.forEach(l => l.classList.remove('active'));
            a.classList.add('active');
        }
    });

    // ==========================================
    // NEWSLETTER SUBSCRIBE (.cta-form)
    // ==========================================
    const ctaBtn = document.querySelector('.cta-form button');
    const ctaInp = document.querySelector('.cta-form input[type="email"]');
    if (ctaBtn && ctaInp) {
        ctaBtn.addEventListener('click', () => {
            const email = ctaInp.value.trim();
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!re.test(email)) {
                ctaInp.style.borderColor = '#ef4444';
                ctaInp.focus();
                return;
            }
            ctaInp.style.borderColor = '';
            ctaBtn.textContent = '✓ Subscribed!';
            ctaBtn.style.background = '#10b981';
            ctaBtn.disabled = true;
            ctaInp.value = '';
        });
    }

    // ==========================================
    // MOBILE NAV HAMBURGER (#hamburger / #mobile-nav)
    // ==========================================
    const hamburger = document.getElementById('hamburger');
    const mobileNav = document.getElementById('mobile-nav');
    if (hamburger && mobileNav) {
        hamburger.addEventListener('click', () => {
            const open = mobileNav.classList.toggle('open');
            hamburger.setAttribute('aria-expanded', open);
        });
    }

    // ==========================================
    // SCROLL-REVEAL PANELS (.panel, .stat-card, etc.)
    // ==========================================
    const panels = document.querySelectorAll(
        '.panel, .stat-card, .feat-card, .testi-card, .activity-item'
    );
    if ('IntersectionObserver' in window && panels.length) {
        const revealIO = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealIO.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08 });

        panels.forEach(p => {
            p.classList.add('reveal-ready');
            revealIO.observe(p);
        });
    }

    // Packages page: read filters from URL
    if (window.location.pathname.includes("/packages/")) {
        filterPackagesFromUrl();
    }
});

// Counter Incrementor Animation Mechanics
function animateCounter(id) {
    let element = document.getElementById(id);
    if (!element) return;

    let target = parseInt(element.innerText) || 0;
    if (target === 0) return;

    let count = 0;
    let speed = Math.ceil(target / 50);

    let interval = setInterval(function () {
        count += speed;
        if (count >= target) {
            count = target;
            clearInterval(interval);
        }
        element.innerText = count;
    }, 30);
}

// Stat number animation (text like "1,200+" / "$45k")
function animateStatNum(el) {
    const text = el.textContent.trim();
    const num = parseFloat(text.replace(/[^0-9.]/g, ''));
    const prefix = text.match(/^[^0-9]*/)?.[0] || '';
    const suffix = text.match(/[^0-9.]*$/)?.[0] || '';
    if (isNaN(num) || num === 0) return;

    const duration = 1200;
    const start = performance.now();

    function step(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const current = Math.round(eased * num);
        el.textContent = prefix + current.toLocaleString() + suffix;
        if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
}

// ==========================================
// DYNAMIC TOUR SEARCH WIDGET LOGIC
// ==========================================
function executeSearch() {
    const destInputField = document.getElementById("dest-input");
    const durationSelect = document.getElementById("duration-select");
    const typeSelect = document.getElementById("type-select");

    if (!destInputField) return;

    const destination = destInputField.value.trim();
    const duration = durationSelect ? durationSelect.value : "any";
    const travelType = typeSelect ? typeSelect.value : "all";

    if (destination === "") {
        alert("Please enter a destination country, region, or city to begin your search.");
        destInputField.focus();
        return;
    }

    const queryUrl = `/packages/?destination=${encodeURIComponent(destination)}&duration=${encodeURIComponent(duration)}&type=${encodeURIComponent(travelType)}`;
    window.location.href = queryUrl;
}

// Packages page: filter cards from URL query params
function filterPackagesFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchDest = urlParams.get('destination')?.toLowerCase() || "";
    const searchDuration = urlParams.get('duration') || "any";
    const searchType = urlParams.get('type') || "all";

    const cards = document.querySelectorAll('.package-card');
    let foundResults = false;

    cards.forEach(card => {
        const cardDest = card.getAttribute('data-destination')?.toLowerCase() || "";
        const cardDuration = card.getAttribute('data-duration') || "";
        const cardType = card.getAttribute('data-type') || "";

        const matchesDest = searchDest === "" || cardDest.includes(searchDest);
        const matchesDuration = searchDuration === "any" || cardDuration === searchDuration;
        const matchesType = searchType === "all" || cardType === searchType;

        if (matchesDest && matchesDuration && matchesType) {
            card.style.display = "block";
            foundResults = true;
        } else {
            card.style.display = "none";
        }
    });

    if (!foundResults) {
        const container = document.querySelector('.card-container');
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; grid-column: 1/-1; padding: 40px; color: #64748b;">
                    <i class="fa-solid fa-folder-open" style="font-size: 48px; margin-bottom: 15px;"></i>
                    <h3>No Matching Tours Found</h3>
                    <p>Try searching for another destination like 'Goa' or 'Dubai'.</p>
                    <a href="/packages/" style="color: #2563eb; text-decoration: underline; font-weight: 600;">View All Packages</a>
                </div>`;
        }
    }
}

// ==========================================
// USER VALIDATION CHECKS
// ==========================================
function validateLogin() {
    let username = document.getElementById("username").value.trim();
    let password = document.getElementById("password").value.trim();

    if (username === "") {
        alert("Enter Username");
        return false;
    }
    if (password === "") {
        alert("Enter Password");
        return false;
    }
    return true;
}

function validateSignup() {
    let username = document.getElementById("username").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("confirm_password").value;

    if (username === "") {
        alert("Enter Username");
        return false;
    }
    if (email === "") {
        alert("Enter Email");
        return false;
    }
    if (password.length < 6) {
        alert("Password must be at least 6 characters");
        return false;
    }
    if (password !== confirm) {
        alert("Passwords do not match");
        return false;
    }
    return true;
}

function validateContact() {
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();

    if (name === "") {
        alert("Enter Name");
        return false;
    }
    if (email === "") {
        alert("Enter Email");
        return false;
    }
    if (!email.includes("@")) {
        alert("Enter Valid Email");
        return false;
    }
    if (message === "") {
        alert("Enter Message");
        return false;
    }
    return true;
}

// ==========================================
// LIVE TRANSACTION CALCULATIONS
// ==========================================
function confirmBooking(packageName) {
    return confirm(`Do you want to book the ${packageName} package?`);
}

function calculateAmount() {
    let persons = document.getElementById("persons");
    let price = document.getElementById("price");
    let total = document.getElementById("total");

    if (!persons || !price || !total) return;

    let personCount = parseInt(persons.value) || 0;
    let packagePrice = parseFloat(price.value) || 0;

    total.value = personCount * packagePrice;
}

// ==========================================
// UTILITY ENGINE COMPONENTS
// ==========================================

// Smooth Anchor Scroll Router Actions
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        let target = document.querySelector(this.getAttribute("href"));
        if (target) {
            target.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
});

// Dynamic Back To Top Button Rulesets
window.onscroll = function () {
    let btn = document.getElementById("topBtn");
    if (!btn) return;

    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
};

function topFunction() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}