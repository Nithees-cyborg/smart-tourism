import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Forwards /api requests to Django instead of Vite's own dev server
      // (which was returning index.html, causing "Unexpected token '<'")
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      // Needed if you ever fetch Django media/uploaded files directly
      '/media': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
})