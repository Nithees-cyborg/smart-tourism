import axios from "axios";

// Relative baseURL on purpose: every request goes through the Vite dev
// proxy (see vite.config.js -> server.proxy["/api"]) so the sessionid and
// csrftoken cookies Django sets always land on the SAME origin
// (localhost:5173) that the rest of the app runs on. Using an absolute
// "http://localhost:8000/api/" baseURL here would set those cookies under
// a different origin, and requests made through the proxy elsewhere in
// the app would never see them.
const api = axios.create({
  baseURL: "/api/",
  withCredentials: true, // sends/receives the Django session + csrf cookies
});

function getCookie(name) {
  const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]+)`));
  return match ? match[2] : null;
}

api.interceptors.request.use((config) => {
  const method = (config.method || "get").toUpperCase();
  if (["POST", "PUT", "PATCH", "DELETE"].includes(method)) {
    const csrftoken = getCookie("csrftoken");
    if (csrftoken) config.headers["X-CSRFToken"] = csrftoken;
  }
  return config;
});

// Call once on app load (see App.jsx) so the csrftoken cookie exists
// BEFORE the user ever submits a form. Without this, the very first POST
// of a session (usually login) has nothing for the interceptor above to
// attach, and Django rejects it with 403 CSRF Failed.
export function fetchCsrfCookie() {
  return api.get("csrf/").catch(() => {
    console.warn("Could not pre-fetch CSRF cookie");
  });
}

export default api;