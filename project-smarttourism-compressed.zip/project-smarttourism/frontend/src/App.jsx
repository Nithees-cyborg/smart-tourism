import { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";

import { fetchCsrfCookie } from "./api";

import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Services from "./pages/Services";
import Packages from "./pages/Packages";
import Gallery from "./pages/Gallery";
import Hotels from "./pages/Hotels";
import AdminLogin from "./pages/AdminLogin";
import Payments from "./pages/Payments";
import RegisterBooking from "./pages/RegisterBooking";
import Payment_Success from "./pages/Payment_Success";
import Success from "./pages/Success";
import Contact_Success from "./pages/Contact_Success";
import Settings from "./pages/Settings";
import HotelOverview from "./pages/HotelOverview";
import Transports from "./pages/Transports";
import Overallview from "./pages/Overallview";
import Invoice from "./pages/Invoice";
import Rewards from "./pages/Rewards";
import Refunds from "./pages/Refunds";
import Cookies from "./pages/cookies";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Career from "./pages/Career";

export default function App() {
  // Fetch the CSRF cookie once, before any POST (login, signup, contact,
  // booking, etc.) is ever sent from anywhere in the app. Without this,
  // the browser has no csrftoken cookie yet and the first unsafe request
  // of the session gets rejected with 403 CSRF Failed.
  useEffect(() => {
    fetchCsrfCookie();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        {/* Home Page */}
        <Route path="/" element={<Home />} />

        {/* Dashboard Page */}
        <Route path="/dashboard/" element={<Dashboard />} />

        {/* Login Page */}
        <Route path="/login/" element={<Login />} />

        {/*Signup Page*/}

        <Route path="/signup/" element={<Signup />} />

        {/*Contact Page*/}

        <Route path="/contact/" element={<Contact />} />

        {/*About Page*/}

        <Route path="/about/" element={<About />} />

        {/*Services Page*/}

        <Route path="/services/" element={<Services />} />

        {/*Packages Page*/}

        <Route path="/packages/" element={<Packages />} />

        {/*Gallery Page*/}

        <Route path="/gallery/" element={<Gallery />} />

        {/*Hotels Page*/}

        <Route path="/hotels/" element={<Hotels />} />

        {/*Admin Page*/}

        <Route path="/admin-login" element={<AdminLogin />} />

        {/*Payments Page*/}

        <Route path="/payments" element={<Payments />} />

        {/*Register_Booking Page*/}

        <Route path="/register_booking/:id" element={<RegisterBooking />} />

        {/*Payment_Success Page*/}

        <Route path="/payment-success" element={<Payment_Success />} />

        {/*Success Page*/}

        <Route path="/success" element={<Success />} />

        {/*Contact_Success Page*/}

        <Route path="/contact-success" element={<Contact_Success />} />

        {/*Settings Page*/}

        <Route path="/settings" element={<Settings />} />

        {/*HotelOverview Page*/}

        <Route path="/hotels/:hotelId/overview" element={<HotelOverview />} />

        {/*Transports Page*/}

        <Route path="/transports" element={<Transports />} />

        {/*Overallview Page*/}

        <Route path="/overview/:packageId" element={<Overallview />} />

        {/*Invoice Page*/}

        <Route path="/invoice" element={<Invoice />} />

        {/*Rewards Page*/}

        <Route path="/rewards" element={<Rewards />} />

        {/*Refunds Page*/}

        <Route path="/refunds" element={<Refunds />} />

        {/*Cookies Page*/}

        <Route path="/cookies" element={<Cookies />} />

        {/*Terms Page*/}

        <Route path="/terms" element={<Terms />} />

        {/*Privacy Page*/}

        <Route path="/privacy" element={<Privacy />} />

        {/*Career Page*/}

        <Route path="/career" element={<Career />} />

        {/* 404 Page */}
        <Route
          path="*"
          element={
            <div style={{ padding: "40px", textAlign: "center" }}>
              <h1>404 - Page Not Found</h1>
            </div>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}