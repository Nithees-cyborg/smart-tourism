import React from "react";

export default function Payment_SuccessBookingCard({ booking }) {
  return (
    <div className="card">
      <div className="card-title">📋 Booking Summary</div>

      <div className="info-row">
        <span className="info-label">Booking ID</span>
        <span className="info-val">#GST-{booking.id}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Package</span>
        <span className="info-val">{booking.package.package_name}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Destination</span>
        <span className="info-val">{booking.package.destination}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Travel Date</span>
        <span className="info-val">{booking.travel_date}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Persons</span>
        <span className="info-val">{booking.persons}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Status</span>
        <span className="info-val">
          <span className="badge-confirmed">Confirmed</span>
        </span>
      </div>

      <div className="total-box">
        <span className="total-label">Amount Paid</span>
        <span className="total-amount">₹ {booking.total_amount}</span>
      </div>
    </div>
  );
}