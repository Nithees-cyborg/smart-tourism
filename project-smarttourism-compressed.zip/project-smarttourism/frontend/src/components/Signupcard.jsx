import React from 'react';

// Simple wrapper so the card's look (radius, shadow, animation) lives in one
// place. Everything passed as children renders inside the white card.
export default function Signupcard({ children }) {
  return <div className="signup-card">{children}</div>;
}