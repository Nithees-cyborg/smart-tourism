import React, { useState } from "react";

/**
 * Contact_SuccessHero.jsx
 * Badge image, heading, lead paragraph, reference-id chip + copy button,
 * and the "Submitted on ..." timestamp.
 *
 * Props:
 *  - refId       (string) reference id returned by the backend after saving the message
 *  - submittedOn (string) ISO date string returned by the backend (optional)
 *
 * Paste into: src/components/Contact_SuccessHero.jsx
 */
export default function Contact_SuccessHero({ refId, submittedOn }) {
  const [copied, setCopied] = useState(false);

  const displayId = refId || "GST-783548";
  const displayDate = submittedOn
    ? new Date(submittedOn).toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      })
    : new Date().toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });

  const copyRefId = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(displayId);
      } else {
        const temp = document.createElement("textarea");
        temp.value = displayId;
        document.body.appendChild(temp);
        temp.select();
        document.execCommand("copy");
        document.body.removeChild(temp);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch (err) {
      // silently ignore clipboard failures
    }
  };

  return (
    <>
      <div className="cs-badge-wrap">
        <div className="cs-badge-glow" aria-hidden="true"></div>
        <img
          src="/images/co-success.jpg"
          alt="Message sent confirmation"
          className="cs-badge-img"
        />
        <span className="cs-badge-check">
          <i className="fa-solid fa-check"></i>
        </span>
      </div>

      <span className="cs-eyebrow">Message Received</span>
      <h1 className="cs-heading">Your Message Has Been Sent</h1>
      <p className="cs-lead">
        Thank you for contacting Global Smart Tourism. Our travel support team has received
        your message and a specialist is already reviewing it.
      </p>

      <div className="cs-ref-row">
        <div className="cs-ref-chip">
          <span className="cs-ref-label">Reference</span>
          <span className="cs-ref-value">{displayId}</span>
        </div>
        <button
          type="button"
          className={`cs-copy-btn ${copied ? "is-copied" : ""}`}
          onClick={copyRefId}
        >
          {copied ? (
            <>
              <i className="fa-solid fa-check"></i> Copied
            </>
          ) : (
            <>
              <i className="fa-regular fa-copy"></i> Copy
            </>
          )}
        </button>
      </div>
      <p className="cs-submitted-on">Submitted on {displayDate}</p>
    </>
  );
}