import React from "react";
import privacyImg from "/privacy.jpg";

export default function PrivacyHero() {
  return (
    <section
      className="legal-hero"
      style={{
        backgroundImage: `linear-gradient(175deg, rgba(16,45,89,0.92) 0%, rgba(8,18,38,0.96) 100%), url(${privacyImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="legal-hero-inner">
        <p className="legal-crumb">
          <a href="/">Home</a>
          <span>/</span>Privacy Policy
        </p>
        <p className="eyebrow on-dark">Legal</p>
        <h1>
          Your <em>Privacy</em>, Mapped Out Clearly
        </h1>
        <p>
          This policy explains what information Global Smart Tourism
          collects when you browse, book, or travel with us, how we use it,
          and the choices you have. We've tried to write it the way we'd
          explain it to a friend, not a courtroom.
        </p>
        <div className="legal-meta">
          <span className="legal-meta-item">
            Effective Date: <b>January 1, 2026</b>
          </span>
          <span className="legal-meta-item">
            Last Updated: <b>June 29, 2026</b>
          </span>
        </div>
      </div>
    </section>
  );
}