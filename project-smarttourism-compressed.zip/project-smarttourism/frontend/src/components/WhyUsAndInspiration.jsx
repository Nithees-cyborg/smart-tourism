import { FEATURES, INSPIRATION } from "./data";
export function WhyUs() {
  return (
    <div className="why-us-bg">
      <div className="sec">
        <div className="sec-head reveal">
          <div className="sec-eye">Why Us</div>
          <h2 className="sec-title">Travel Smarter With Us</h2>
          <p className="sec-sub">Every detail handled so you can focus on the experience.</p>
        </div>
        <div className="feats-grid">
          {FEATURES.map((f, i) => (
            <div key={i} className="feat reveal" style={{ transitionDelay: `${i * 60}ms` }}>
              <div className={`feat-icon ${f.color}`}><i className={`fa-solid ${f.icon}`}></i></div>
              <div className="feat-title">{f.title}</div>
              <div className="feat-desc">{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function InspirationSection() {
  return (
    <div className="sec">
      <div className="sec-head reveal">
        <div className="sec-eye">Travel Inspiration</div>
        <h2 className="sec-title">Stories From the Road</h2>
        <p className="sec-sub">Real itineraries and insider tips to help you plan smarter.</p>
      </div>
      <div className="insp-grid">
        {INSPIRATION.map((it, i) => (
          <div key={i} className="insp-card reveal" style={{ transitionDelay: `${i * 80}ms` }}>
            <div className="insp-img"><img src={it.img} alt={it.title} /></div>
            <div className="insp-body">
              <span className="insp-tag">{it.tag}</span>
              <div className="insp-title">{it.title}</div>
              <p className="insp-excerpt">{it.excerpt}</p>
              <a href="/packages" className="insp-link">Read the guide <i className="fa-solid fa-arrow-right"></i></a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}