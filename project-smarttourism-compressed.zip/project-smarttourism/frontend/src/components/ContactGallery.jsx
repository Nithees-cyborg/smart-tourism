import { useState } from 'react';

const items = [
  { img: '/images/contact1.jpg', alt: 'Global Smart Tourism Chennai office reception', icon: 'fa-building', grad: 'var(--ocean),var(--ocean-lite)', title: 'Chennai Care Centre', sub: 'Our main customer care office' },
  { img: '/images/contact2.jpg', alt: 'Customer care desk helping a traveller', icon: 'fa-headset', grad: 'var(--teal),#34c0b0', title: 'Customer Care Desk', sub: 'Walk-in support, no appointment needed' },
  { img: '/images/contact3.jpg', alt: 'Travel planning lounge with maps and itineraries', icon: 'fa-map-location-dot', grad: 'var(--gold-deep),var(--gold)', title: 'Travel Planning Lounge', sub: 'Sit down with a specialist and build your trip' },
];

export default function ContactGallery() {
  const [errored, setErrored] = useState({});

  return (
    <div className="sec">
      <div className="sec-head reveal">
        <p className="eyebrow" style={{ justifyContent: 'center' }}>Visit Us</p>
        <h2 className="sec-title">Step Into Our Travel Lounges</h2>
        <p className="sec-sub">Prefer talking face to face? Drop by in person — our Chennai care centre and partner desks are open for walk-in consultations.</p>
      </div>
      <div className="gallery-grid">
        {items.map((item, i) => (
          <div className="gallery-card reveal" key={item.img}>
            {!errored[i] ? (
              <img src={item.img} alt={item.alt} onError={() => setErrored((s) => ({ ...s, [i]: true }))} />
            ) : (
              <div className="gallery-placeholder" style={{ display: 'flex', background: `linear-gradient(135deg,${item.grad})` }}>
                <i className={`fa-solid ${item.icon}`} style={{ fontSize: 30 }}></i>
              </div>
            )}
            <div className="gallery-overlay">
              <div><span>{item.title}</span><small>{item.sub}</small></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}