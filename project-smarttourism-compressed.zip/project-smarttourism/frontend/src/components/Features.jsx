import { Zap, TrendingUp, Hotel, ShieldCheck, Headset, MapPin, Languages, Smartphone } from "lucide-react";

const features = [
  { color: "blue", Icon: Zap, title: "Instant Bookings", desc: "Confirm customer bookings in seconds with real-time availability checks across all your packages and hotels.", img: "https://picsum.photos/seed/instant-booking/320/180" },
  { color: "teal", Icon: TrendingUp, title: "Smart Analytics", desc: "Track revenue, booking trends, and customer behaviour with live dashboards built for travel operations.", img: "https://picsum.photos/seed/smart-analytics/320/180" },
  { color: "gold", Icon: Hotel, title: "Hotel Network", desc: "Manage partner hotels, room inventory, and pricing from a single unified interface — no spreadsheets needed.", img: "https://picsum.photos/seed/hotel-network/320/180" },
  { color: "green", Icon: ShieldCheck, title: "Secure Payments", desc: "Every transaction is tracked, reconciled, and stored securely so your accounts are always audit-ready.", img: "https://picsum.photos/seed/secure-payments/320/180" },
  { color: "purple", Icon: Headset, title: "24/7 Support", desc: "Our dedicated travel support team is available round the clock to assist customers and resolve issues fast.", img: "https://picsum.photos/seed/support-team/320/180" },
  { color: "red", Icon: MapPin, title: "Live Tracking", desc: "Monitor ongoing tours with live itinerary tracking so your team always knows where every group is.", img: "https://picsum.photos/seed/live-tracking/320/180" },
  { color: "teal", Icon: Languages, title: "Multi-Language", desc: "Serve international travellers in their native language with our built-in multilingual content support.", img: "https://picsum.photos/seed/multi-language/320/180" },
  { color: "gold", Icon: Smartphone, title: "Mobile-First", desc: "Fully responsive across all devices — your team and customers get a seamless experience on any screen.", img: "https://picsum.photos/seed/mobile-first/320/180" },
];

export default function Features() {
  return (
    <div className="features-section">
      <div className="features-inner">
        <p className="section-eyebrow">Why Choose Us</p>
        <h2 className="section-title">Everything You Need to Run Travel Operations</h2>
        <div className="features-grid">
          {features.map((f, i) => (
            <div className="feat-card" key={i}>
              <img src={f.img} alt="" className="feat-card-img" loading="lazy" />
              <div className={`feat-icon ${f.color}`}>
                <f.Icon size={17} strokeWidth={2.25} />
              </div>
              <div className="feat-title">{f.title}</div>
              <div className="feat-desc">{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}