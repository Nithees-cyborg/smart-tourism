import { useEffect, useState } from "react";
import { Users, MapPinned, CalendarCheck, Hotel, IndianRupee, X, TrendingUp } from "lucide-react";

// Formats a raw number/string into ₹ with Indian-style comma grouping,
// e.g. 1467800 -> "₹14,67,800". Falls back gracefully if the value isn't
// a clean number (keeps whatever was passed in, e.g. "—" while loading).
function formatRevenue(value) {
  const num = Number(String(value).replace(/,/g, ""));
  if (Number.isNaN(num)) return value;
  return `₹${num.toLocaleString("en-IN")}`;
}

export default function StatsCards({
  customerCount,
  packageCount,
  bookingCount,
  hotelCount,
  totalRevenue,
}) {
  const stats = [
    {
      color: "blue",
      Icon: Users,
      trend: "↑ 12%",
      value: customerCount,
      label: "Total Customers",
      detail: "Unique customers who have made at least one booking.",
      meta: [
        { label: "New this week", value: "+2" },
        { label: "Returning", value: "3" },
      ],
    },
    {
      color: "teal",
      Icon: MapPinned,
      trend: "↑ 4",
      value: packageCount,
      label: "Tour Packages",
      detail: "Active tour packages currently listed on the platform.",
      meta: [
        { label: "Most booked", value: "Goa Escape" },
        { label: "Added this month", value: "+4" },
      ],
    },
    {
      color: "gold",
      Icon: CalendarCheck,
      trend: "↑ 8%",
      value: bookingCount,
      label: "Total Bookings",
      detail: "All bookings placed across every package and hotel.",
      meta: [
        { label: "Confirmed", value: "41" },
        { label: "Pending", value: "6" },
      ],
    },
    {
      color: "green",
      Icon: Hotel,
      trend: "↑ 3",
      value: hotelCount,
      label: "Partner Hotels",
      detail: "Hotels currently partnered and available for booking.",
      meta: [
        { label: "New partners", value: "+3" },
        { label: "Avg. rating", value: "4.6★" },
      ],
    },
    {
      color: "purple",
      Icon: IndianRupee,
      trend: "↑ 18%",
      value: totalRevenue === "—" ? "—" : formatRevenue(totalRevenue),
      label: "Total Revenue",
      detail: "Gross revenue collected across all bookings to date.",
      meta: [
        { label: "This month", value: "₹18,40,000" },
        { label: "Last month", value: "₹15,60,000" },
      ],
    },
  ];

  // Index of the card currently expanded into the modal view, or null.
  const [expanded, setExpanded] = useState(null);

  // Close on Escape key, and lock body scroll while the modal is open.
  useEffect(() => {
    if (expanded === null) return;

    const onKeyDown = (e) => {
      if (e.key === "Escape") setExpanded(null);
    };
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = "";
    };
  }, [expanded]);

  const active = expanded !== null ? stats[expanded] : null;

  return (
    <div className="stats-section">
      <p className="section-eyebrow">Live Overview</p>
      <h2 className="section-title">Platform At a Glance</h2>

      <div className="stats-grid">
        {stats.map((s, i) => {
          // Length of the displayed string drives --num-len, which the
          // CSS uses to shrink font-size for long values (e.g. currency)
          // so they no longer overflow the card. Short values (e.g. "4",
          // "33") stay large since --num-len is small.
          const displayValue = s.value === "—" ? "—" : String(s.value);

          return (
            <button
              type="button"
              className={`stat-card stat-card--glass ${s.color}`}
              key={s.label}
              style={{ "--stat-i": i }}
              onClick={() => setExpanded(i)}
              aria-haspopup="dialog"
            >
              <div className="stat-card-glow" aria-hidden="true" />

              {/* Icon + trend badge share one row — keeps the trend pill
                  small and next to the icon instead of stretching full width */}
              <div className="stat-card-top">
                <div className="stat-icon">
                  <s.Icon size={18} strokeWidth={2.25} />
                </div>
                <span className="stat-trend">{s.trend}</span>
              </div>

              {/* Number + label pinned to the bottom so every card's number
                  sits on the same baseline regardless of card height */}
              <div className="stat-body">
                <div
                  className="stat-num"
                  style={{ "--num-len": displayValue.length }}
                >
                  {s.value === "—" ? <span className="stat-skel" /> : s.value}
                </div>
                <div className="stat-label">{s.label}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Expanded card modal — tap a stat to open, X or backdrop to close */}
      {active && (
        <div
          className="stat-modal-overlay"
          role="dialog"
          aria-modal="true"
          aria-label={`${active.label} details`}
          onClick={() => setExpanded(null)}
        >
          <div
            className={`stat-modal-card ${active.color}`}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              className="stat-modal-close"
              onClick={() => setExpanded(null)}
              aria-label="Close"
            >
              <X size={18} strokeWidth={2.25} />
            </button>

            <div className="stat-modal-icon">
              <active.Icon size={26} strokeWidth={2.25} />
            </div>

            <span className="stat-trend stat-modal-trend">
              <TrendingUp size={12} strokeWidth={2.5} />
              {active.trend}
            </span>

            <div className="stat-modal-num">{active.value}</div>
            <div className="stat-modal-label">{active.label}</div>

            {active.detail && <p className="stat-modal-detail">{active.detail}</p>}

            {active.meta && active.meta.length > 0 && (
              <div className="stat-modal-meta">
                {active.meta.map((m) => (
                  <div className="stat-modal-meta-row" key={m.label}>
                    <span className="stat-modal-meta-label">{m.label}</span>
                    <span className="stat-modal-meta-value">{m.value}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}