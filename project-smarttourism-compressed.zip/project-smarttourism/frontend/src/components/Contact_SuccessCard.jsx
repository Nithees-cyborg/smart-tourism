import React from "react";

/**
 * Contact_SuccessCard.jsx
 * The 3-step "what happens next" grid + response-time chip + CTA buttons.
 * Paste into: src/components/Contact_SuccessCard.jsx
 */
export default function Contact_SuccessCard() {
  const steps = [
    {
      icon: "fa-solid fa-envelope-circle-check",
      title: "We review it",
      text: "A specialist reads through your request, usually within a few hours.",
    },
    {
      icon: "fa-solid fa-headset",
      title: "We reach out",
      text: "Expect a reply by email or phone within 24 hours.",
    },
    {
      icon: "fa-solid fa-route",
      title: "We help you plan",
      text: "From there, we'll tailor recommendations to your trip.",
    },
  ];

  return (
    <>
      <div className="cs-steps">
        {steps.map((step) => (
          <div className="cs-step" key={step.title}>
            <div className="cs-step-icon">
              <i className={step.icon}></i>
            </div>
            <h4>{step.title}</h4>
            <p>{step.text}</p>
          </div>
        ))}
      </div>

      <div className="cs-response-chip">
        <i className="fa-regular fa-clock"></i> Typically replies within 24 hours
      </div>

      <div className="cs-cta-row">
        <a href="/" className="cs-btn-primary-cta">
          Return to Dashboard <i className="fa-solid fa-arrow-right"></i>
        </a>
        <a href="/packages/" className="cs-btn-secondary-cta">
          Browse Packages
        </a>
      </div>
    </>
  );
}