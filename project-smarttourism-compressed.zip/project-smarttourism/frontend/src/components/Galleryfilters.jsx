import React from 'react';

const categories = [
  { name: 'all', label: 'All', count: 30 },
  { name: 'Architecture', label: 'Architecture', count: 5 },
  { name: 'Landscapes', label: 'Landscapes', count: 5 },
  { name: 'Culture', label: 'Culture', count: 5 },
  { name: 'Cuisine', label: 'Cuisine', count: 5 },
  { name: 'Lifestyle', label: 'Lifestyle', count: 5 },
  { name: 'Details', label: 'Details', count: 5 },
];

const Galleryfilters = ({
  currentCategory,
  setCurrentCategory,
  favoritesOnly,
  setFavoritesOnly,
  favCount,
}) => {
  return (
    <div className="gallery-controls">
      <div className="filter-pills">
        {categories.map((cat) => (
          <button
            key={cat.name}
            className={`filter-pill ${currentCategory === cat.name ? 'active' : ''}`}
            onClick={() => setCurrentCategory(cat.name)}
          >
            {cat.label} <span>({cat.count})</span>
          </button>
        ))}
      </div>
      <button
        className={`favorites-toggle ${favoritesOnly ? 'active' : ''}`}
        onClick={() => setFavoritesOnly((f) => !f)}
      >
        <i className={favoritesOnly ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}></i>
        Favorites <span>({favCount})</span>
      </button>
    </div>
  );
};

export default Galleryfilters;