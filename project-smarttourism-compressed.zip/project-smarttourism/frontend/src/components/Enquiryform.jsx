import { useState } from "react";

export default function EnquiryForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    destination: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Enquiry submitted:", form);
    setSubmitted(true);
    setForm({ name: "", email: "", phone: "", destination: "", message: "" });
  };

  return (
    <div className="sec">
      <div className="sec-head reveal">
        <div className="sec-eye">Plan With Us</div>
        <h2 className="sec-title">Send Us an Enquiry</h2>
        <p className="sec-sub">Tell us about your dream trip — our travel experts will get back to you within 24 hours.</p>
      </div>

      <div className="enquiry-wrap reveal">
        <form className="enquiry-form" onSubmit={handleSubmit}>
          <div className="enquiry-row">
            <div className="enquiry-field">
              <label htmlFor="enq-name">Full Name</label>
              <div className="s-input-row">
                <i className="fa-solid fa-user"></i>
                <input id="enq-name" type="text" name="name" placeholder="Your full name" value={form.name} onChange={handleChange} required />
              </div>
            </div>

            <div className="enquiry-field">
              <label htmlFor="enq-email">Email Address</label>
              <div className="s-input-row">
                <i className="fa-solid fa-envelope"></i>
                <input id="enq-email" type="email" name="email" placeholder="you@example.com" value={form.email} onChange={handleChange} required />
              </div>
            </div>
          </div>

          <div className="enquiry-row">
            <div className="enquiry-field">
              <label htmlFor="enq-phone">Phone Number</label>
              <div className="s-input-row">
                <i className="fa-solid fa-phone"></i>
                <input id="enq-phone" type="tel" name="phone" placeholder="+91 98765 43210" value={form.phone} onChange={handleChange} required />
              </div>
            </div>

            <div className="enquiry-field">
              <label htmlFor="enq-dest">Preferred Destination</label>
              <div className="s-input-row">
                <i className="fa-solid fa-location-dot"></i>
                <input id="enq-dest" type="text" name="destination" placeholder="e.g. Goa, Dubai, Maldives…" value={form.destination} onChange={handleChange} />
              </div>
            </div>
          </div>

          <div className="enquiry-field full">
            <label htmlFor="enq-message">Message</label>
            <textarea
              id="enq-message"
              name="message"
              rows="4"
              placeholder="Tell us about your travel dates, group size, and what you're looking for…"
              value={form.message}
              onChange={handleChange}
            ></textarea>
          </div>

          <button type="submit" className="s-btn enquiry-submit">
            <i className="fa-solid fa-paper-plane"></i> Submit Enquiry
          </button>

          {submitted && (
            <div className="enquiry-success">
              <i className="fa-solid fa-circle-check"></i> Thanks! Your enquiry has been received — we'll be in touch shortly.
            </div>
          )}
        </form>
      </div>
    </div>
  );
}