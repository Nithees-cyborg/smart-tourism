import React from "react";
import logo from "/logo.png"; // adjust this path to wherever you place logo.png

// Top navigation bar shown on the booking success page
export default function SuccessNavbar() {
  return (
    <nav className="navbar">
      <div className="nav-brand">
        <div className="nav-logo">
          <img src={logo} alt="Global Smart Tourism" className="nav-logo-img" />
        </div>
        <h2>Global Smart Tourism</h2>
      </div>
      <div className="nav-status">✅ Booking Confirmed</div>
    </nav>
  );
}