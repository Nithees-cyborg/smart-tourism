import React from 'react';
import { useNavigate } from 'react-router-dom';

const Gallerynavbar = () => {
  const navigate = useNavigate();

  return (
    <nav className="navbar">
      <button
        onClick={() => navigate(-1)}
        aria-label="Go back"
        className="nav-back-btn"
      >
        <i className="fa-solid fa-arrow-left"></i>
      </button>

      <a href="/" className="brand">
        <img
          src="/images/logo.png"
          alt="Global Smart Tourism Logo"
          className="brand-logo"
          onError={(e) => {
            e.target.style.display = 'none';
            e.target.nextElementSibling.style.display = 'flex';
          }}
        />
        <div className="brand-icon"><i className="fa-solid fa-earth-asia"></i></div>
        <span className="brand-name">Global <em>Smart</em> Tourism</span>
      </a>
      <ul>
        <li><a href="/dashboard">Dashboard</a></li>
        <li><a href="/packages/">Packages</a></li>
        <li><a href="/gallery/" className="active">Gallery</a></li>
        <li><a href="/about/">About</a></li>
        <li><a href="/contact/">Contact</a></li>
        <li><a href="/services/">Services</a></li>
      </ul>
    </nav>
  );
};

export default Gallerynavbar;