import React, { useState, useEffect, useRef } from 'react';

const showcaseSlides = [
  { src: '/images/gallery1.jpg', category: 'Architecture' },
  { src: '/images/gallery6.jpg', category: 'Details' },
  { src: '/images/gallery11.jpg', category: 'Lifestyle' },
  { src: '/images/gallery16.jpg', category: 'Cuisine' },
  { src: '/images/gallery21.jpg', category: 'Culture' },
  { src: '/images/gallery26.jpg', category: 'Landscapes' },
];

const Galleryshowcase = () => {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const timerRef = useRef(null);

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) setPlaying(false);
  }, []);

  useEffect(() => {
    clearInterval(timerRef.current);
    if (!playing) return;
    timerRef.current = setInterval(() => {
      setIndex((prev) => (prev + 1) % showcaseSlides.length);
    }, 4500);
    return () => clearInterval(timerRef.current);
  }, [playing]);

  const goToSlide = (i) => {
    setIndex(i);
    setPlaying(false);
  };

  const togglePlay = () => setPlaying((p) => !p);

  const handleMouseEnter = () => clearInterval(timerRef.current);
  const handleMouseLeave = () => {
    if (playing) {
      timerRef.current = setInterval(() => {
        setIndex((prev) => (prev + 1) % showcaseSlides.length);
      }, 4500);
    }
  };

  return (
    <section
      className="showcase"
      aria-label="Featured shots"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {showcaseSlides.map((slide, i) => (
        <div
          key={i}
          className={`showcase-slide ${i === index ? 'active' : ''}`}
          style={{ backgroundImage: `url(${slide.src})` }}
        />
      ))}
      <div className="showcase-overlay">
        <span className="showcase-eyebrow">Featured Shot</span>
        <h3 className="showcase-caption">{showcaseSlides[index].category}</h3>
      </div>
      <div className="showcase-controls">
        <button
          className="showcase-pause"
          onClick={togglePlay}
          aria-label={playing ? 'Pause slideshow' : 'Play slideshow'}
        >
          <i className={`fa-solid ${playing ? 'fa-pause' : 'fa-play'}`}></i>
        </button>
        <div className="showcase-dots">
          {showcaseSlides.map((_, i) => (
            <button
              key={i}
              className={`showcase-dot ${i === index ? 'active' : ''}`}
              onClick={() => goToSlide(i)}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Galleryshowcase;