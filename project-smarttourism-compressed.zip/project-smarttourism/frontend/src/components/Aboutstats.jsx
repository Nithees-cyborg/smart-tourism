import { useEffect, useRef, useState } from "react";

const STAMPS = [
  { icon: "fa-users", target: 50000, suffix: "+", label: "Travellers Served" },
  { icon: "fa-suitcase-rolling", target: 120, suffix: "+", label: "Destinations" },
  { icon: "fa-earth-americas", target: 40, suffix: "+", label: "Countries Covered" },
  { icon: "fa-hotel", target: 400, suffix: "+", label: "Partner Hotels & Guides" },
  { icon: "fa-star", target: 4.9, suffix: "★", decimals: 1, label: "Average Rating" },
  { icon: "fa-award", target: 14, suffix: "+", label: "Years of Trust" },
];

const TIMELINE_COL1 = [
  { year: 2012, title: "Founded in Mumbai", desc: "Two travel enthusiasts launch GST with a focus on curated India packages — Kerala, Rajasthan, and Goa. The first 200 bookings are handled personally." },
  { year: 2014, title: "International Expansion", desc: "We open our Dubai and Maldives desk, partnering with 40+ overseas hotels. International revenue overtakes domestic for the first time." },
  { year: 2017, title: "10,000 Travellers Milestone", desc: "GST crosses 10,000 happy travellers and launches a 24/7 support hotline — a promise, not a feature." },
];

const TIMELINE_COL2 = [
  { year: 2019, title: "Smart Platform Launch", desc: "Our online booking platform goes live, making it possible to book, customise, and manage entire trips from a single dashboard." },
  { year: 2021, title: "Eco-Certified Portfolio", desc: "100% of our hotel partners earn eco-certification, and carbon-offset travel becomes standard across every package." },
  { year: 2026, title: "50K+ Travellers & Counting", desc: "We celebrate 50,000 trips completed with a 4.9-star average rating — and a team of 80 specialists spread across three offices." },
];

function useCountUp(ref) {
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (!ref.current || !("IntersectionObserver" in window)) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            setStarted(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, [ref, started]);

  return started;
}

function Stamp({ icon, target, suffix, decimals = 0, label, started }) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!started) return;
    const duration = 1600;
    const start = performance.now();
    let raf;
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(target * eased);
      if (progress < 1) raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, target]);

  return (
    <div className="stamp reveal">
      <div className="stamp-ring"><i className={`fa-solid ${icon}`}></i></div>
      <div className="stamp-num">{value.toFixed(decimals) + suffix}</div>
      <p>{label}</p>
    </div>
  );
}

export function Aboutstats() {
  const sectionRef = useRef(null);
  const started = useCountUp(sectionRef);

  return (
    <div className="stats-bg" ref={sectionRef}>
      <div className="sec on-dark">
        <div className="sec-head reveal">
          <p className="eyebrow on-dark">By the Numbers</p>
          <h2 className="sec-title">A Decade of Journeys, Stamped One Trip at a Time</h2>
          <p className="sec-sub">Every stamp below represents a real itinerary, not a vanity metric.</p>
        </div>
        <div className="stamp-grid">
          {STAMPS.map((s) => (
            <Stamp key={s.label} {...s} started={started} />
          ))}
        </div>
      </div>
    </div>
  );
}

export function Aboutjourney() {
  return (
    <div className="journey-bg">
      <div className="sec on-dark">
        <div className="sec-head reveal">
          <p className="eyebrow on-dark">Our Journey</p>
          <h2 className="sec-title">14 Years of Building Trust</h2>
          <p className="sec-sub">Every milestone reflects a lesson learned and a traveller served.</p>
        </div>
        <div className="timeline-cols">
          <div className="timeline reveal">
            {TIMELINE_COL1.map((t) => (
              <div className="tl-item" key={t.year}>
                <div className="tl-year">{t.year}</div>
                <div className="tl-title">{t.title}</div>
                <div className="tl-desc">{t.desc}</div>
              </div>
            ))}
          </div>
          <div className="timeline reveal">
            {TIMELINE_COL2.map((t) => (
              <div className="tl-item" key={t.year}>
                <div className="tl-year">{t.year}</div>
                <div className="tl-title">{t.title}</div>
                <div className="tl-desc">{t.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Aboutstats;