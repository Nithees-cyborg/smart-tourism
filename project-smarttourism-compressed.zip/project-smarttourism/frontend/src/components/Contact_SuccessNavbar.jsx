import React from "react";

/**
 * Contact_SuccessNavbar.jsx
 * Top-left floating brand mark (logo + name).
 * Paste into: src/components/Contact_SuccessNavbar.jsx
 */
export default function Contact_SuccessNavbar() {
  return (
    <a href="/" className="cs-brand-mark">
      <img
        src="/images/logo.png"
        alt="Global Smart Tourism Logo"
        className="cs-brand-mark-logo"
        onError={(e) => {
          e.currentTarget.style.display = "none";
          e.currentTarget.nextElementSibling.style.display = "flex";
        }}
      />
      <div className="cs-brand-mark-icon">
        <i className="fa-solid fa-earth-asia"></i>
      </div>
      <span className="cs-brand-mark-name">
        Global <em>Smart</em> Tourism
      </span>
    </a>
  );
}