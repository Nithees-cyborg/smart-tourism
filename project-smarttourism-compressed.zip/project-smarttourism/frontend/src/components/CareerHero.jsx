import React from "react";
import careerImg from "/career.jpg";

export default function CareerHero() {
  return (
    <section
      className="career-hero"
      style={{
        backgroundImage: `linear-gradient(175deg, rgba(16,45,89,0.90) 0%, rgba(8,18,38,0.95) 100%), url(${careerImg})`,
      }}
    >
      <div className="career-hero-inner">
        <p className="eyebrow on-dark">We're Hiring</p>
        <h1>
          Build Journeys. <em>Grow Your Career.</em>
        </h1>
        <p>
          Join the team behind Global Smart Tourism's bookings, itineraries,
          and on-the-ground travel experiences. We're a small, fast-moving
          crew that ships often and travels more than most travel agencies.
        </p>
        <div className="career-hero-actions">
          <a href="#openings" className="btn-primary">
            View Open Roles <i className="fa-solid fa-arrow-down"></i>
          </a>
          <a href="#culture" className="btn-ghost">
            Life at GST
          </a>
        </div>

        <div className="career-hero-stats">
          <div className="stat">
            <span className="stat-num">38+</span>
            <span className="stat-label">Team Members</span>
          </div>
          <div className="stat">
            <span className="stat-num">3</span>
            <span className="stat-label">Office Hubs</span>
          </div>
          <div className="stat">
            <span className="stat-num">12</span>
            <span className="stat-label">Countries Served</span>
          </div>
          <div className="stat">
            <span className="stat-num">4.7★</span>
            <span className="stat-label">Team Satisfaction</span>
          </div>
        </div>
      </div>
    </section>
  );
}