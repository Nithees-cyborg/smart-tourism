import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Aboutnavbar() {
  const [scrolled, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeDrawer = () => setDrawerOpen(false);

  return (
    <>
      <nav className={`navbar${scrolled ? " scrolled" : ""}`} id="navbar">
        <button
          className="nav-back-btn"
          aria-label="Go back"
          onClick={() => navigate(-1)}
        >
          <i className="fa-solid fa-arrow-left"></i>
        </button>

        <a href="/" className="brand">
          <img
            src="/images/logo.png"
            alt="Global Smart Tourism logo"
            onError={(e) => {
              e.target.style.display = "none";
              e.target.nextElementSibling.style.display = "flex";
            }}
          />
          <div className="brand-mark">
            <i className="fa-solid fa-route"></i>
          </div>
          <span className="brand-name">
            Global <em>Smart</em> Tourism
          </span>
        </a>

        <div className="nav-links">
          <a href="/">Home</a>
          <a href="/dashboard/">Dashboard</a>
          <a href="/gallery/">Gallery</a>
          <a href="/about/" className="active">About</a>
          <a href="/contact/">Contact</a>
          <a href="/login/">Login</a>
          <a href="/signup/" className="cta-pill">Get Started</a>
        </div>

        <button
          className={`nav-toggle${drawerOpen ? " open" : ""}`}
          aria-label="Toggle menu"
          aria-expanded={drawerOpen}
          aria-controls="navDrawer"
          onClick={() => setDrawerOpen((o) => !o)}
        >
          <span></span><span></span><span></span>
        </button>
      </nav>

      <div className={`scrim${drawerOpen ? " show" : ""}`} onClick={closeDrawer}></div>

      <div className={`nav-drawer${drawerOpen ? " open" : ""}`} id="navDrawer">
        <a href="/" onClick={closeDrawer}>Home</a>
        <a href="/about/" className="active" onClick={closeDrawer}>About</a>
        <a href="/contact/" onClick={closeDrawer}>Contact</a>
        <a href="/login/" onClick={closeDrawer}>Login</a>
        <a href="/signup/" className="cta-pill" onClick={closeDrawer}>Get Started</a>
      </div>
    </>
  );
}