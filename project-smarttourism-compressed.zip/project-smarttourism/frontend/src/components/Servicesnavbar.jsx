import { useNavigate } from "react-router-dom";
import logo from "../assets/images/logo.png";

function Servicesnavbar() {
  const navigate = useNavigate();

  return (
    <nav className="svc-navbar">
      <button
        className="svc-back-btn"
        aria-label="Go back"
        onClick={() => navigate(-1)}
      >
        <i className="fa-solid fa-arrow-left"></i>
      </button>

      <div className="svc-logo">
        <img src={logo} alt="Global Smart Tourism logo" />
        <h2>Global Smart Tourism</h2>
      </div>

      <ul className="svc-nav-links">
        <li><a href="/">Home</a></li>
        <li><a href="/dashboard/">Dashboard</a></li>
        <li><a href="/packages/">Destinations</a></li>
        <li><a href="/services/" className="active">Services</a></li>
        <li><a href="/about/">About</a></li>
        <li><a href="/contact/">Contact</a></li>
      </ul>
    </nav>
  );
}

export default Servicesnavbar;