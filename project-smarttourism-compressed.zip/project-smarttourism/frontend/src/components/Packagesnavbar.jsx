import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function Packagesnavbar({ theme, toggleTheme }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const navStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "18px 6vw",
    borderBottom: "1px solid var(--line)",
    position: "sticky",
    top: 0,
    background: "var(--paper)",
    zIndex: 50,
  };

  return (
    <header style={navStyle}>
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        {/* Back button — returns to the previous page */}
        <button
          onClick={() => navigate(-1)}
          aria-label="Go back"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: "1px solid var(--line-strong)",
            background: "transparent",
            borderRadius: 999,
            width: 38,
            height: 38,
            cursor: "pointer",
            color: "var(--ink)",
            flexShrink: 0,
          }}
        >
          <ArrowLeft size={18} />
        </button>

        {/* Logo — icon (public/logo.png) + wordmark */}
        <a
          href="#"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            textDecoration: "none",
          }}
        >
          <img
            src="/logo.png"
            alt="Global Smart Tourism"
            style={{
              width: 40,
              height: 40,
              borderRadius: 10,
              objectFit: "cover",
              flexShrink: 0,
            }}
          />

          <span
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: 21,
              letterSpacing: "-0.01em",
              lineHeight: 1.1,
            }}
          >
            <span style={{ color: "var(--ink)" }}>Global Smart </span>
            <span style={{ color: "var(--gold-deep)" }}>Tourism</span>
          </span>
        </a>
      </div>

      <nav
        style={{
          display: open ? "flex" : "none",
          gap: 28,
          alignItems: "center",
        }}
        className="pkg-nav-links"
      >
        <a href="#packages" style={{ color: "var(--ink-soft)", textDecoration: "none", fontWeight: 600, fontSize: 14 }}>
          Packages
        </a>
        <a href="#why-us" style={{ color: "var(--ink-soft)", textDecoration: "none", fontWeight: 600, fontSize: 14 }}>
          Why Us
        </a>
        <a href="#contact" style={{ color: "var(--ink-soft)", textDecoration: "none", fontWeight: 600, fontSize: 14 }}>
          Contact
        </a>
      </nav>

      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <button
          onClick={toggleTheme}
          aria-label="Toggle theme"
          style={{
            border: "1px solid var(--line-strong)",
            background: "transparent",
            borderRadius: 999,
            width: 38,
            height: 38,
            cursor: "pointer",
            color: "var(--ink)",
            fontSize: 16,
          }}
        >
          {theme === "dark" ? "☀️" : "🌙"}
        </button>
        <button
          className="pkg-nav-toggle"
          onClick={() => setOpen((o) => !o)}
          style={{
            display: "none",
            border: "none",
            background: "none",
            fontSize: 22,
            color: "var(--ink)",
            cursor: "pointer",
          }}
        >
          ☰
        </button>
      </div>
    </header>
  );
}