import React from "react";

export default function HotelCard({ hotel, onClick }) {
  const singleRoom = hotel.rooms.find((r) => r.id === "single");

  return (
    <div className="hotel-box" onClick={() => onClick(hotel)}>
      <div className="hotel-cover">
        <img src={hotel.images[0]} alt={hotel.name} loading="lazy" />
        <span className="photo-count-badge">
          <i className="fa-solid fa-images"></i> {hotel.images.length}
        </span>
      </div>
      <div className="hotel-content">
        <div>
          <div className="hotel-meta-top">
            <span className="hotel-id">{hotel.code}</span>
            <span className="rating-badge">
              <i className="fa-solid fa-star"></i> {hotel.rating}
            </span>
          </div>
          <h3 className="hotel-name">{hotel.name}</h3>
          <div className="hotel-location">
            <i className="fa-solid fa-location-dot"></i> {hotel.location}
          </div>
          <p className="hotel-desc">{hotel.desc}</p>
        </div>
        <div className="hotel-pricing-footer">
          <div className="price-group">
            <span className="price-label">Avg. per night (2 guests)</span>
            <div className="price-value">
              ₹{hotel.price.toLocaleString("en-IN")}
              <span className="price-unit">/night</span>
            </div>
            {singleRoom && (
              <span className="price-single-note">
                Solo from ₹{singleRoom.pricePerNight.toLocaleString("en-IN")}/night
              </span>
            )}
          </div>
          <button className="btn-card-action" title="View Details">
            <i className="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
}