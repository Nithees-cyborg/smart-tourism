const VALUES = [
  { cls: "c1", icon: "fa-person-circle-check", title: "Traveller First, Always", desc: "Every decision — from hotel selection to itinerary timing — starts with what the traveller actually wants here." },
  { cls: "c2", icon: "fa-star-half-stroke", title: "Honest Over Impressive", desc: "We tell you what a place is really like — the crowds, the seasons, the trade-offs — before you book, not after you arrive." },
  { cls: "c3", icon: "fa-earth-asia", title: "Leave It Better", desc: "We invest in local communities and offset every tour's carbon footprint. Travel should be a force for good in the places we love." },
  { cls: "c4", icon: "fa-headset", title: "Available, Always", desc: "Things go wrong. Flights get cancelled. We have a real human on call at 3am — not a chatbot — because that's when it matters most." },
  { cls: "c5", icon: "fa-sliders", title: "Your Trip, Your Rules", desc: "No two travellers are the same. We build flexible itineraries that can change, because life doesn't always follow a booking confirmation." },
  { cls: "c6", icon: "fa-lock", title: "Price You Can Trust", desc: "No hidden fees, no bait-and-switch pricing. What you see is what you pay — and if you find it cheaper, we'll match it." },
];

const WHY = [
  { icon: "fa-hotel", title: "Luxury Hotels", desc: "Stay in premium hotels and resorts at the best available rates, hand-checked by our team." },
  { icon: "fa-plane", title: "Flight Booking", desc: "Book domestic and international flights quickly, with real support if your plans change." },
  { icon: "fa-earth-americas", title: "Worldwide Tours", desc: "Explore 40+ countries with itineraries designed by people who've actually been there." },
  { icon: "fa-headset", title: "24×7 Support", desc: "Dedicated support before, during, and after your trip — every hour, every time zone." },
  { icon: "fa-shield-halved", title: "Secure Booking", desc: "Safe payment gateways with instant confirmation, so you know it's locked in." },
  { icon: "fa-money-bill-wave", title: "Honest Pricing", desc: "Premium travel experiences without hidden fees eating into your budget." },
];

export function Aboutvalues() {
  return (
    <div className="sec">
      <div className="values-intro reveal">
        <p className="eyebrow" style={{ justifyContent: "center" }}>What Drives Us</p>
        <h2 className="sec-title">The Values We Travel By</h2>
        <p>
          Our vision is simple: become the tourism partner people trust before they've even picked a
          destination. The values below are how we make that real — they're not mission-statement
          words, they're the rules our team operates by every day.
        </p>
      </div>
      <div className="values-grid">
        {VALUES.map((v) => (
          <div className={`value-card ${v.cls} reveal`} key={v.title}>
            <div className="value-icon"><i className={`fa-solid ${v.icon}`}></i></div>
            <div className="value-title">{v.title}</div>
            <div className="value-desc">{v.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Aboutwhyus() {
  return (
    <div className="why-bg">
      <div className="sec">
        <div className="sec-head reveal">
          <p className="eyebrow" style={{ justifyContent: "center" }}>Why Choose Us</p>
          <h2 className="sec-title">Everything Handled, By People Who Actually Travel</h2>
          <p className="sec-sub">From the first search to the final landing, here's what's included with every booking.</p>
        </div>
        <div className="why-grid">
          {WHY.map((w) => (
            <div className="why-card reveal" key={w.title}>
              <i className={`fa-solid ${w.icon}`}></i>
              <h3>{w.title}</h3>
              <p>{w.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Aboutvalues;