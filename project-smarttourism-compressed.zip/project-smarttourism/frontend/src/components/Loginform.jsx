import { useState } from "react";

const STRENGTH_LEVELS = [
  { pct: "20%", color: "#ef4444", label: "Very weak" },
  { pct: "40%", color: "#f97316", label: "Weak" },
  { pct: "65%", color: "#eab308", label: "Fair" },
  { pct: "85%", color: "#22c55e", label: "Strong" },
  { pct: "100%", color: "#16a34a", label: "Very strong" },
];

function getStrength(value) {
  let score = 0;
  if (value.length >= 8) score++;
  if (value.length >= 12) score++;
  if (/[A-Z]/.test(value)) score++;
  if (/[0-9]/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;
  return STRENGTH_LEVELS[Math.min(score, 4)];
}

/**
 * Loginform.jsx
 * The actual <form>: username, password (with show/hide + strength meter),
 * remember me, forgot password link, submit button with ripple + spinner.
 *
 * Props:
 *  - onSubmit(e, { username, password, remember }) — called on submit
 *  - isSubmitting: bool — shows spinner instead of button text
 *  - csrfToken: string — optional Django CSRF token to embed as hidden input
 */
export default function Loginform({ onSubmit, isSubmitting = false, csrfToken }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const [ripples, setRipples] = useState([]);

  const strength = password ? getStrength(password) : null;

  const handleRipple = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const id = Date.now();
    setRipples((prev) => [
      ...prev,
      {
        id,
        size,
        left: e.clientX - rect.left - size / 2,
        top: e.clientY - rect.top - size / 2,
      },
    ]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 650);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    onSubmit?.(e, { username, password, remember });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {csrfToken && <input type="hidden" name="csrfmiddlewaretoken" value={csrfToken} />}

      {/* Username */}
      <div className="field-group">
        <label className="field-label" htmlFor="username">
          Username
        </label>
        <div className={`field-wrap ${focusedField === "username" ? "focused" : ""}`}>
          <span className="field-icon">
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
            </svg>
          </span>
          <input
            className="field-input"
            type="text"
            id="username"
            name="username"
            placeholder="Enter your username"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onFocus={() => setFocusedField("username")}
            onBlur={() => setFocusedField(null)}
            required
          />
        </div>
      </div>

      {/* Password */}
      <div className="field-group">
        <label className="field-label" htmlFor="password">
          Password
        </label>
        <div className={`field-wrap ${focusedField === "password" ? "focused" : ""}`}>
          <span className="field-icon">
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <rect x="3" y="11" width="18" height="11" rx="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </span>
          <input
            className="field-input"
            type={showPassword ? "text" : "password"}
            id="password"
            name="password"
            placeholder="Enter your password"
            autoComplete="current-password"
            style={{ paddingRight: 44 }}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onFocus={() => setFocusedField("password")}
            onBlur={() => setFocusedField(null)}
            required
          />
          <button
            className="toggle-pass"
            type="button"
            aria-label="Toggle password visibility"
            onClick={() => setShowPassword((s) => !s)}
          >
            {showPassword ? "🙈" : "👁"}
          </button>
        </div>

        {password && strength && (
          <>
            <div className="strength-bar">
              <div
                className="strength-fill"
                style={{ width: strength.pct, background: strength.color }}
              />
            </div>
            <div className="strength-label" style={{ color: strength.color }}>
              {strength.label}
            </div>
          </>
        )}
      </div>

      {/* Remember + Forgot */}
      <div className="options-row">
        <label className="remember-check">
          <input
            type="checkbox"
            name="remember"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
          />
          Remember me
        </label>
        <a href="/forgot-password/" className="forgot-link">
          Forgot password?
        </a>
      </div>

      {/* Submit */}
      <button className="btn-login" type="submit" onClick={handleRipple} disabled={isSubmitting}>
        {isSubmitting ? <div className="spinner" /> : <span>Sign in</span>}
        {ripples.map((r) => (
          <span
            key={r.id}
            className="ripple"
            style={{ width: r.size, height: r.size, left: r.left, top: r.top }}
          />
        ))}
      </button>
    </form>
  );
}