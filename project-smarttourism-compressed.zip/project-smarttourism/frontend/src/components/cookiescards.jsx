import React from "react";

const STATUS_CARDS = [
  {
    key: "functionality",
    icon: "fa-sliders",
    title: "Functionality",
    desc: "Remembers settings like your preferred language, currency, and recently viewed destinations.",
  },
  {
    key: "measurement",
    icon: "fa-chart-line",
    title: "Measurement",
    desc: "Helps us understand which pages and packages get used, so we can fix issues and improve the experience.",
  },
  {
    key: "marketing",
    icon: "fa-bullhorn",
    title: "Marketing",
    desc: "Used to show you relevant offers on this site and others, based on the destinations you've shown interest in.",
  },
  {
    key: "experience",
    icon: "fa-wand-magic-sparkles",
    title: "Experience",
    desc: "Personalizes recommendations and layout based on how you browse, without identifying you individually.",
  },
];

export default function CookiesCards({ consent }) {
  return (
    <div className="policy-section" id="categories">
      <div className="policy-section-icon">
        <i className="fa-solid fa-layer-group"></i>
      </div>
      <h2>Cookie Categories</h2>
      <p>
        Here's exactly what each category does. You can switch any of the
        optional ones on or off from the preference panel.
      </p>

      <div className="cat-grid">
        <div className="cat-card">
          <div className="cat-card-top">
            <div className="cat-card-icon">
              <i className="fa-solid fa-shield-halved"></i>
            </div>
            <span className="always-badge">Always Active</span>
          </div>
          <h3>Essential</h3>
          <p>
            Required for core features like login, navigation, and secure
            checkout. The site can't run properly without these.
          </p>
        </div>

        {STATUS_CARDS.map(({ key, icon, title, desc }) => {
          const on = !!consent[key];
          return (
            <div className="cat-card" key={key}>
              <div className="cat-card-top">
                <div className="cat-card-icon">
                  <i className={`fa-solid ${icon}`}></i>
                </div>
                <span
                  className={`status-pill ${on ? "status-on" : "status-off"}`}
                >
                  {on ? "Currently: On" : "Currently: Off"}
                </span>
              </div>
              <h3>{title}</h3>
              <p>{desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
