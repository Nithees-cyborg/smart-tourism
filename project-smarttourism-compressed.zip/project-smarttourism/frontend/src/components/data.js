// ── Images live in the /public folder (e.g. public/images/dubai.jpg)
// Since they're in `public`, they're served as static files — reference by
// URL path (starting with "/"), do NOT import them like a module.

const dubaiImg    = "/images/dubai.jpg";
const goaImg      = "/images/goa.jpg";
const maldivesImg = "/images/maldives.jpg";
const keralaImg   = "/images/kerala.jpg";
const parisImg    = "/images/paris.jpg";
const kenyaImg    = "/images/kenya.jpg";

export const SLIDES = [
  {
    img: dubaiImg,
    eyebrow: "Architectural Marvels",
    h1: ["Live Life at", "Peak ", "Luxury"],
    p: "World-record towers, desert safaris, and rooftop infinity pools — Dubai redefines what travel can be.",
    icon: "fa-city",
    label: "Explore Dubai",
  },
  {
    img: goaImg,
    eyebrow: "Vibrant Shorelines",
    h1: ["Sun, Sand &", "", "Coastal", " Nights"],
    p: "Golden beaches by day, vibrant beach shacks and live music by night — Goa never stops.",
    icon: "fa-umbrella-beach",
    label: "Explore Goa",
  },
  {
    img: maldivesImg,
    eyebrow: "Overwater Escapes",
    h1: ["Float Above", "", "Paradise"],
    p: "Turquoise lagoons, private overwater villas, and sunsets made for two — the Maldives is barefoot luxury at its purest.",
    icon: "fa-water",
    label: "Explore Maldives",
  },
  {
    img: keralaImg,
    eyebrow: "Serene Backwaters",
    h1: ["Connect Deeply", "With ", "Pristine", " Nature"],
    p: "Drift through tropical backwater passages on private houseboats — jungle, silence, and stars overhead.",
    icon: "fa-map-location-dot",
    label: "Explore Kerala",
  },
  {
    img: parisImg,
    eyebrow: "Timeless Romance",
    h1: ["Fall In Love", "With ", "Paris"],
    p: "Cobblestone cafés, candlelit Seine cruises, and the Eiffel Tower at golden hour — Paris writes its own love story.",
    icon: "fa-landmark",
    label: "Explore Paris",
  },
  {
    img: kenyaImg,
    eyebrow: "Timeless Adventure",
    h1: ["Adventures", "In", "Kenya"],
    p: "Nature Views, WildLife Adventures, Jungle Safari - See wild Animals, Enjoy Your Trip.",
    icon: "fa-landmark",
    label: "Explore Kenya",
  },
];

export const DESTINATIONS = [
  { img: keralaImg,   tag: "Nature",   name: "Kerala",   sub: "Backwaters · Hills · Ayurveda", price: "From ₹28K", big: true },
  { img: goaImg,      tag: "Beach",    name: "Goa",      price: "From ₹18K" },
  { img: maldivesImg, tag: "Island",   name: "Maldives", price: "From ₹95K" },
  { img: kenyaImg,    tag: "Safari",   name: "Kenya",    price: "From ₹65K" },
  { img: dubaiImg,    tag: "Luxury",   name: "Dubai",    price: "From ₹55K" },
];

export const TOURS = [
  { img: goaImg,      name: "Goa Beach Getaway",   price: "₹18,999",   days: "4 Days", rating: "4.8", chip: { icon: "fa-users",        label: "Any group" } },
  { img: dubaiImg,    name: "Dubai Luxury Tour",    price: "₹85,000",   days: "5 Days", rating: "4.9", chip: { icon: "fa-gem",          label: "Luxury" } },
  { img: maldivesImg, name: "Maldives Escape",      price: "₹1,10,000", days: "7 Days", rating: "5.0", chip: { icon: "fa-heart",        label: "Honeymoon" } },
  { img: keralaImg,   name: "Kerala Backwaters",    price: "₹32,000",   days: "6 Days", rating: "4.7", chip: { icon: "fa-leaf",         label: "Nature" } },
];

export const FEATURES = [
  { color: "blue",   icon: "fa-bolt",            title: "Instant Confirmations",  desc: "Book your trip and get a confirmed itinerary and hotel vouchers within minutes — no waiting, no uncertainty." },
  { color: "gold",   icon: "fa-hotel",           title: "Handpicked Hotels",      desc: "Every property in our network is personally vetted for quality, cleanliness, and guest experience." },
  { color: "teal",   icon: "fa-shield-halved",   title: "Secure Payments",        desc: "Fully encrypted transactions across all major cards and UPI. Your money is protected every step of the way." },
  { color: "green",  icon: "fa-headset",         title: "24/7 Travel Support",    desc: "Our team is on call round the clock — whether you need directions, rebooking, or just a local tip." },
  { color: "purple", icon: "fa-map-location-dot",title: "Custom Itineraries",     desc: "Tell us what you love — beaches, history, food — and we'll build a bespoke plan around you." },
  { color: "red",    icon: "fa-percent",         title: "Best Price Guarantee",   desc: "Find the same trip cheaper elsewhere and we'll match it. Premium experience shouldn't cost more." },
];

export const TESTIMONIALS = [
  { letter: "R", grad: "linear-gradient(135deg,#1559c2,#3b82f6)", name: "Rahul Mehta",      loc: "Mumbai, India",    text: "The Dubai package was absolutely flawless. Every hotel, transfer, and activity was perfectly arranged. I didn't have to think about a single thing." },
  { letter: "P", grad: "linear-gradient(135deg,#0d9488,#14b8a6)", name: "Priya Nair",       loc: "Bangalore, India", text: "Kerala was a dream. The houseboat stay, the spice gardens, the Ayurvedic spa — curated beautifully. We'll be back next year without question." },
  { letter: "A", grad: "linear-gradient(135deg,#7c3aed,#a78bfa)", name: "Aakash & Sneha",  loc: "Delhi, India",     text: "Booked the Maldives escape for our honeymoon. The overwater villa, the snorkelling, the sunset dinner on the beach — every moment felt magical." },
];

export const INSPIRATION = [
  { img: keralaImg,   tag: "Nature & Wellness",  title: "7 Days in Kerala: Backwaters, Hills & Ayurveda",    excerpt: "A slow-travel route through houseboats, tea estates, and traditional spa towns — built for total reset." },
  { img: dubaiImg,    tag: "City & Luxury",      title: "Dubai After Dark: Skyline Views Worth the Trip",     excerpt: "From rooftop dinners to desert stargazing — how to spend an evening in the city that never dims." },
  { img: maldivesImg, tag: "Island & Romance",   title: "Why the Maldives Is the Ultimate Honeymoon",         excerpt: "Overwater villas, private sandbanks, and sunsets that do most of the talking for you." },
];

export const HOW_STEPS = [
  { num: "01", color: "blue",  icon: "fa-magnifying-glass", title: "Search a Destination",  desc: "Use our smart search to browse packages by destination, budget, or travel style." },
  { num: "02", color: "gold",  icon: "fa-list-check",       title: "Pick Your Package",     desc: "Choose from curated itineraries with hotels, transfers, and guided experiences included." },
  { num: "03", color: "teal",  icon: "fa-credit-card",      title: "Secure Your Booking",   desc: "Pay safely through our encrypted gateway. Instant confirmation sent to your email." },
  { num: "04", color: "green", icon: "fa-plane-departure",  title: "Pack & Travel",         desc: "Your itinerary, hotel vouchers, and 24/7 support — all ready before you leave home." },
];

export const FAQS = [
  { q: "How do I book a tour package?",        a: "Pick a package from our destinations or search results, choose your dates and travellers, then check out securely. You'll get an instant confirmation email with your itinerary and vouchers." },
  { q: "Can I customize my itinerary?",        a: "Absolutely. Every package can be adjusted — swap hotels, add activities, or extend your stay. Reach out to our travel experts after booking, or before, to build a fully bespoke plan." },
  { q: "What's your cancellation policy?",     a: "Most packages can be cancelled or rescheduled free of charge up to 7 days before departure. Exact terms vary by package and are always shown clearly at checkout." },
  { q: "Is payment on the site secure?",       a: "Yes — every transaction runs through an encrypted payment gateway supporting all major cards and UPI. We never store your full card details on our servers." },
  { q: "Can I add travel insurance?",          a: "Yes, optional travel insurance can be added at checkout for most packages, covering trip delays, medical emergencies, and baggage loss." },
  { q: "How do I reach support while travelling?", a: "Our support team is available 24/7 by phone, email, or live chat — whether you need a quick local tip or help rebooking on the road." },
];

export const MARQUEE_ITEMS = [
  { icon: "fa-shield-halved",   label: "Secure Encrypted Payments" },
  { icon: "fa-headset",         label: "24/7 Traveller Support" },
  { icon: "fa-hotel",           label: "Handpicked Verified Stays" },
  { icon: "fa-route",           label: "Custom-Built Itineraries" },
  { icon: "fa-percent",         label: "Best Price Guarantee" },
  { icon: "fa-calendar-days",   label: "Flexible Date Changes" },
  { icon: "fa-map-location-dot",label: "Local Destination Experts" },
];