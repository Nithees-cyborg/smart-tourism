import React from "react";
import PlacesCovered from "./PlacesCovered";

export default function PackageDetail({ pkg, onBack, onBookNow }) {
  if (!pkg) return null;

  return (
    <section className="pkg-section pkg-detail">
      <button className="pkg-back" onClick={onBack}>
        ← Back to all packages
      </button>

      <div className="pkg-hero-card">
        <img src={pkg.image} alt={pkg.destination} />
        <div className="pkg-hero-content">
          <div className="pkg-hero-code">
            {pkg.code} · {pkg.destination}
          </div>
          <h1>{pkg.package_name}</h1>
          <p>{pkg.tagline}</p>
        </div>
      </div>

      <div className="pkg-ticket">
        <div className="pkg-ticket-row">
          <div className="pkg-ticket-item">
            <span className="label">Duration</span>
            <span className="value">{pkg.duration}</span>
          </div>
          <div className="pkg-ticket-item">
            <span className="label">Rating</span>
            <span className="value">★ {pkg.rating}</span>
          </div>
          <div className="pkg-ticket-item">
            <span className="label">Traveler</span>
            <span className="value">1 Adult</span>
          </div>
          <div className="pkg-ticket-item">
            <span className="label">Price / person</span>
            <span className="value price">₹{pkg.price}</span>
          </div>
        </div>

        <div className="pkg-detail-body" style={{ padding: 0, gridTemplateColumns: "1fr", gap: 0 }}>
          <div className="pkg-detail-main" style={{ maxWidth: "100%" }}>
            <p className="pkg-overview">{pkg.overview || pkg.description}</p>
          </div>
        </div>
      </div>

      <div className="pkg-detail-body">
        <div className="pkg-detail-main">
          <h3>Day-by-day itinerary</h3>
          <ul className="pkg-itinerary">
            {pkg.itinerary?.map((step) => (
              <li key={step.day}>
                <span className="day-tag">Day {step.day}</span>
                <div className="day-title">{step.title}</div>
                <div className="day-detail">{step.detail}</div>
              </li>
            ))}
          </ul>

          <PlacesCovered
            places={pkg.placesCovered}
            destination={pkg.destination}
            transport={pkg.transport}
            inclusions={pkg.inclusions}
            onBookNow={onBookNow}
          />

          <h3>Transport</h3>
          <ul className="pkg-transport-list">
            {pkg.transport?.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        </div>

        <div className="pkg-detail-side">
          <h3>What's included</h3>
          <div className="pkg-list-box inclusions">
            <ul>
              {pkg.inclusions?.map((inc) => (
                <li key={inc}>{inc}</li>
              ))}
            </ul>
          </div>

          <h3>Not included</h3>
          <div className="pkg-list-box exclusions">
            <ul>
              {pkg.exclusions?.map((exc) => (
                <li key={exc}>{exc}</li>
              ))}
            </ul>
          </div>

          <div className="pkg-cta-box">
            <div className="best-time">Best time to visit: {pkg.bestTime}</div>
            {/*
              Book Now now goes to your in-between BookingOverview page
              instead of opening booking.com. If a parent passes onBookNow
              (Packages.jsx does, flipping its `stage` state to
              "overview"), that's called. Otherwise this falls back to the
              old booking.com search so the button never dead-ends.
            */}
            <button
              className="pkg-cta-btn pkg-cta-btn--book"
              onClick={() => {
                if (onBookNow) {
                  onBookNow();
                  return;
                }
                const query = encodeURIComponent(pkg.destination);
                window.open(
                  `https://www.booking.com/searchresults.html?ss=${query}`,
                  "_blank",
                  "noopener,noreferrer"
                );
              }}
            >
              Book Now — Find Hotels in {pkg.destination}
            </button>
            <button className="pkg-cta-btn">Enquire about this trip</button>
          </div>
        </div>
      </div>
    </section>
  );
}