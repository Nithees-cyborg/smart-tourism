import React, { useEffect, useRef, useState } from "react";

const SECTIONS = [
  { id: "intro", label: "1. Introduction" },
  { id: "collect", label: "2. Information We Collect" },
  { id: "use", label: "3. How We Use It" },
  { id: "cookies", label: "4. Cookies & Tracking" },
  { id: "sharing", label: "5. How We Share Data" },
  { id: "retention", label: "6. Data Retention" },
  { id: "rights", label: "7. Your Rights & Choices" },
  { id: "security", label: "8. Data Security" },
  { id: "children", label: "9. Children's Privacy" },
  { id: "transfers", label: "10. International Transfers" },
  { id: "changes", label: "11. Changes to This Policy" },
  { id: "contact", label: "12. Contact Us" },
];

export default function PrivacyContent() {
  const [activeId, setActiveId] = useState("intro");
  const sectionRefs = useRef({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "-40% 0px -50% 0px" }
    );

    Object.values(sectionRefs.current).forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const setRef = (id) => (el) => {
    sectionRefs.current[id] = el;
  };

  return (
    <div className="legal-shell">
      <aside className="legal-toc">
        <span className="legal-toc-label">On This Page</span>
        <ul id="tocList">
          {SECTIONS.map((s) => (
            <li key={s.id}>
              <a
                href={`#${s.id}`}
                className={activeId === s.id ? "active" : ""}
              >
                {s.label}
              </a>
            </li>
          ))}
        </ul>
      </aside>

      <main className="legal-content">
        <div className="legal-section" id="intro" ref={setRef("intro")}>
          <span className="legal-num">01</span>
          <h2>Introduction</h2>
          <p>
            Global Smart Tourism ("GST", "we", "us", or "our") provides
            travel booking, itinerary planning, and related tourism services
            through our website, mobile applications, and customer support
            channels (collectively, the "Services").
          </p>
          <p>
            This Privacy Policy describes how we collect, use, disclose, and
            safeguard your information when you use our Services. By
            creating an account, making a booking, or otherwise using GST,
            you agree to the practices described here. If you don't agree,
            please don't use the Services.
          </p>
        </div>

        <div className="legal-section" id="collect" ref={setRef("collect")}>
          <span className="legal-num">02</span>
          <h2>Information We Collect</h2>
          <p>
            We collect information in three ways: what you give us
            directly, what we gather automatically, and what we receive
            from travel partners involved in fulfilling your booking.
          </p>
          <table className="legal-table">
            <tbody>
              <tr>
                <th>Category</th>
                <th>Examples</th>
              </tr>
              <tr>
                <td>
                  <strong>Account &amp; Booking Details</strong>
                </td>
                <td>
                  Name, email, phone number, billing address, passport/ID
                  details where required for travel, payment information
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Travel Preferences</strong>
                </td>
                <td>
                  Destinations searched, saved itineraries, special
                  requests, accessibility needs, loyalty program numbers
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Device &amp; Usage Data</strong>
                </td>
                <td>
                  IP address, browser type, pages viewed, session duration,
                  referring URLs
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Communications</strong>
                </td>
                <td>
                  Support chats, emails, call recordings (with notice),
                  feedback and reviews
                </td>
              </tr>
              <tr>
                <td>
                  <strong>Partner-Supplied Data</strong>
                </td>
                <td>
                  Confirmation details from airlines, hotels, and local tour
                  operators tied to your booking
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="legal-section" id="use" ref={setRef("use")}>
          <span className="legal-num">03</span>
          <h2>How We Use Your Information</h2>
          <ul>
            <li>
              To process bookings, payments, and itinerary changes, and to
              confirm details with airlines, hotels, and partners on your
              behalf.
            </li>
            <li>
              To provide customer support before, during, and after your
              trip, including emergency assistance.
            </li>
            <li>
              To personalise recommendations, packages, and pricing based on
              your travel history and preferences.
            </li>
            <li>
              To send booking confirmations, itinerary updates, and
              service-related notices (these are not optional, since they
              relate to active bookings).
            </li>
            <li>
              To send marketing communications about offers and
              destinations — only with your consent, and you can opt out
              anytime.
            </li>
            <li>
              To detect fraud, secure our platform, and comply with legal
              and regulatory obligations, including aviation and tourism
              authority requirements.
            </li>
          </ul>
        </div>

        <div className="legal-section" id="cookies" ref={setRef("cookies")}>
          <span className="legal-num">04</span>
          <h2>Cookies &amp; Tracking Technologies</h2>
          <p>
            We use cookies and similar technologies to keep you logged in,
            remember your search filters, measure site performance, and
            understand which destinations and packages are most popular.
          </p>
          <ul>
            <li>
              <strong>Essential cookies</strong> — required for login,
              checkout, and core site functionality. These can't be
              disabled.
            </li>
            <li>
              <strong>Analytics cookies</strong> — help us understand usage
              patterns so we can improve the booking flow.
            </li>
            <li>
              <strong>Marketing cookies</strong> — used to show relevant
              offers on our site and occasionally on third-party platforms.
            </li>
          </ul>
          <p>
            You can manage cookie preferences through your browser settings
            at any time. Disabling non-essential cookies won't affect your
            ability to book, but may make the experience less personalised.
          </p>
        </div>

        <div className="legal-section" id="sharing" ref={setRef("sharing")}>
          <span className="legal-num">05</span>
          <h2>How We Share Your Information</h2>
          <p>
            We do not sell your personal information. We share it only
            where necessary to deliver your trip or run our business:
          </p>
          <ul>
            <li>
              <strong>Travel suppliers</strong> — airlines, hotels, car
              rentals, and local guides who need your details to fulfil a
              booking.
            </li>
            <li>
              <strong>Payment processors</strong> — to securely process
              transactions; we do not store full card numbers on our own
              servers.
            </li>
            <li>
              <strong>Service providers</strong> — for things like customer
              support tooling, email delivery, and IT infrastructure, under
              contracts that limit their use of your data.
            </li>
            <li>
              <strong>Legal &amp; safety</strong> — when required by law, by
              a valid legal process, or to protect the safety of travellers
              or staff.
            </li>
          </ul>
          <div className="legal-callout">
            <i className="fa-solid fa-circle-info"></i>
            We require every partner we share data with to handle it under
            terms at least as protective as this policy.
          </div>
        </div>

        <div className="legal-section" id="retention" ref={setRef("retention")}>
          <span className="legal-num">06</span>
          <h2>Data Retention</h2>
          <p>
            We retain booking and account information for as long as your
            account is active, and for a reasonable period afterward to
            meet accounting, tax, and travel-insurance recordkeeping
            obligations — typically up to 7 years for completed bookings.
            Marketing data is retained until you opt out or it becomes
            inactive for 24 months, whichever comes first.
          </p>
        </div>

        <div className="legal-section" id="rights" ref={setRef("rights")}>
          <span className="legal-num">07</span>
          <h2>Your Rights &amp; Choices</h2>
          <p>Depending on where you're located, you may have the right to:</p>
          <ul>
            <li>Access a copy of the personal information we hold about you.</li>
            <li>Correct inaccurate or outdated information in your account.</li>
            <li>
              Request deletion of your data, subject to legal retention
              requirements for completed bookings.
            </li>
            <li>
              Opt out of marketing emails at any time via the unsubscribe
              link or your account settings.
            </li>
            <li>Object to or restrict certain processing of your data.</li>
          </ul>
          <p>
            To exercise any of these rights, contact us using the details at
            the bottom of this page. We'll respond within 30 days.
          </p>
        </div>

        <div className="legal-section" id="security" ref={setRef("security")}>
          <span className="legal-num">08</span>
          <h2>Data Security</h2>
          <p>
            We use industry-standard safeguards — including encryption in
            transit, access controls, and regular security reviews — to
            protect your information. Payment processing is handled through
            PCI-DSS compliant gateways. That said, no system is perfectly
            secure, and we encourage you to use a strong, unique password
            for your GST account.
          </p>
        </div>

        <div className="legal-section" id="children" ref={setRef("children")}>
          <span className="legal-num">09</span>
          <h2>Children's Privacy</h2>
          <p>
            Our Services are intended for users aged 18 and older. We do not
            knowingly collect personal information directly from children.
            Information about minors travelling as part of a booking is
            collected only from the adult making that booking, for the
            purpose of fulfilling travel and accommodation requirements.
          </p>
        </div>

        <div className="legal-section" id="transfers" ref={setRef("transfers")}>
          <span className="legal-num">10</span>
          <h2>International Data Transfers</h2>
          <p>
            Because travel bookings often involve partners in other
            countries, your information may be transferred to and processed
            in locations outside your home country, including countries
            that may have different data protection laws. Where required,
            we use appropriate safeguards such as standard contractual
            clauses to protect data transferred internationally.
          </p>
        </div>

        <div className="legal-section" id="changes" ref={setRef("changes")}>
          <span className="legal-num">11</span>
          <h2>Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy from time to time to reflect
            changes in our practices or legal requirements. Material
            changes will be notified via email or a prominent notice on our
            site before they take effect. The "Last Updated" date at the
            top of this page always reflects the current version.
          </p>
        </div>

        <div className="legal-section" id="contact" ref={setRef("contact")}>
          <span className="legal-num">12</span>
          <h2>Contact Us</h2>
          <p>
            If you have questions about this Privacy Policy or how your
            data is handled, reach out to our privacy team directly:
          </p>
          <div className="legal-contact-box">
            <h3>Global Smart Tourism — Privacy Team</h3>
            <div className="footer-contact-item">
              <i className="fa-solid fa-envelope"></i> privacy@gst.com
            </div>
            <div className="footer-contact-item">
              <i className="fa-solid fa-phone"></i> +91 98765 43210
            </div>
            <div className="footer-contact-item">
              <i className="fa-solid fa-location-dot"></i> Mumbai &middot;
              Dubai &middot; Coimbatore
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}