import { FcGoogle } from "react-icons/fc";
import { FaWindows } from "react-icons/fa";
import '../components/Login.css';

export default function Loginsocial() {
  return (
    <>
      <div className="divider">
        <span>or continue with</span>
      </div>
    </>
  );
}