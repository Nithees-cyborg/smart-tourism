import React from "react";
import { Link, useNavigate } from "react-router-dom"; // remove Link import + swap Link->a if you're not using react-router

// "What happens next" card + the return-to-dashboard / download-invoice buttons
export default function SuccessNextSteps({ booking, payment }) {
  const navigate = useNavigate();

  return (
    <div className="card full" style={{ marginBottom: 30 }}>
      <div className="card-title">🗺 What happens next?</div>

      <div className="next-list">
        <div className="next-item">
          <div className="next-icon" style={{ background: "#dcfce7" }}>📧</div>
          <div className="next-text">
            <p>Confirmation email sent</p>
            <span>Full booking details have been sent to {booking.customer.email}.</span>
          </div>
        </div>

        <div className="next-item">
          <div className="next-icon" style={{ background: "#dbeafe" }}>📞</div>
          <div className="next-text">
            <p>Our team will call you</p>
            <span>
              A travel expert will contact you on {booking.customer.phone} within
              24 hours to finalize your itinerary.
            </span>
          </div>
        </div>

        <div className="next-item">
          <div className="next-icon" style={{ background: "#fef9c3" }}>🎒</div>
          <div className="next-text">
            <p>Prepare for {booking.package.destination}</p>
            <span>
              Check our travel guide for packing tips and local highlights for
              your destination.
            </span>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 20, flexWrap: "wrap" }}>
        <button
          className="btn-dashboard"
          style={{ background: "linear-gradient(135deg, #16a34a, #15803d)", flex: 1, border: "none", cursor: "pointer" }}
          onClick={() => navigate("/invoice", { state: { booking, payment } })}
        >
          ⬇ Download Invoice
        </button>

        <Link to="/dashboard" className="btn-dashboard" style={{ flex: 1 }}>
          Return to Dashboard
        </Link>
      </div>
    </div>
  );
}