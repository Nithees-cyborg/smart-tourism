import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "gst_cookie_consent";
const DEFAULTS = {
  essential: true,
  functionality: true,
  measurement: false,
  marketing: false,
  experience: true,
};

function loadConsent() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function persistConsent(partial) {
  const payload = {
    ...DEFAULTS,
    ...partial,
    essential: true,
    updatedAt: new Date().toISOString(),
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  return payload;
}

/**
 * Central hook for the cookie consent banner / modal / preference state.
 * Mirrors the vanilla-JS logic from the original cookies.html.
 */
export default function useCookieConsent() {
  const [consent, setConsent] = useState(DEFAULTS);
  const [bannerVisible, setBannerVisible] = useState(false);
  const [floatBtnVisible, setFloatBtnVisible] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const existing = loadConsent();
    if (existing) {
      setConsent(existing);
      setFloatBtnVisible(true);
    } else {
      setConsent(DEFAULTS);
      const timer = setTimeout(() => setBannerVisible(true), 700);
      return () => clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    if (!modalOpen) return;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [modalOpen]);

  useEffect(() => {
    if (!modalOpen) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") setModalOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [modalOpen]);

  const hideBanner = useCallback(() => {
    setBannerVisible(false);
    setFloatBtnVisible(true);
  }, []);

  const openModal = useCallback(() => setModalOpen(true), []);
  const closeModal = useCallback(() => setModalOpen(false), []);

  const acceptAllCookies = useCallback(() => {
    const state = persistConsent({
      functionality: true,
      measurement: true,
      marketing: true,
      experience: true,
    });
    setConsent(state);
    hideBanner();
    closeModal();
  }, [hideBanner, closeModal]);

  const rejectAllCookies = useCallback(() => {
    const state = persistConsent({
      functionality: false,
      measurement: false,
      marketing: false,
      experience: false,
    });
    setConsent(state);
    hideBanner();
    closeModal();
  }, [hideBanner, closeModal]);

  const savePreferences = useCallback(
    (draft) => {
      const state = persistConsent(draft);
      setConsent(state);
      hideBanner();
      closeModal();
    },
    [hideBanner, closeModal]
  );

  return {
    consent,
    bannerVisible,
    floatBtnVisible,
    modalOpen,
    openModal,
    closeModal,
    acceptAllCookies,
    rejectAllCookies,
    savePreferences,
  };
}
