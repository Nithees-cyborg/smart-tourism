import { useMemo } from "react";

/**
 * Loginbackground.jsx
 * Animated backdrop: gradient, grid, orbs, twinkling stars, floating particles.
 * Pure decoration — no props needed. Drop this once, near the top of Login.jsx.
 */
export default function Loginbackground() {
  const stars = useMemo(() => {
    return Array.from({ length: 60 }, (_, i) => {
      const size = 1 + Math.random() * 2.5;
      return {
        id: i,
        style: {
          width: size,
          height: size,
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
          animationDuration: `${2 + Math.random() * 4}s`,
          animationDelay: `${Math.random() * 5}s`,
        },
      };
    });
  }, []);

  const particles = useMemo(() => {
    const colors = ["#60a5fa", "#818cf8", "#a5b4fc", "#67e8f9", "#ffffff"];
    return Array.from({ length: 22 }, (_, i) => {
      const size = 3 + Math.random() * 10;
      return {
        id: i,
        style: {
          width: size,
          height: size,
          left: `${Math.random() * 100}%`,
          bottom: `-${Math.random() * 60}px`,
          background: colors[Math.floor(Math.random() * colors.length)],
          animationDuration: `${10 + Math.random() * 15}s`,
          animationDelay: `${Math.random() * 12}s`,
          opacity: 0.12,
        },
      };
    });
  }, []);

  return (
    <>
      <div className="login-bg-gradient" />
      <div className="login-bg-grid" />

      <div className="stars">
        {stars.map((s) => (
          <div key={s.id} className="star" style={s.style} />
        ))}
      </div>

      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />
      <div className="orb orb-4" />

      <div className="particles">
        {particles.map((p) => (
          <div key={p.id} className="particle" style={p.style} />
        ))}
      </div>
    </>
  );
}