import { useState, useEffect } from 'react';

export default function ContactNavbar() {
  const [scrolled, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [theme, setTheme] = useState('light');
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('theme');
    const preferred = saved || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    setTheme(preferred);
    document.documentElement.setAttribute('data-theme', preferred);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
  };

  const closeDrawer = () => setDrawerOpen(false);

  const links = [
    { href: '/', label: 'Home' },
    { href: '/packages/', label: 'Packages' },
    { href: '/about/', label: 'About' },
    { href: '/contact/', label: 'Contact', active: true },
    { href: '/login/', label: 'Login' },
  ];

  return (
    <>
      <nav className={`navbar${scrolled ? ' scrolled' : ''}`} id="navbar">
        <a href="/" className="brand">
          {!logoError ? (
            <img src="/images/logo.png" alt="Global Smart Tourism logo" onError={() => setLogoError(true)} />
          ) : (
            <div className="brand-mark" style={{ display: 'flex' }}>
              <i className="fa-solid fa-route"></i>
            </div>
          )}
          <span className="brand-name">Global <em>Smart</em> Tourism</span>
        </a>

        <div className="nav-links">
          {links.map((l) => (
            <a key={l.href} href={l.href} className={l.active ? 'active' : ''}>{l.label}</a>
          ))}
          <a href="/signup/" className="cta-pill">Get Started</a>
          <button className="theme-toggle" onClick={toggleTheme} aria-label="Toggle dark mode">
            <i className="fa-solid fa-moon"></i>
            <i className="fa-solid fa-sun"></i>
          </button>
        </div>

        <button
          className={`nav-toggle${drawerOpen ? ' open' : ''}`}
          aria-label="Toggle menu"
          aria-expanded={drawerOpen}
          aria-controls="navDrawer"
          onClick={() => setDrawerOpen((o) => !o)}
        >
          <span></span><span></span><span></span>
        </button>
      </nav>

      <div className={`scrim${drawerOpen ? ' show' : ''}`} onClick={closeDrawer}></div>

      <div className={`nav-drawer${drawerOpen ? ' open' : ''}`} id="navDrawer">
        {links.map((l) => (
          <a key={l.href} href={l.href} className={l.active ? 'active' : ''} onClick={closeDrawer}>{l.label}</a>
        ))}
        <a href="/signup/" className="cta-pill" onClick={closeDrawer}>Get Started</a>
        <button className="nav-drawer-theme" onClick={toggleTheme} aria-label="Toggle dark mode">
          <span className="label"><i className="fa-solid fa-moon"></i> Dark Mode</span>
          <span className="switch-track"><span className="switch-thumb"></span></span>
        </button>
      </div>
    </>
  );
}