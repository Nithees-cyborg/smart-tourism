const BASE = "http://localhost:8000/api/dashboard";

async function getJSON(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request failed: ${path}`);
  return res.json();
}

export const fetchStats = () => getJSON("/stats/");
export const fetchDestinations = () => getJSON("/destinations/");
export const fetchTopPackages = () => getJSON("/packages/top/");
export const fetchActivity = () => getJSON("/activity/");
export const fetchRevenueSplit = () => getJSON("/revenue-split/");
export const fetchTestimonials = () => getJSON("/testimonials/");

export async function subscribeNewsletter(email) {
  const res = await fetch(`${BASE}/newsletter/subscribe/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Subscription failed.");
  return data;
}