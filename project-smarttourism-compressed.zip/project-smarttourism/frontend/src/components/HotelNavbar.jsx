import React from "react";
import logo from "../assets/logo.png"; // adjust path to wherever your logo actually lives

export default function HotelNavbar() {
  const [imgFailed, setImgFailed] = React.useState(false);

  const toggleTheme = () => {
    const html = document.documentElement;
    const current = html.getAttribute("data-theme");
    html.setAttribute("data-theme", current === "light" ? "dark" : "light");
  };

  const goBack = (e) => {
    e.preventDefault();
    // If this tab has history to go back to, use it.
    // Otherwise (e.g. opened fresh in a new tab), fall back to home.
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = "/";
    }
  };

  return (
    <nav className="navbar" id="navbar">
      <button
        type="button"
        className="back-btn"
        aria-label="Go back to previous page"
        onClick={goBack}
      >
        <i className="fa-solid fa-arrow-left"></i>
      </button>

      <a href="/" className="brand">
        {!imgFailed ? (
          <img
            src={logo}
            alt="Global Smart Tourism Logo"
            className="brand-logo"
            onError={() => setImgFailed(true)}
          />
        ) : (
          <div className="brand-icon" style={{ display: "flex" }}>
            <i className="fa-solid fa-earth-asia"></i>
          </div>
        )}
        <span className="brand-name">
          Global <em>Smart</em> Tourism
        </span>
      </a>
      <ul>
        <li><a href="/dashboard/">Dashboard</a></li>
        <li><a href="/packages/">Packages</a></li>
        <li><a href="/gallery/">Gallery</a></li>
        <li><a href="/hotels/" className="active">Hotels</a></li>
        <li>
          <button
            className="theme-toggle-btn"
            aria-label="Toggle dark mode"
            onClick={toggleTheme}
          >
            <i className="fa-solid fa-moon"></i>
          </button>
        </li>
      </ul>
    </nav>
  );
}