import React from "react";

export default function CookiesHero({ onManagePreferences }) {
  return (
    <section className="hero">
      <span className="hero-eyebrow">Privacy &amp; Transparency</span>
      <h1 className="hero-title">
        We use cookies &mdash; <em>here's exactly why</em>, and how to
        control them.
      </h1>
      <p className="hero-subtitle">
        This page explains what cookies Global Smart Tourism uses, what each
        category does, and how you can switch any of it on or off at any
        time.
      </p>
      <div className="hero-cta">
        <button className="btn-hero-primary" onClick={onManagePreferences}>
          <i className="fa-solid fa-sliders"></i> Manage Preferences
        </button>
        <a href="#what-are-cookies" className="btn-hero-secondary">
          Read the Policy
        </a>
      </div>
      <div className="hero-trust">
        <span>
          <i className="fa-solid fa-circle-check"></i> GDPR &amp; CCPA aware
        </span>
        <span>
          <i className="fa-solid fa-circle-check"></i> You're always in
          control
        </span>
        <span>
          <i className="fa-solid fa-circle-check"></i> Last updated June 2026
        </span>
      </div>
    </section>
  );
}
