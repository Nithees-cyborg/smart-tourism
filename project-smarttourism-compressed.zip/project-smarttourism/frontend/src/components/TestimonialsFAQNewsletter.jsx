import { useEffect, useRef, useState } from "react";
import { TESTIMONIALS, FAQS } from "./data";

export function Testimonials() {
  return (
    <div className="testi-bg">
      <div className="sec">
        <div className="sec-head reveal">
          <div className="sec-eye">Traveller Stories</div>
          <h2 className="sec-title">What Our Guests Say</h2>
          <p className="sec-sub">Real words from real travellers — unfiltered and unedited.</p>
        </div>
        <div className="testi-grid">
          {TESTIMONIALS.map((t, i) => (
            <div key={i} className="testi reveal" style={{ transitionDelay: `${i * 80}ms` }}>
              <div className="testi-stars">★★★★★</div>
              <div className="testi-quote">{t.text}</div>
              <div className="testi-person">
                <div className="testi-av" style={{ background: t.grad }}>{t.letter}</div>
                <div>
                  <div className="testi-name">{t.name}</div>
                  <div className="testi-loc"><i className="fa-solid fa-location-dot" style={{ color: "var(--ocean)", fontSize: "10px" }}></i> {t.loc}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function FAQ() {
  const [open, setOpen] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const ansRefs = useRef([]);
  const sectionRef = useRef(null);

  const toggle = (i) => setOpen((prev) => (prev === i ? null : i));

  useEffect(() => {
    ansRefs.current.forEach((el, i) => {
      if (!el) return;
      el.style.maxHeight = open === i ? el.scrollHeight + "px" : "0px";
    });
  }, [open]);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) {
          setRevealed(true);
          obs.unobserve(e.target);
        }
      }),
      { threshold: 0.15 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div className="sec">
      <div className={`sec-head reveal${revealed ? " in-view" : ""}`} ref={sectionRef}>
        <div className="sec-eye">Got Questions?</div>
        <h2 className="sec-title">Frequently Asked Questions</h2>
        <p className="sec-sub">Everything you need to know before you book.</p>
      </div>
      <div className="faq-list">
        {FAQS.map((faq, i) => (
          <div key={i} className={`faq-item reveal in-view${open === i ? " open" : ""}`}>
            <button className="faq-q" onClick={() => toggle(i)}>
              {faq.q} <i className="fa-solid fa-plus"></i>
            </button>
            <div className="faq-a" ref={(el) => { ansRefs.current[i] = el; }}>
              <div className="faq-a-inner">{faq.a}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Newsletter() {
  const [email, setEmail] = useState("");
  return (
    <div className="nl-wrap">
      <div className="nl-inner reveal">
        <div className="sec-eye">Stay in the Loop</div>
        <h2 className="sec-title">Get Exclusive Travel Deals</h2>
        <p className="sec-sub">Early access to new packages, seasonal discounts, and insider destination guides — straight to your inbox.</p>
        <div className="nl-form">
          <input
            type="email"
            placeholder="Your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button type="button"><i className="fa-solid fa-paper-plane"></i> Subscribe</button>
        </div>
      </div>
    </div>
  );
}