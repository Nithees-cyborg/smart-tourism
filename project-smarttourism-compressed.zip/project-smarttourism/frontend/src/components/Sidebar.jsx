import { useEffect, useRef, useState } from "react";
import Chart from "chart.js/auto";
import { IndianRupee, CalendarCheck, UserPlus, AlertTriangle, ArrowRight } from "lucide-react";
import { fetchActivity, fetchTopPackages, fetchRevenueSplit } from "../components/DashboardApi";

const ICONS = { booking: CalendarCheck, payment: IndianRupee, customer: UserPlus, alert: AlertTriangle };

function ActivityText({ text }) {
  const words = text.split(" ");
  const lead = words.slice(0, 2).join(" ");
  const rest = words.slice(2).join(" ");
  return (
    <p>
      <strong>{lead}</strong> {rest}
    </p>
  );
}

function DonutChart({ confirmed, pending, cancelled }) {
  const canvasRef = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (chartRef.current) chartRef.current.destroy();
    chartRef.current = new Chart(canvasRef.current, {
      type: "doughnut",
      data: {
        labels: ["Confirmed", "Pending", "Cancelled"],
        datasets: [{ data: [confirmed, pending, cancelled], backgroundColor: ["#10b981", "#f59e0b", "#ef4444"], borderWidth: 0 }],
      },
      options: { responsive: true, maintainAspectRatio: false, cutout: "72%", plugins: { legend: { display: false } } },
    });
    return () => chartRef.current && chartRef.current.destroy();
  }, [confirmed, pending, cancelled]);

  return <canvas ref={canvasRef}></canvas>;
}

export default function Sidebar({ totalRevenue, bookingCount }) {
  const [revenueBars, setRevenueBars] = useState([]);
  const [activity, setActivity] = useState([]);
  const [topPackages, setTopPackages] = useState([]);

  useEffect(() => {
    let alive = true;
    fetchRevenueSplit().then((d) => alive && setRevenueBars(d));
    fetchActivity().then((d) => alive && setActivity(d));
    fetchTopPackages().then((d) => alive && setTopPackages(d));
    return () => {
      alive = false;
    };
  }, []);

  return (
    <>
      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Revenue Split</h3>
        </div>
        <div className="rev-widget">
          <div className="rev-total">₹{totalRevenue}</div>
          <div className="rev-label">Total platform revenue</div>
          <div className="rev-bar-wrap">
            {revenueBars.map((b) => (
              <div className="rev-bar-row" key={b.id}>
                <div className="rev-bar-top">
                  <span className="rev-bar-dest">{b.destination}</span>
                  <span className="rev-bar-pct">{b.pct}%</span>
                </div>
                <div className="rev-bar-track">
                  <div
                    className="rev-bar-fill"
                    style={{ width: `${b.pct}%`, background: `linear-gradient(90deg, ${b.color_start}, ${b.color_end})` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Recent Activity</h3>
        </div>
        <div className="activity-list">
          {activity.map((a) => {
            const Icon = ICONS[a.type] || CalendarCheck;
            return (
              <div className="activity-item" key={a.id}>
                <div className={`act-dot ${a.type}`}>
                  <Icon size={14} strokeWidth={2.25} />
                </div>
                <div className="act-text">
                  <ActivityText text={a.text} />
                  <div className="act-time">{a.time_ago}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Top Packages</h3>
          <a href="/packages/">
            All <ArrowRight size={13} strokeWidth={2.5} />
          </a>
        </div>
        <div className="top-pkg-list">
          {topPackages.map((p) => (
            <div className="top-pkg-item" key={p.id}>
              <div className="pkg-rank">{p.rank}</div>
              <img className="pkg-thumb" src={p.image} alt={p.name} loading="lazy" />
              <div className="pkg-info">
                <div className="pkg-info-name">{p.name}</div>
                <div className="pkg-info-sub">{p.sub}</div>
              </div>
              <div className="pkg-price">{p.price}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Booking Status</h3>
        </div>
        <div style={{ padding: "20px 24px 24px", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
          <div style={{ width: 160, height: 160, position: "relative" }}>
            <DonutChart confirmed={68} pending={24} cancelled={8} />
            <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", textAlign: "center", pointerEvents: "none" }}>
              <div style={{ fontFamily: "'Fraunces',serif", fontSize: 22, fontWeight: 600, color: "var(--heading)" }}>
                {bookingCount}
              </div>
              <div style={{ fontSize: 10, color: "var(--muted)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>
                Total
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center" }}>
            <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: "var(--green)", display: "inline-block" }}></span>
              Confirmed
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: "var(--amber-status)", display: "inline-block" }}></span>
              Pending
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: "var(--red)", display: "inline-block" }}></span>
              Cancelled
            </span>
          </div>
        </div>
      </div>
    </>
  );
}