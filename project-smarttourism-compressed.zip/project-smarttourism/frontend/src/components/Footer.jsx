import { useEffect, useState } from "react";

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer-top">
        <div className="footer-brand">
          <h3>Global <em>Smart</em> Tourism</h3>
          <p>Premium travel operations and destination management — delivering unforgettable global experiences since 2012.</p>
          <div className="socials">
            {[
              { icon: "fa-facebook-f",  href: "https://facebook.com",  label: "Facebook" },
              { icon: "fa-instagram",   href: "https://instagram.com", label: "Instagram" },
              { icon: "fa-x-twitter",   href: "https://x.com",         label: "X" },
              { icon: "fa-linkedin-in", href: "https://linkedin.com",  label: "LinkedIn" },
              { icon: "fa-youtube",     href: "https://youtube.com",   label: "YouTube" },
            ].map((s) => (
              <a key={s.label} href={s.href} className="soc-btn" target="_blank" rel="noopener noreferrer" aria-label={s.label}>
                <i className={`fa-brands ${s.icon}`}></i>
              </a>
            ))}
          </div>
        </div>
        <div className="footer-col">
          <h4>Explore</h4>
          <ul>
            {[["Tour Packages","/packages"],["Partner Hotels","/hotels"],["My Bookings","/bookings"],["Gallery","/gallery"],["About Us","/about"]].map(([lbl,href]) => (
              <li key={lbl}><a href={href}>{lbl}</a></li>
            ))}
          </ul>
        </div>
        <div className="footer-col">
          <h4>Destinations</h4>
          <ul>
            {["Goa","Kerala","Dubai","Maldives","Paris"].map((d) => (
              <li key={d}><a href="/packages">{d}</a></li>
            ))}
          </ul>
        </div>
        <div className="footer-col">
          <h4>Contact Us</h4>
          {[
            { icon: "fa-envelope",    text: "support@gst.com" },
            { icon: "fa-phone",       text: "+91 9876 543 210" },
            { icon: "fa-location-dot",text: "Mumbai, India" },
            { icon: "fa-clock",       text: "Mon–Sat, 9am–7pm" },
          ].map((c) => (
            <div key={c.text} className="footer-contact-item">
              <i className={`fa-solid ${c.icon}`}></i> {c.text}
            </div>
          ))}
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 Global Smart Tourism. All Rights Reserved.</span>
        <div className="footer-legal">
          <a href="/Privacy">Privacy Policy</a>
          <a href="/Terms">Terms of Use</a>
          <a href="/cookies">Cookies</a>
        </div>
      </div>
    </footer>
  );
}

export function ScrollProgress() {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const handler = () => {
      const docH = document.documentElement.scrollHeight - window.innerHeight;
      setPct(docH > 0 ? (window.scrollY / docH) * 100 : 0);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return <div className="scroll-progress" style={{ width: pct + "%" }}></div>;
}

export function ToTopBtn() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const handler = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return (
    <button
      className={`to-top-btn${show ? " show" : ""}`}
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
    >
      <i className="fa-solid fa-arrow-up"></i>
    </button>
  );
}