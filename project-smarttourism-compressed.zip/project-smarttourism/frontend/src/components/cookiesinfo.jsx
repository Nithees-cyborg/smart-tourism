import React from "react";

export default function CookiesInfo() {
  return (
    <>
      <div className="policy-section" id="what-are-cookies">
        <div className="policy-section-icon">
          <i className="fa-solid fa-cookie-bite"></i>
        </div>
        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a
          website. They allow us to remember your preferences, keep you
          logged in between visits, and understand how our site is used
          &mdash; so we can make Global Smart Tourism faster, safer, and more
          relevant to you.
        </p>
        <p>
          Cookies don't let us access your device or files; they simply
          store small pieces of information tied to your browser.
        </p>
      </div>

      <div className="policy-section">
        <div className="policy-section-icon">
          <i className="fa-solid fa-circle-question"></i>
        </div>
        <h2>Why We Use Them</h2>
        <p>
          We rely on cookies for four broad purposes: keeping the site
          functional, remembering your choices, understanding how people use
          the platform, and &mdash; only with your consent &mdash; showing
          you more relevant offers and content.
        </p>
      </div>
    </>
  );
}
