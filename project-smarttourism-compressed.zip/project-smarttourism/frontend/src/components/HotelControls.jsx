import React from "react";

export default function HotelControls({
  searchTerm,
  onSearchChange,
  sortOrder,
  onSortChange,
  priceFilter,
  onPriceChange,
}) {
  return (
    <div className="controls-panel">
      <div className="search-wrapper">
        <i className="fa-solid fa-magnifying-glass"></i>
        <input
          type="text"
          id="searchInput"
          className="search-input"
          placeholder="Search hotels by name or destination..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>

      <select
        className="filter-select"
        id="sortSelect"
        value={sortOrder}
        onChange={(e) => onSortChange(e.target.value)}
      >
        <option value="">Sort by Rating</option>
        <option value="high">Highest First</option>
        <option value="low">Lowest First</option>
      </select>

      <select
        className="filter-select"
        id="priceSelect"
        value={priceFilter}
        onChange={(e) => onPriceChange(e.target.value)}
      >
        <option value="">Price Range</option>
        <option value="budget">Budget (under ₹35,000)</option>
        <option value="luxury">Luxury (₹35,000+)</option>
      </select>

      <button className="btn-primary">
        <i className="fa-solid fa-plus"></i> Add New Hotel
      </button>
    </div>
  );
}