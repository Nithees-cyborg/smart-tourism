import { useState } from "react";
import {
  LayoutDashboard,
  Package,
  Building2,
  Info,
  Briefcase,
  Settings,
  LogOut,
  ChevronsLeft,
  ChevronsRight,
  Sun,
  Moon,
} from "lucide-react";

const NAV_ITEMS = [
  { key: "overview", label: "Overview", href: "/", icon: LayoutDashboard },
  { key: "packages", label: "Packages", href: "/packages/", icon: Package },
  { key: "gallery", label: "gallery", href: "/gallery/", icon: Building2 },
  { key: "about", label: "About", href: "/about/", icon: Info },
  { key: "contact", label: "contact", href: "/contact/", icon: Building2 },
  { key: "services", label: "Services", href: "/services/", icon: Briefcase },
];

const SETTINGS_ITEM = { key: "settings", label: "Settings", href: "/settings/", icon: Settings };

export default function Navbar({ currentPath, onNavigate = () => {}, onLogout, theme = "light", onToggleTheme = () => {} }) {
  const [collapsed, setCollapsed] = useState(false);

  const path =
    currentPath ?? (typeof window !== "undefined" ? window.location.pathname : "/");

  const isActive = (href) => (href === "/" ? path === "/" : path.startsWith(href));

  const handleLogout = () => {
    try {
      localStorage.removeItem("authToken");
      sessionStorage.clear();
    } catch {
      // storage may be unavailable (SSR, privacy mode) — safe to ignore
    }
    if (onLogout) onLogout();
    window.location.href = "/";
  };

  return (
    <aside className={`dash-nav ${collapsed ? "is-collapsed" : ""}`}>
      <a href="/" className="dash-nav__brand">
        <span className="dash-nav__mark">
          <img src="/logo.png" alt="Global Smart Tourism" className="dash-nav__logo-img" />
        </span>
        {!collapsed && (
          <span className="dash-nav__brand-text">Global Smart Tourism</span>
        )}
      </a>

      <nav className="dash-nav__route" aria-label="Primary">
        {NAV_ITEMS.map(({ key, label, href, icon: Icon }, i) => (
          <a
            key={key}
            href={href}
            className={`dash-nav__stop ${isActive(href) ? "is-active" : ""}`}
            onClick={() => onNavigate(key)}
            style={{ "--stop-index": i }}
            title={collapsed ? label : undefined}
            aria-current={isActive(href) ? "page" : undefined}
          >
            <span className="dash-nav__dot">
              <Icon size={18} strokeWidth={2.25} />
            </span>
            {!collapsed && <span className="dash-nav__label">{label}</span>}
          </a>
        ))}
      </nav>

      <div className="dash-nav__footer">
        <a
          href={SETTINGS_ITEM.href}
          className={`dash-nav__stop ${isActive(SETTINGS_ITEM.href) ? "is-active" : ""}`}
          onClick={() => onNavigate(SETTINGS_ITEM.key)}
          title={collapsed ? SETTINGS_ITEM.label : undefined}
        >
          <span className="dash-nav__dot">
            <Settings size={18} strokeWidth={2.25} />
          </span>
          {!collapsed && <span className="dash-nav__label">Settings</span>}
        </a>

        <button
          className="dash-nav__stop dash-nav__theme"
          onClick={onToggleTheme}
          title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          aria-label="Toggle color theme"
        >
          <span className="dash-nav__dot">
            {theme === "dark" ? <Sun size={18} strokeWidth={2.25} /> : <Moon size={18} strokeWidth={2.25} />}
          </span>
          {!collapsed && (
            <span className="dash-nav__label">{theme === "dark" ? "Light mode" : "Dark mode"}</span>
          )}
        </button>

        <button
          className="dash-nav__stop dash-nav__logout"
          onClick={handleLogout}
          title={collapsed ? "Logout" : undefined}
        >
          <span className="dash-nav__dot">
            <LogOut size={18} strokeWidth={2.25} />
          </span>
          {!collapsed && <span className="dash-nav__label">Logout</span>}
        </button>

        <button
          className="dash-nav__collapse"
          onClick={() => setCollapsed((c) => !c)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </div>
    </aside>
  );
}