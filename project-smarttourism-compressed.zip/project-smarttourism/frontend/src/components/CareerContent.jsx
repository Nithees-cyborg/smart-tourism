import React, { useMemo, useState } from "react";

const PERKS = [
  {
    icon: "fa-plane",
    title: "Travel Credits",
    desc: "Annual travel allowance to explore the destinations we sell.",
  },
  {
    icon: "fa-house-laptop",
    title: "Hybrid Friendly",
    desc: "Work from our hubs or remotely — we care about output, not seats.",
  },
  {
    icon: "fa-heart-pulse",
    title: "Health Cover",
    desc: "Medical insurance for you and your immediate family.",
  },
  {
    icon: "fa-graduation-cap",
    title: "Learning Budget",
    desc: "Yearly stipend for courses, certifications, and conferences.",
  },
  {
    icon: "fa-mug-hot",
    title: "Flexible Leave",
    desc: "Take the time you need — we trust you to manage your workload.",
  },
  {
    icon: "fa-users",
    title: "Small Teams",
    desc: "Flat structure, direct ownership, no layers of approval.",
  },
];

const POSITIONS = [
  {
    id: "p1",
    title: "Frontend Engineer (React)",
    dept: "Engineering",
    location: "Coimbatore · Hybrid",
    type: "Full-time",
  },
  {
    id: "p2",
    title: "Backend Engineer (Django)",
    dept: "Engineering",
    location: "Coimbatore · Remote",
    type: "Full-time",
  },
  {
    id: "p3",
    title: "Travel Consultant",
    dept: "Operations",
    location: "Mumbai · On-site",
    type: "Full-time",
  },
  {
    id: "p4",
    title: "Destination Partnerships Manager",
    dept: "Operations",
    location: "Dubai · On-site",
    type: "Full-time",
  },
  {
    id: "p5",
    title: "Performance Marketing Specialist",
    dept: "Marketing",
    location: "Mumbai · Hybrid",
    type: "Full-time",
  },
  {
    id: "p6",
    title: "Content & SEO Writer",
    dept: "Marketing",
    location: "Remote",
    type: "Contract",
  },
  {
    id: "p7",
    title: "Customer Support Associate",
    dept: "Support",
    location: "Coimbatore · On-site",
    type: "Full-time",
  },
];

const DEPARTMENTS = ["All", ...new Set(POSITIONS.map((p) => p.dept))];

export default function CareerContent() {
  const [activeDept, setActiveDept] = useState("All");

  const filteredPositions = useMemo(() => {
    if (activeDept === "All") return POSITIONS;
    return POSITIONS.filter((p) => p.dept === activeDept);
  }, [activeDept]);

  return (
    <>
      {/* ============ PERKS ============ */}
      <section className="career-section" id="culture">
        <div className="career-section-inner">
          <p className="eyebrow">Why Join Us</p>
          <h2>A team that travels as much as it talks about travel</h2>
          <div className="perks-grid">
            {PERKS.map((perk) => (
              <div className="perk-card" key={perk.title}>
                <div className="perk-icon">
                  <i className={`fa-solid ${perk.icon}`}></i>
                </div>
                <h3>{perk.title}</h3>
                <p>{perk.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ OPEN POSITIONS ============ */}
      <section className="career-section alt" id="openings">
        <div className="career-section-inner">
          <p className="eyebrow">Open Roles</p>
          <h2>Find your next trip — the career kind</h2>

          <div className="dept-filter">
            {DEPARTMENTS.map((dept) => (
              <button
                key={dept}
                className={`dept-pill ${activeDept === dept ? "active" : ""}`}
                onClick={() => setActiveDept(dept)}
              >
                {dept}
              </button>
            ))}
          </div>

          <div className="positions-list">
            {filteredPositions.map((job) => (
              <div className="position-card" key={job.id}>
                <div className="position-info">
                  <h3>{job.title}</h3>
                  <div className="position-meta">
                    <span>
                      <i className="fa-solid fa-building"></i> {job.dept}
                    </span>
                    <span>
                      <i className="fa-solid fa-location-dot"></i>{" "}
                      {job.location}
                    </span>
                    <span>
                      <i className="fa-solid fa-clock"></i> {job.type}
                    </span>
                  </div>
                </div>
                <a href={`/career/apply/${job.id}/`} className="btn-primary sm">
                  Apply <i className="fa-solid fa-arrow-right"></i>
                </a>
              </div>
            ))}

            {filteredPositions.length === 0 && (
              <p className="no-positions">
                No open roles in this department right now — check back soon.
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ============ CTA ============ */}
      <section className="career-cta">
        <div className="career-cta-inner">
          <h2>Don't see the right role?</h2>
          <p>
            We're always happy to hear from good people. Send us your resume
            and tell us where you'd fit in.
          </p>
          <a href="mailto:careers@gst.com" className="btn-primary">
            Email Your Resume <i className="fa-solid fa-paper-plane"></i>
          </a>
        </div>
      </section>
    </>
  );
}