import React from "react";

const THIRD_PARTY_ROWS = [
  {
    provider: "Google Analytics",
    purpose: "Site usage & performance measurement",
    category: "Measurement",
  },
  {
    provider: "Google Maps",
    purpose: "Interactive hotel & package location maps",
    category: "Functionality",
  },
  {
    provider: "Payment Gateway",
    purpose: "Secure checkout & fraud prevention",
    category: "Essential",
  },
  {
    provider: "Ad Network Partner",
    purpose: "Relevant travel offers across the web",
    category: "Marketing",
  },
];

export default function CookiesTable({ onManagePreferences }) {
  return (
    <>
      <div className="policy-section">
        <div className="policy-section-icon">
          <i className="fa-solid fa-puzzle-piece"></i>
        </div>
        <h2>Third-Party Cookies</h2>
        <p>
          Some cookies are set by trusted partners who help us run
          analytics, maps, and payments. We only enable these if the
          matching category above is switched on.
        </p>
        <table className="cookie-table">
          <thead>
            <tr>
              <th>Provider</th>
              <th>Purpose</th>
              <th>Category</th>
            </tr>
          </thead>
          <tbody>
            {THIRD_PARTY_ROWS.map((row) => (
              <tr key={row.provider}>
                <td>{row.provider}</td>
                <td>{row.purpose}</td>
                <td>{row.category}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="policy-section">
        <div className="policy-section-icon">
          <i className="fa-solid fa-toggle-on"></i>
        </div>
        <h2>How to Control Cookies</h2>
        <p>
          You can change your preferences at any time &mdash; nothing is
          locked in once you've made a choice.
        </p>
        <ul>
          <li>
            Use the{" "}
            <button className="inline-link-btn" onClick={onManagePreferences}>
              cookie preference panel
            </button>{" "}
            on this page to toggle each category individually.
          </li>
          <li>
            Use your browser's settings to block or delete cookies entirely
            (this may affect some site features).
          </li>
          <li>
            Look for the floating "Cookie Settings" button in the corner of
            any page to reopen this panel later.
          </li>
        </ul>
      </div>

      <div className="policy-section">
        <div className="policy-section-icon">
          <i className="fa-solid fa-rotate"></i>
        </div>
        <h2>Changes to This Policy</h2>
        <p>
          We may update this policy as our site or regulations evolve.
          Material changes will be highlighted on this page. This version
          was last updated <strong>June 2026</strong>.
        </p>
      </div>

      <div className="policy-section">
        <div className="policy-section-icon">
          <i className="fa-solid fa-envelope"></i>
        </div>
        <h2>Questions?</h2>
        <p>
          Reach out to our privacy team any time at{" "}
          <a
            href="mailto:privacy@globalsmarttourism.com"
            style={{
              color: "var(--primary)",
              fontWeight: 600,
              textDecoration: "none",
            }}
          >
            privacy@globalsmarttourism.com
          </a>
          .
        </p>
      </div>
    </>
  );
}
