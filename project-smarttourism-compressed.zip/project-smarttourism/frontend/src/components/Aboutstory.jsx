export default function Aboutstory() {
  return (
    <div className="story-wrap">
      <div className="sec">
        <div className="story-grid reveal">
          <div className="story-img-wrap">
            <img
              src="/images/mission.jpg"
              alt="Global Smart Tourism office team planning a trip"
              className="story-img-main"
            />
            <img src="/images/mission.jpg" alt="" className="story-img-accent" />
            <div className="story-badge">EST. 2012 · MUMBAI</div>
          </div>
          <div className="story-text">
            <p className="eyebrow">Who We Are</p>
            <h2>Born From a <em>Passion</em> for the Journey</h2>
            <p>
              Global Smart Tourism started as a two-person operation in a small Mumbai office. Our
              founders — both seasoned travellers — were tired of cookie-cutter packages that missed
              everything that made a destination worth visiting.
            </p>
            <p>
              Today we're a team of 80+ travel specialists, destination experts, and round-the-clock
              support staff, working from offices in Mumbai, Dubai, and Coimbatore. The mission
              hasn't changed: every itinerary we build puts the traveller at the centre, not the
              transaction.
            </p>
            <p>
              We've built relationships with 400+ hotels, airlines, and local guides across 40
              countries — so when you book with us, you get access no aggregator can match.
            </p>
            <div className="pillars">
              <div className="pillar">
                <div className="pillar-icon blue"><i className="fa-solid fa-handshake"></i></div>
                <div>
                  <div className="pillar-title">Relationships Over Transactions</div>
                  <div className="pillar-desc">
                    We stay with you before, during, and after your trip — not just until your
                    booking is confirmed.
                  </div>
                </div>
              </div>
              <div className="pillar">
                <div className="pillar-icon gold"><i className="fa-solid fa-magnifying-glass-location"></i></div>
                <div>
                  <div className="pillar-title">Local Knowledge, Global Reach</div>
                  <div className="pillar-desc">
                    Our destination experts have lived in, not just visited, the places they
                    recommend.
                  </div>
                </div>
              </div>
              <div className="pillar">
                <div className="pillar-icon teal"><i className="fa-solid fa-leaf"></i></div>
                <div>
                  <div className="pillar-title">Responsible Tourism</div>
                  <div className="pillar-desc">
                    We offset 100% of our tour carbon footprint and partner only with eco-certified
                    properties.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}