import React from 'react';

// Update this import to wherever your logo actually lives, e.g.
// import logo from '../assets/logo.png';
const logo = '/logo.png';

const STEP_TITLES = ['Account details', 'Personal info', 'Set your password'];

export default function Signupheader({ step }) {
  return (
    <>
      <div className="brand-header">
        <img src={logo} alt="Global Smart Tourism Logo" className="brand-logo-img" />
        <div className="brand-name">Global Smart Tourism</div>
        <div className="brand-tagline">Create your free account</div>
      </div>

      <div className="steps-bar">
        {[1, 2, 3].map((n) => (
          <React.Fragment key={n}>
            <div className={`step-dot ${n < step ? 'done' : n === step ? 'active' : ''}`}>
              {n < step ? '✓' : n}
            </div>
            {n < 3 && <div className={`step-line ${n < step ? 'done' : ''}`} />}
          </React.Fragment>
        ))}
      </div>

      <div className="section-title">{STEP_TITLES[step - 1]}</div>
    </>
  );
}