import React from "react";
import { Link } from "react-router-dom";

export default function Payment_SuccessWhatsNext({ booking }) {
  return (
    <div className="card full-width">
      <div className="card-title">🗺 What happens next?</div>

      <div className="whats-next">
        <div className="next-item">
          <div className="next-icon" style={{ background: "#dcfce7" }}>📧</div>
          <div className="next-text">
            <p>Confirmation email sent</p>
            <span>
              A full booking confirmation with itinerary details has been sent
              to {booking.customer.email}.
            </span>
          </div>
        </div>

        <div className="next-item">
          <div className="next-icon" style={{ background: "#dbeafe" }}>📞</div>
          <div className="next-text">
            <p>Our team will call you</p>
            <span>
              A travel expert will contact you within 24 hours to finalize
              your itinerary and hotel preferences.
            </span>
          </div>
        </div>

        <div className="next-item">
          <div className="next-icon" style={{ background: "#fef9c3" }}>🎒</div>
          <div className="next-text">
            <p>Prepare for your trip</p>
            <span>
              Check our travel guide for packing tips, local weather
              forecasts, and destination highlights.
            </span>
          </div>
        </div>
      </div>

      <div className="btn-row">
        <Link to="/" className="btn-primary">Go to Home</Link>
        <Link to="/success/" className="btn-outline">View My Bookings</Link>
      </div>
    </div>
  );
}