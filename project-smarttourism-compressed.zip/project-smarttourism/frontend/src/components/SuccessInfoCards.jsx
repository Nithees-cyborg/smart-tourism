import React from "react";

// Reference number banner + the 4 info cards (customer, package, booking, payment)
// Pass the `booking` and `payment` objects down as props from Success.jsx
export default function SuccessInfoCards({ booking, payment }) {
  return (
    <>
      {/* Reference Banner */}
      <div className="ref-banner">
        <div>
          <div className="ref-label">Booking Reference Number</div>
          <div className="ref-id">#GST-{booking.id}</div>
        </div>
        <div className="ref-right">📌 Save this number for your records</div>
      </div>

      {/* Row 1: Customer + Package */}
      <div className="grid">
        <div className="card">
          <div className="card-title">👤 Customer Details</div>
          <div className="info-row">
            <span className="info-label">Full Name</span>
            <span className="info-val">{booking.customer.full_name}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Email</span>
            <span className="info-val">{booking.customer.email}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Phone</span>
            <span className="info-val">{booking.customer.phone}</span>
          </div>
          <div className="info-row">
            <span className="info-label">City</span>
            <span className="info-val">{booking.customer.city}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Country</span>
            <span className="info-val">{booking.customer.country}</span>
          </div>
        </div>

        <div className="card">
          <div className="card-title">🌍 Package Details</div>
          <div className="info-row">
            <span className="info-label">Package Name</span>
            <span className="info-val">{booking.package.package_name}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Destination</span>
            <span className="info-val">{booking.package.destination}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Duration</span>
            <span className="info-val">{booking.package.duration}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Price / Person</span>
            <span className="info-val">₹ {booking.package.price}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Description</span>
            <span className="info-val" style={{ fontSize: 12, color: "#64748b" }}>
              {booking.package.description}
            </span>
          </div>
        </div>
      </div>

      {/* Row 2: Booking + Payment */}
      <div className="grid">
        <div className="card">
          <div className="card-title">📋 Booking Info</div>
          <div className="info-row">
            <span className="info-label">Travel Date</span>
            <span className="info-val">{booking.travel_date}</span>
          </div>
          <div className="info-row">
            <span className="info-label">No. of Persons</span>
            <span className="info-val">{booking.persons}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Booking Status</span>
            <span className="info-val">
              <span className="badge-green">{booking.status}</span>
            </span>
          </div>
          <div className="total-box">
            <span className="total-label">Total Amount</span>
            <span className="total-amount">₹ {booking.total_amount}</span>
          </div>
        </div>

        <div className="card">
          <div className="card-title">💳 Payment Details</div>
          <div className="info-row">
            <span className="info-label">Amount Paid</span>
            <span className="info-val">₹ {payment.amount}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Payment Method</span>
            <span className="info-val">{payment.payment_method}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Payment Date</span>
            <span className="info-val">{payment.payment_date}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Payment Status</span>
            <span className="info-val">
              <span className="badge-green">{payment.status}</span>
            </span>
          </div>
          <div className="pay-success-box">
            <div className="icon">🔒</div>
            <div>
              <p>Payment Successful</p>
              <span>Your transaction was processed securely</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}