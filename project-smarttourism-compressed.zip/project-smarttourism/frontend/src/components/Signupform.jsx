import React, { useState } from 'react';
import axios from "axios";
const STRENGTH_LEVELS = [
  { pct: '18%', color: '#ef4444', label: 'Very weak' },
  { pct: '38%', color: '#f97316', label: 'Weak' },
  { pct: '62%', color: '#eab308', label: 'Fair' },
  { pct: '84%', color: '#22c55e', label: 'Strong' },
  { pct: '100%', color: '#16a34a', label: 'Very strong' },
];

function getStrength(pwd) {
  let s = 0;
  if (pwd.length >= 8) s++;
  if (pwd.length >= 12) s++;
  if (/[A-Z]/.test(pwd)) s++;
  if (/[0-9]/.test(pwd)) s++;
  if (/[^A-Za-z0-9]/.test(pwd)) s++;
  return STRENGTH_LEVELS[Math.min(s, 4)];
}

export default function Signupform({ step, setStep, showToast }) {
  const [form, setForm] = useState({
    fname: '',
    lname: '',
    username: '',
    email: '',
    phone: '',
    country: '',
    role: '',
    password: '',
    confirm: '',
    terms: false,
  });
  const [error, setError] = useState('');
  const [showPass1, setShowPass1] = useState(false);
  const [showPass2, setShowPass2] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [field]: value }));
  };

  const goStep2 = () => {
    if (!form.fname.trim() || !form.lname.trim()) return setError('Enter your first and last name.');
    if (!form.username.trim()) return setError('Choose a username.');
    if (!/^[a-zA-Z0-9_]+$/.test(form.username))
      return setError('Username can only contain letters, numbers, and underscores.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return setError('Enter a valid email address.');
    setError('');
    setStep(2);
  };

  const goStep3 = () => {
    if (!form.phone.trim() || !form.country.trim()) return setError('Fill in your phone number and country.');
    if (!form.role) return setError('Select your role.');
    setError('');
    setStep(3);
  };

  const submit = async () => {
  if (form.password.length < 8) {
    return setError("Password must be at least 8 characters.");
  }

  if (form.password !== form.confirm) {
    return setError("Passwords do not match.");
  }

  if (!form.terms) {
    return setError("Accept the Terms of Service.");
  }

  setError("");
  setSubmitting(true);

  try {
    const response = await axios.post(
      "http://127.0.0.1:8000/api/signup/",
      {
        first_name: form.fname,
        last_name: form.lname,
        username: form.username,
        email: form.email,
        phone: form.phone,
        country: form.country,
        role: form.role,
        password: form.password,
      },
      {
        withCredentials: true,
      }
    );

    if (response.data.success) {
      showToast("Account Created Successfully!");

      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);

    } else {
      setError(response.data.message);
      showToast(response.data.message, false);
    }

  } catch (err) {
    console.log(err);

    if (err.response) {
      setError(err.response.data.message);
      showToast(err.response.data.message, false);
    } else {
      setError("Unable to connect to Django.");
      showToast("Unable to connect to Django.", false);
    }

  } finally {
    setSubmitting(false);
  }
};

  const lvl = getStrength(form.password);

  return (
    <form className="signup-form" onSubmit={(e) => e.preventDefault()} noValidate>
      {error && <div className="error-box" style={{ display: 'block' }}>{error}</div>}

      {/* Step 1: Account details */}
      {step === 1 && (
        <div>
          <div className="row-2">
            <div className="field-group">
              <label className="field-label">First name</label>
              <div className="field-wrap">
                <input
                  className={`field-input ${form.fname ? 'valid' : ''}`}
                  type="text"
                  placeholder="John"
                  value={form.fname}
                  onChange={update('fname')}
                  autoComplete="given-name"
                />
                <span className="field-valid">✓</span>
              </div>
            </div>
            <div className="field-group">
              <label className="field-label">Last name</label>
              <div className="field-wrap">
                <input
                  className={`field-input ${form.lname ? 'valid' : ''}`}
                  type="text"
                  placeholder="Doe"
                  value={form.lname}
                  onChange={update('lname')}
                  autoComplete="family-name"
                />
                <span className="field-valid">✓</span>
              </div>
            </div>
          </div>

          <div className="field-group">
            <label className="field-label">Username</label>
            <div className="field-wrap">
              <input
                className={`field-input ${form.username ? 'valid' : ''}`}
                type="text"
                placeholder="john_doe"
                value={form.username}
                onChange={update('username')}
                autoComplete="username"
              />
              <span className="field-valid">✓</span>
            </div>
            <div className="field-hint">Letters, numbers, and underscores only</div>
          </div>

          <div className="field-group">
            <label className="field-label">Email address</label>
            <div className="field-wrap">
              <input
                className={`field-input ${form.email ? 'valid' : ''}`}
                type="email"
                placeholder="john@example.com"
                value={form.email}
                onChange={update('email')}
                autoComplete="email"
              />
              <span className="field-valid">✓</span>
            </div>
          </div>

          <button className="btn-primary" type="button" onClick={goStep2}>
            Continue →
          </button>
        </div>
      )}

      {/* Step 2: Personal info */}
      {step === 2 && (
        <div>
          <div className="field-group">
            <label className="field-label">Phone number</label>
            <div className="field-wrap">
              <input
                className={`field-input ${form.phone ? 'valid' : ''}`}
                type="tel"
                placeholder="+91 98765 43210"
                value={form.phone}
                onChange={update('phone')}
                autoComplete="tel"
              />
              <span className="field-valid">✓</span>
            </div>
          </div>

          <div className="field-group">
            <label className="field-label">Country</label>
            <div className="field-wrap">
              <input
                className={`field-input ${form.country ? 'valid' : ''}`}
                type="text"
                placeholder="India"
                value={form.country}
                onChange={update('country')}
                autoComplete="country-name"
              />
              <span className="field-valid">✓</span>
            </div>
          </div>

          <div className="field-group">
            <label className="field-label">I am a</label>
            <div className="field-wrap">
              <select className="field-input" value={form.role} onChange={update('role')}>
                <option value="">Select your role…</option>
                <option>Tourist</option>
                <option>Travel Agent</option>
                <option>Tour Operator</option>
                <option>Hotel / Resort</option>
                <option>Government Official</option>
              </select>
            </div>
          </div>

          <div className="btn-row">
            <button className="btn-back" type="button" onClick={() => setStep(1)}>
              ← Back
            </button>
            <button className="btn-primary" type="button" onClick={goStep3}>
              Continue →
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Password */}
      {step === 3 && (
        <div>
          <div className="field-group">
            <label className="field-label">Password</label>
            <div className="field-wrap">
              <input
                className="field-input"
                type={showPass1 ? 'text' : 'password'}
                placeholder="Create a strong password"
                value={form.password}
                onChange={update('password')}
                autoComplete="new-password"
              />
              <button className="toggle-pass" type="button" onClick={() => setShowPass1((s) => !s)}>
                {showPass1 ? '🙈' : '👁'}
              </button>
            </div>
            {form.password && (
              <>
                <div className="strength-bar" style={{ display: 'block' }}>
                  <div className="strength-fill" style={{ width: lvl.pct, background: lvl.color }} />
                </div>
                <div className="strength-label" style={{ display: 'block', color: lvl.color }}>
                  {lvl.label}
                </div>
              </>
            )}
          </div>

          <div className="field-group">
            <label className="field-label">Confirm password</label>
            <div className="field-wrap">
              <input
                className={`field-input ${
                  form.confirm && form.confirm !== form.password
                    ? 'invalid'
                    : form.confirm
                    ? 'valid'
                    : ''
                }`}
                type={showPass2 ? 'text' : 'password'}
                placeholder="Re-enter password"
                value={form.confirm}
                onChange={update('confirm')}
                autoComplete="new-password"
              />
              <button className="toggle-pass" type="button" onClick={() => setShowPass2((s) => !s)}>
                {showPass2 ? '🙈' : '👁'}
              </button>
              {form.confirm && form.confirm === form.password && (
                <span className="field-valid" style={{ display: 'block' }}>✓</span>
              )}
            </div>
            {form.confirm && (
              <div
                className="field-hint"
                style={{ color: form.confirm === form.password ? '#22c55e' : '#ef4444' }}
              >
                {form.confirm === form.password ? 'Passwords match' : 'Passwords do not match'}
              </div>
            )}
          </div>

          <div className="terms-row">
            <input type="checkbox" checked={form.terms} onChange={update('terms')} id="terms" />
            <label htmlFor="terms">
              I agree to the <a href="/terms/">Terms of Service</a> and{' '}
              <a href="/privacy/">Privacy Policy</a>
            </label>
          </div>

          <div className="btn-row">
            <button className="btn-back" type="button" onClick={() => setStep(2)}>
              ← Back
            </button>
            <button className="btn-primary" type="button" onClick={submit} disabled={submitting}>
              {submitting ? <div className="btn-spinner" style={{ display: 'block' }} /> : 'Create account'}
            </button>
          </div>
        </div>
      )}
    </form>
  );
}