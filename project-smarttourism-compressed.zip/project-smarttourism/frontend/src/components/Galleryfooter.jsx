import React from 'react';

const Galleryfooter = () => {
  return (
    <footer className="site-footer">
      Global Smart Tourism &mdash; Gallery images shown are for demonstration purposes within this project.
    </footer>
  );
};

export default Galleryfooter;