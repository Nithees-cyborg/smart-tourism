import React, { useEffect, useRef } from 'react';

/**
 * Full-page background: bg image + dark gradient overlay + floating particles.
 * Wraps everything else passed in as children (the card).
 */
export default function Signupbackground({ children }) {
  const particlesRef = useRef(null);

  useEffect(() => {
    const container = particlesRef.current;
    if (!container) return;

    container.innerHTML = '';
    const colors = ['#60a5fa', '#93c5fd', '#dbeafe', '#ffffff'];

    for (let i = 0; i < 20; i++) {
      const p = document.createElement('div');
      const sz = 4 + Math.random() * 14;
      p.className = 'signup-particle';
      p.style.cssText = [
        `width:${sz}px`,
        `height:${sz}px`,
        `left:${Math.random() * 100}%`,
        `bottom:-${Math.random() * 60}px`,
        `background:${colors[Math.floor(Math.random() * colors.length)]}`,
        `animation-duration:${9 + Math.random() * 13}s`,
        `animation-delay:${Math.random() * 10}s`,
      ].join(';');
      container.appendChild(p);
    }
  }, []);

  return (
    <div className="signup-body">
      <div className="signup-overlay" />
      <div className="signup-particles" ref={particlesRef} />
      <div className="signup-wrapper">{children}</div>
    </div>
  );
}