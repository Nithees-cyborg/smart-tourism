import React, { useEffect, useState } from "react";

const TOGGLE_ROWS = [
  {
    key: "functionality",
    title: "Functionality",
    desc: "Remembers language, currency, and recent searches.",
  },
  {
    key: "measurement",
    title: "Measurement",
    desc: "Helps us understand usage to improve the site.",
  },
  {
    key: "marketing",
    title: "Marketing",
    desc: "Shows relevant offers based on your interests.",
  },
  {
    key: "experience",
    title: "Experience",
    desc: "Personalizes recommendations and layout for you.",
  },
];

export default function CookiesModal({
  modalOpen,
  consent,
  onClose,
  onAcceptAll,
  onRejectAll,
  onSave,
}) {
  // Local draft so toggles only commit when "Save Preferences" is clicked
  const [draft, setDraft] = useState(consent);

  useEffect(() => {
    if (modalOpen) setDraft(consent);
  }, [modalOpen, consent]);

  const toggle = (key) =>
    setDraft((prev) => ({ ...prev, [key]: !prev[key] }));

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <div
      className={`cookie-modal-overlay${modalOpen ? " active" : ""}`}
      onClick={handleOverlayClick}
    >
      <div className="cookie-modal-box">
        <button className="cookie-modal-close" onClick={onClose}>
          <i className="fa-solid fa-xmark"></i>
        </button>
        <h3>We use cookies</h3>
        <p>
          We use cookies and similar technologies &mdash; our own and those
          from selected third parties &mdash; for essential functionality,
          analytics, and marketing. You can manage your preferences below
          and update or withdraw consent any time from the Cookie Settings
          button.
        </p>

        <div className="pref-grid">
          <div className="pref-item full">
            <div className="pref-text">
              <h4>
                Essential <span className="always-badge">Always Active</span>
              </h4>
              <p>Required for login, navigation, and secure checkout to work.</p>
            </div>
            <label className="toggle-switch disabled">
              <input type="checkbox" checked disabled readOnly />
              <span className="toggle-slider"></span>
            </label>
          </div>

          {TOGGLE_ROWS.map(({ key, title, desc }) => (
            <div className="pref-item" key={key}>
              <div className="pref-text">
                <h4>{title}</h4>
                <p>{desc}</p>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={!!draft[key]}
                  onChange={() => toggle(key)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
          ))}
        </div>

        <div className="cookie-modal-footer">
          <button className="btn-cookie btn-cookie-outline" onClick={onRejectAll}>
            Reject All
          </button>
          <button
            className="btn-cookie btn-cookie-ghost"
            onClick={() => onSave(draft)}
          >
            Save Preferences
          </button>
          <button className="btn-cookie btn-cookie-primary" onClick={onAcceptAll}>
            Accept All
          </button>
        </div>

        <a href="#what-are-cookies" className="learn-more-link" onClick={onClose}>
          Learn more about our cookie policy
        </a>
      </div>
    </div>
  );
}
