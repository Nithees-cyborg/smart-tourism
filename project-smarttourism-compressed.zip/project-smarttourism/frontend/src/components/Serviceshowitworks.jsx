const steps = [
  {
    code: "DEP — STEP 01",
    icon: "fa-solid fa-location-dot",
    title: "Tell Us Where",
    desc: "Pick your dates and destination — solo trip, family holiday, or a guided tour, your call.",
  },
  {
    code: "CNX — STEP 02",
    icon: "fa-solid fa-circle-check",
    title: "We Confirm Everything",
    desc: "Hotel, flights, and a guide (if you want one) get locked in and texted to you the same day.",
  },
  {
    code: "ARR — STEP 03",
    icon: "fa-solid fa-suitcase-rolling",
    title: "You Just Travel",
    desc: "One trip number covers every booking. Show it at check-in, the counter, or the gate.",
  },
];

function Serviceshowitworks() {
  return (
    <section className="svc-how-it-works">
      <div className="section-head on-light reveal">
        <p className="eyebrow">Boarding Process</p>
        <h2>Three steps. One trip number.</h2>
        <p>Booking with us reads like an itinerary, not a checkout form.</p>
      </div>

      <div className="svc-timeline">
        {steps.map((s) => (
          <div className="svc-t-step reveal" key={s.code}>
            <div className="svc-t-dot">
              <i className={s.icon}></i>
            </div>
            <span className="svc-t-code">{s.code}</span>
            <h3>{s.title}</h3>
            <p>{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Serviceshowitworks;