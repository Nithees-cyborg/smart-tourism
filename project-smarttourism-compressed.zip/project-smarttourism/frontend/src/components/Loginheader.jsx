export default function Loginheader({
  brandName = "Global Smart Tourism",
  tagline = "Enterprise access management",
  title = "Sign in to your account",
}) {
  return (
    <>
      <div className="brand-header">
        <div className="logo-wrap">
          <div className="logo-ring-outer"></div>

          <div className="logo-inner">
            <img
              src="/logo.png"
              alt={brandName}
              className="brand-logo-img"
            />
          </div>
        </div>

        <h1 className="brand-name">{brandName}</h1>
        <p className="brand-tagline">{tagline}</p>
      </div>

      <h2 className="section-title">{title}</h2>
    </>
  );
}