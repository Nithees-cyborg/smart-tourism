import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const ICONS = {
  train: "M4 15a3 3 0 0 0 3 3l-1.5 2.5h9L13 18a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v8ZM4 11h12M8.5 18.5h.01M15.5 18.5h.01M7 7h10",
  car: "M4 16V11l2-5h12l2 5v5M4 16a1.5 1.5 0 0 0 3 0M17 16a1.5 1.5 0 0 0 3 0M4 16h2m11 0h3M4 11h16",
  boat: "M3 15h18l-2 5H5l-2-5ZM6 15V7l6-3 6 3v8M9 7h6M12 4v3",
  bus: "M4 16V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10M4 16a1.5 1.5 0 0 0 3 0M17 16a1.5 1.5 0 0 0 3 0M4 16h2m11 0h3M4 12h16M8 9h8",
  plane: "M12 3v7l7 4v2l-7-2-2 5H8l1-5-7 2v-2l7-4V5a2 2 0 0 1 4-2Z",
  ticket: "M4 9a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1.5a1.5 1.5 0 0 0 0 3V15a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1.5a1.5 1.5 0 0 0 0-3V9ZM10 7v10",
  bed: "M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7M3 18v-2h18v2M3 16v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1M13 13a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1",
  food: "M6 3v7a2 2 0 0 0 4 0V3M8 10v11M17 3c-1.5 1.5-2 3-2 5s.5 3.5 2 5v8",
  guide: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 3.6-7 8-7s8 3 8 7",
  shield: "M12 3l8 3v6c0 5-3.4 8.5-8 9-4.6-.5-8-4-8-9V6l8-3Z",
  star: "M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 16.9 6.4 20.1l1.4-6.3-4.8-4.3 6.4-.6L12 3Z",
  check: "M4 12l5 5L20 6",
  close: "M6 6l12 12M18 6L6 18",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 3.6-7 8-7s8 3 8 7",
  users: "M9 12a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM17 12a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM2 20c0-3.3 3.1-6 7-6s7 2.7 7 6M14 14.5c3.4.3 6 2.7 6 5.5",
  map: "M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2Zm0 0v14m6-12v14",
};

function Icon({ name, size = 18 }) {
  const d = ICONS[name] || ICONS.ticket;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

function guessIcon(text) {
  const t = text.toLowerCase();
  if (/(train|rail|shinkansen|ktx|tgv|glacier express)/.test(t)) return "train";
  if (/(flight|fly|plane|airfare)/.test(t)) return "plane";
  if (/(car|vehicle|4x4|jeep|drive|transfer)/.test(t)) return "car";
  if (/(boat|cruise|ferry|houseboat|shikara|felucca|catamaran|gondola)/.test(t)) return "boat";
  if (/(bus|coach)/.test(t)) return "bus";
  if (/(breakfast|meal|dinner|food|board)/.test(t)) return "food";
  if (/(guide)/.test(t)) return "guide";
  if (/(insurance|permit|fee|safety)/.test(t)) return "shield";
  if (/(stay|hotel|night|villa|camp|lodge|resort)/.test(t)) return "bed";
  return "ticket";
}

export default function HotelModal({ hotel, onClose }) {
  const navigate = useNavigate();
  const [activeImg, setActiveImg] = useState(0);
  const [selectedRoomId, setSelectedRoomId] = useState(null);
  const [guests, setGuests] = useState(2);

  if (!hotel) return null;

  const selectedRoom = hotel.rooms.find((r) => r.id === selectedRoomId) || hotel.rooms.find((r) => r.popular) || hotel.rooms[0];
  const total = selectedRoom.pricePerNight * hotel.nights;

  const handleGuestChange = (delta) => {
    setGuests((g) => Math.min(selectedRoom.maxGuests, Math.max(1, g + delta)));
  };

  const handleSelectRoom = (room) => {
    setSelectedRoomId(room.id);
    setGuests(Math.min(guests, room.maxGuests));
  };

  const handleBookNow = () => {
    navigate(`/hotels/${hotel.id}/overview`, {
      state: { roomId: selectedRoom.id, guests },
    });
  };

  return (
    <div className="hm-overlay" onClick={onClose}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Work+Sans:wght@400;500;600&display=swap');

        .hm-overlay { position: fixed; inset: 0; z-index: 3000; background: rgba(5,7,13,0.75); backdrop-filter: blur(4px); display: flex; align-items: flex-start; justify-content: center; padding: 28px 20px; overflow-y: auto; animation: hm-fade 0.25s ease; }
        @keyframes hm-fade { from { opacity: 0; } to { opacity: 1; } }

        .hm-box {
          --ink: #f4f1ea; --navy: #0a0e1a; --navy-deep: #05070d; --navy-soft: #0d1428;
          --panel: rgba(244,241,234,0.045); --panel-2: rgba(244,241,234,0.07);
          --gold: #e3a94a; --gold-soft: rgba(227,169,74,0.35);
          --line: rgba(244,241,234,0.12); --btn-ink: #10182b; --muted: rgba(244,241,234,0.62);
          font-family: 'Work Sans', -apple-system, sans-serif;
          color: var(--ink);
          background: linear-gradient(180deg, var(--navy-deep) 0%, var(--navy) 55%, var(--navy-soft) 100%);
          border-radius: 22px; max-width: 1120px; width: 100%; max-height: 94vh; overflow: hidden;
          position: relative; box-shadow: 0 40px 90px -20px rgba(0,0,0,0.65); display: flex; flex-direction: column;
        }

        .hm-topbar { display: flex; align-items: center; justify-content: space-between; padding: 18px 26px; border-bottom: 1px solid var(--line); flex-shrink: 0; }
        .hm-breadcrumb { font-size: 12.5px; color: var(--muted); display: flex; align-items: center; gap: 6px; }
        .hm-breadcrumb strong { color: var(--gold); font-weight: 600; }
        .hm-close { width: 36px; height: 36px; border-radius: 50%; background: rgba(244,241,234,0.08); border: 1px solid var(--line); color: var(--ink); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: background 0.2s ease, color 0.2s ease; }
        .hm-close:hover { background: var(--gold); color: var(--btn-ink); }

        .hm-scroll { overflow-y: auto; }
        .hm-gallery { display: grid; grid-template-columns: 2fr 1fr; gap: 6px; padding: 6px 26px 0; }
        .hm-main-img { height: 300px; border-radius: 14px 0 0 14px; overflow: hidden; position: relative; }
        .hm-main-img img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .hm-side-imgs { display: grid; grid-template-rows: 1fr 1fr; gap: 6px; height: 300px; }
        .hm-side-imgs > div { border-radius: 0; overflow: hidden; cursor: pointer; position: relative; }
        .hm-side-imgs > div:first-child { border-radius: 0 14px 0 0; }
        .hm-side-imgs > div:last-child { border-radius: 0 0 14px 0; }
        .hm-side-imgs img { width: 100%; height: 100%; object-fit: cover; display: block; }

        .hm-thumbrow { display: flex; gap: 8px; padding: 10px 26px 0; }
        .hm-thumbrow img { width: 72px; height: 50px; object-fit: cover; border-radius: 8px; cursor: pointer; opacity: 0.5; border: 2px solid transparent; transition: opacity 0.2s ease, border-color 0.2s ease; }
        .hm-thumbrow img.hm-active { opacity: 1; border-color: var(--gold); }

        .hm-layout { display: grid; grid-template-columns: 1fr 320px; gap: 32px; padding: 24px 26px 32px; align-items: start; }

        .hm-eyebrow { display: inline-flex; align-items: center; gap: 8px; font-size: 11.5px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gold); font-weight: 600; margin-bottom: 10px; }
        .hm-eyebrow::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: var(--gold); }
        .hm-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: clamp(24px, 2.6vw, 30px); margin: 0 0 8px; line-height: 1.12; }
        .hm-location { font-size: 13.5px; color: var(--muted); display: flex; align-items: center; gap: 6px; margin: 0 0 16px; }

        .hm-rating-badge { display: inline-flex; align-items: center; gap: 5px; background: var(--gold); color: var(--btn-ink); padding: 4px 9px; border-radius: 7px; font-weight: 700; font-size: 13px; }

        .hm-overview { font-size: 14.5px; line-height: 1.7; color: var(--muted); margin: 0 0 22px; }
        .hm-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 26px; }
        .hm-tag { background: var(--panel); border: 1px solid var(--line); color: rgba(244,241,234,0.88); padding: 7px 13px; border-radius: 100px; font-size: 12.5px; font-weight: 500; display: inline-flex; align-items: center; gap: 6px; }
        .hm-tag svg { color: var(--gold); }

        .hm-section { margin: 28px 0 0; }
        .hm-section-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: 18px; margin: 0 0 4px; }
        .hm-section-sub { font-size: 12.8px; color: var(--muted); margin: 0 0 14px; }

        .hm-item-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
        .hm-item { display: flex; gap: 11px; align-items: flex-start; background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 12px 13px; }
        .hm-item-icon { flex-shrink: 0; width: 30px; height: 30px; border-radius: 8px; background: rgba(227,169,74,0.12); color: var(--gold); display: flex; align-items: center; justify-content: center; }
        .hm-item p { margin: 0; font-size: 12.8px; line-height: 1.45; color: rgba(244,241,234,0.85); }

        /* ---- Room picker ---- */
        .hm-rooms { display: flex; flex-direction: column; gap: 12px; }
        .hm-room-card {
          display: grid; grid-template-columns: auto 1fr auto; gap: 16px; align-items: center;
          background: var(--panel); border: 1px solid var(--line); border-radius: 14px; padding: 16px;
          cursor: pointer; transition: border-color 0.2s ease, background 0.2s ease;
        }
        .hm-room-card.selected { border-color: var(--gold); background: rgba(227,169,74,0.08); }
        .hm-room-radio { width: 20px; height: 20px; border-radius: 50%; border: 2px solid var(--line); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .hm-room-card.selected .hm-room-radio { border-color: var(--gold); }
        .hm-room-radio-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--gold); opacity: 0; transition: opacity 0.15s ease; }
        .hm-room-card.selected .hm-room-radio-dot { opacity: 1; }
        .hm-room-name-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 4px; }
        .hm-room-name { font-family: 'Fraunces', serif; font-weight: 600; font-size: 15.5px; color: var(--ink); }
        .hm-room-popular { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--btn-ink); background: var(--gold); padding: 2px 8px; border-radius: 100px; }
        .hm-room-occupancy { font-size: 12px; color: var(--muted); display: flex; align-items: center; gap: 5px; margin-bottom: 5px; }
        .hm-room-desc { font-size: 12.3px; color: rgba(244,241,234,0.65); line-height: 1.4; margin: 0; max-width: 420px; }
        .hm-room-price { text-align: right; white-space: nowrap; }
        .hm-room-price-value { font-family: 'Fraunces', serif; font-size: 19px; font-weight: 600; color: var(--ink); }
        .hm-room-price-unit { display: block; font-size: 11px; color: var(--muted); margin-top: 1px; }

        .hm-guest-stepper { display: flex; align-items: center; gap: 14px; margin-top: 16px; background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 12px 16px; }
        .hm-guest-label { font-size: 13px; color: var(--ink); font-weight: 600; display: flex; align-items: center; gap: 8px; flex: 1; }
        .hm-guest-label svg { color: var(--gold); }
        .hm-stepper-btn { width: 30px; height: 30px; border-radius: 50%; border: 1px solid var(--line); background: var(--panel-2); color: var(--ink); font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
        .hm-stepper-btn:hover { border-color: var(--gold); color: var(--gold); }
        .hm-guest-count { font-weight: 700; font-size: 14px; min-width: 18px; text-align: center; }
        .hm-guest-note { font-size: 11px; color: var(--muted); }

        .hm-footer { margin-top: 0; border-top: 1px solid var(--line); padding: 22px 36px 28px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; position: sticky; bottom: 0; background: linear-gradient(0deg, var(--navy-soft) 70%, transparent); }
        .hm-price-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; color: rgba(244,241,234,0.5); font-weight: 600; }
        .hm-price-value { font-family: 'Fraunces', serif; font-size: 26px; font-weight: 600; color: var(--ink); margin-top: 2px; }
        .hm-price-unit { font-size: 13px; font-weight: 400; color: rgba(244,241,234,0.55); font-family: 'Work Sans', sans-serif; }
        .hm-book-btn { font-family: 'Work Sans', sans-serif; font-weight: 600; font-size: 14.5px; color: var(--btn-ink); background: var(--gold); border: none; border-radius: 100px; padding: 14px 30px; cursor: pointer; white-space: nowrap; transition: background 0.25s ease, transform 0.25s ease; }
        .hm-book-btn:hover { background: #ddb257; transform: translateY(-2px); }

        @media (max-width: 860px) {
          .hm-layout { grid-template-columns: 1fr; }
          .hm-gallery { grid-template-columns: 1fr; }
          .hm-side-imgs { display: none; }
          .hm-item-grid { grid-template-columns: 1fr; }
          .hm-room-card { grid-template-columns: auto 1fr; }
          .hm-room-price { grid-column: 1 / -1; text-align: left; margin-top: 6px; }
        }
      `}</style>

      <div className="hm-box" onClick={(e) => e.stopPropagation()}>
        <div className="hm-topbar">
          <span className="hm-breadcrumb">Hotels <Icon name="close" size={10} /> {hotel.location} <Icon name="close" size={10} /> <strong>{hotel.name}</strong></span>
          <button className="hm-close" onClick={onClose} aria-label="Close"><Icon name="close" size={16} /></button>
        </div>

        <div className="hm-scroll">
          <div className="hm-gallery">
            <div className="hm-main-img"><img src={hotel.images[activeImg]} alt={hotel.name} /></div>
            {hotel.images.length >= 3 && (
              <div className="hm-side-imgs">
                <div onClick={() => setActiveImg(1)}><img src={hotel.images[1]} alt={`${hotel.name} 2`} /></div>
                <div onClick={() => setActiveImg(2)}><img src={hotel.images[2]} alt={`${hotel.name} 3`} /></div>
              </div>
            )}
          </div>

          <div className="hm-thumbrow">
            {hotel.images.map((img, i) => (
              <img key={img} src={img} alt={`${hotel.name} thumb ${i + 1}`} className={i === activeImg ? "hm-active" : ""} onClick={() => setActiveImg(i)} />
            ))}
          </div>

          <div className="hm-layout">
            <div>
              <span className="hm-eyebrow">{hotel.code} · Featured Stay</span>
              <h2 className="hm-title">{hotel.name}</h2>
              <p className="hm-location"><Icon name="map" size={14} /> {hotel.location} · Part of the {hotel.packageName}</p>
              <span className="hm-rating-badge" style={{ marginBottom: 20, display: "inline-flex" }}>
                <Icon name="star" size={12} /> {hotel.rating}
              </span>

              <p className="hm-overview">{hotel.overview}</p>

              {hotel.amenities?.length > 0 && (
                <div className="hm-tags">
                  {hotel.amenities.map((item) => (
                    <span className="hm-tag" key={item}><Icon name="star" size={13} /> {item}</span>
                  ))}
                </div>
              )}

              {/* ---- Room selection ---- */}
              <div className="hm-section">
                <h3 className="hm-section-title">Choose your room</h3>
                <p className="hm-section-sub">Prices shown are per night — separate rates for solo, double, and group stays.</p>
                <div className="hm-rooms">
                  {hotel.rooms.map((room) => (
                    <div
                      key={room.id}
                      className={`hm-room-card ${selectedRoom.id === room.id ? "selected" : ""}`}
                      onClick={() => handleSelectRoom(room)}
                    >
                      <span className="hm-room-radio"><span className="hm-room-radio-dot" /></span>
                      <div>
                        <div className="hm-room-name-row">
                          <span className="hm-room-name">{room.name}</span>
                          {room.popular && <span className="hm-room-popular">Most booked</span>}
                        </div>
                        <div className="hm-room-occupancy">
                          <Icon name={room.occupancy === 1 ? "user" : "users"} size={13} />
                          Sleeps up to {room.maxGuests} {room.maxGuests === 1 ? "guest" : "guests"}
                        </div>
                        <p className="hm-room-desc">{room.description}</p>
                      </div>
                      <div className="hm-room-price">
                        <span className="hm-room-price-value">₹{room.pricePerNight.toLocaleString("en-IN")}</span>
                        <span className="hm-room-price-unit">per night</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="hm-guest-stepper">
                  <span className="hm-guest-label"><Icon name="users" size={16} /> Guests for this room</span>
                  <button className="hm-stepper-btn" onClick={() => handleGuestChange(-1)}>−</button>
                  <span className="hm-guest-count">{guests}</span>
                  <button className="hm-stepper-btn" onClick={() => handleGuestChange(1)}>+</button>
                  <span className="hm-guest-note">Max {selectedRoom.maxGuests} for this room</span>
                </div>
              </div>

              {hotel.transport?.length > 0 && (
                <div className="hm-section">
                  <h3 className="hm-section-title">Getting around</h3>
                  <div className="hm-item-grid">
                    {hotel.transport.map((item) => (
                      <div className="hm-item" key={item}>
                        <span className="hm-item-icon"><Icon name={guessIcon(item)} size={15} /></span>
                        <p>{item}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="hm-footer">
          <div>
            <div className="hm-price-label">{selectedRoom.name} · {hotel.nights} nights</div>
            <div className="hm-price-value">₹{total.toLocaleString("en-IN")} <span className="hm-price-unit">total</span></div>
          </div>
          <button className="hm-book-btn" onClick={handleBookNow}>Book this hotel</button>
        </div>
      </div>
    </div>
  );
}