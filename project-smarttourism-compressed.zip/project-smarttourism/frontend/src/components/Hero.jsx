import { useEffect, useRef, useState } from "react";
import { SLIDES } from "./data";
import { pad } from "./helpers";

function HeroSlide({ slide, active }) {
  return (
    <div className={`slide${active ? " active" : ""}`}>
      <div className="slide-bg" style={{ backgroundImage: `url(${slide.img})` }}></div>
      <div className="slide-veil"></div>
      <div className="slide-glow"></div>
      <div className="slide-content">
        <div className="slide-eyebrow">{slide.eyebrow}</div>
        <h1>
          {slide.h1[0]}<br />
          {slide.h1[1]}<em>{slide.h1[2]}</em>{slide.h1[3] || ""}
        </h1>
        <p>{slide.p}</p>
        <div className="slide-btns">
          <a href="/packages" className="btn-hero-primary">
            <i className={`fa-solid ${slide.icon}`}></i>{slide.label}
          </a>
          <a href="/login" className="btn-hero-ghost">
            <i className="fa-solid fa-calendar-check"></i>Book Now
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Hero({ searchState, setSearchState, onSearch }) {
  const [cur, setCur]       = useState(0);
  const [paused, setPaused] = useState(false);
  const fillRefs            = useRef([]);
  const rafRef              = useRef(null);
  const startRef            = useRef(performance.now());
  const DURATION            = 3000; // was 5500ms — now inside the 3–5s window

  const goTo = (idx) => {
    cancelAnimationFrame(rafRef.current);
    const next = ((idx % SLIDES.length) + SLIDES.length) % SLIDES.length;
    setCur(next);
    startRef.current = performance.now();
    fillRefs.current.forEach((f) => { if (f) f.style.width = "0%"; });
  };

  useEffect(() => {
    if (paused) return;
    const tick = (now) => {
      const pct = Math.min(100, ((now - startRef.current) / DURATION) * 100);
      if (fillRefs.current[cur]) fillRefs.current[cur].style.width = pct + "%";
      if (pct >= 100) { goTo(cur + 1); return; }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [cur, paused]);

  const touchX = useRef(0);

  return (
    <div
      className="hero-wrap"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => { setPaused(false); startRef.current = performance.now(); }}
      onTouchStart={(e) => { touchX.current = e.changedTouches[0].screenX; }}
      onTouchEnd={(e) => { const dx = e.changedTouches[0].screenX - touchX.current; if (Math.abs(dx) > 40) goTo(dx < 0 ? cur + 1 : cur - 1); }}
    >
      {SLIDES.map((s, i) => <HeroSlide key={i} slide={s} active={i === cur} />)}

      <button className="c-arrow prev" onClick={() => goTo(cur - 1)} aria-label="Previous slide"><i className="fa-solid fa-chevron-left"></i></button>
      <button className="c-arrow next" onClick={() => goTo(cur + 1)} aria-label="Next slide"><i className="fa-solid fa-chevron-right"></i></button>

      <div className="slide-dots">
        {SLIDES.map((_, i) => (
          <button key={i} className={`dot${i === cur ? " active" : ""}`} onClick={() => goTo(i)} aria-label={`Slide ${i + 1}`}>
            <span className="dot-fill" ref={(el) => { fillRefs.current[i] = el; }}></span>
          </button>
        ))}
      </div>

      <div className="slide-counter">
        <div className="counter-num current">{pad(cur + 1)}</div>
        <div className="counter-line"></div>
        <div className="counter-num">{pad(SLIDES.length)}</div>
      </div>
    </div>
  );
}

export function TrustBar() {
  const items = [
    { target: "50", suffix: "K+", label: "Happy Travellers" },
    { target: "120", suffix: "+", label: "Destinations" },
    { target: "4.9", suffix: "★", label: "Average Rating" },
    { target: "12", suffix: "+", label: "Years of Trust" },
    { target: null, static: "24/7", label: "Support" },
  ];

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting || en.target.dataset.animated) return;
        en.target.dataset.animated = "true";
        const target  = parseFloat(en.target.dataset.target);
        const suffix  = en.target.dataset.suffix || "";
        const dec     = en.target.dataset.target.includes(".") ? 1 : 0;
        const dur     = 1500;
        const t0      = performance.now();
        const tick    = (now) => {
          const p = Math.min(1, (now - t0) / dur);
          const e = 1 - Math.pow(1 - p, 3);
          en.target.textContent = (target * e).toFixed(dec) + suffix;
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    document.querySelectorAll(".trust-num[data-target]").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <div className="trust-bar">
      <div className="trust-inner">
        {items.map((it, i) => (
          <div key={i} className="trust-item">
            {it.target
              ? <div className="trust-num" data-target={it.target} data-suffix={it.suffix}>{it.target + it.suffix}</div>
              : <div className="trust-num">{it.static}</div>
            }
            <div className="trust-label">{it.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function OfferBand() {
  const [time, setTime] = useState({ d: "00", h: "00", m: "00", s: "00" });

  useEffect(() => {
    const target = new Date(Date.now() + (4 * 86400 + 8 * 3600 + 17 * 60) * 1000);
    const tick = () => {
      const diff = Math.max(0, target - Date.now());
      setTime({
        d: pad(Math.floor(diff / 86400000)),
        h: pad(Math.floor((diff % 86400000) / 3600000)),
        m: pad(Math.floor((diff % 3600000) / 60000)),
        s: pad(Math.floor((diff % 60000) / 1000)),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="offer-band">
      <div className="offer-inner reveal">
        <div className="offer-text">
          <span className="offer-badge"><i className="fa-solid fa-bolt"></i> Limited Time</span>
          <h3>Monsoon Mega Sale — Up to 40% Off Kerala &amp; Goa</h3>
          <p>Book before the timer runs out and lock in season-low pricing on our most-loved backwater and beach packages.</p>
        </div>
        <div className="offer-timer">
          {[["d","Days"],["h","Hrs"],["m","Min"],["s","Sec"]].map(([k, lbl]) => (
            <div key={k} className="t-box"><span>{time[k]}</span><label>{lbl}</label></div>
          ))}
        </div>
        <a href="/packages" className="btn-hero-primary offer-cta"><i className="fa-solid fa-tag"></i>Grab the Deal</a>
      </div>
    </div>
  );
}