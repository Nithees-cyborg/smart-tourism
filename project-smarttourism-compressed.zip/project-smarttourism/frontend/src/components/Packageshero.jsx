import React from "react";

export default function Packageshero({ search, onSearchChange, onSearchSubmit }) {
  return (
    <section
      style={{
        padding: "72px 6vw 90px",
        background:
          "linear-gradient(180deg, var(--paper) 0%, var(--paper-dim) 100%)",
        textAlign: "center",
      }}
    >
      <span className="pkg-eyebrow" style={{ justifyContent: "center", display: "inline-flex" }}>
        Trips built for one
      </span>
      <h1
        style={{
          fontFamily: "var(--font-display)",
          fontWeight: 600,
          fontSize: "clamp(34px, 5.5vw, 64px)",
          margin: "18px auto 16px",
          maxWidth: 780,
          lineHeight: 1.1,
          color: "var(--ink)",
        }}
      >
        Every itinerary, priced for a party of one.
      </h1>
      <p
        style={{
          color: "var(--ink-soft)",
          fontSize: 17,
          maxWidth: 560,
          margin: "0 auto 36px",
          lineHeight: 1.6,
        }}
      >
        Browse 30+ single-traveler packages across six continents. See the day-by-day
        plan, transport and inclusions before you commit — no group minimums, no guesswork.
      </p>

      <form
        onSubmit={onSearchSubmit}
        style={{
          display: "flex",
          justifyContent: "center",
          gap: 10,
          maxWidth: 480,
          margin: "0 auto",
        }}
      >
        <input
          type="text"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search a destination, e.g. Bali"
          style={{
            flex: 1,
            padding: "14px 18px",
            borderRadius: 999,
            border: "1px solid var(--line-strong)",
            fontSize: 14.5,
            fontFamily: "var(--font-body)",
            background: "var(--paper-card)",
            color: "var(--ink)",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "14px 26px",
            borderRadius: 999,
            border: "none",
            background: "var(--ink)",
            color: "var(--paper)",
            fontWeight: 700,
            fontSize: 14.5,
            cursor: "pointer",
          }}
        >
          Search
        </button>
      </form>
    </section>
  );
}