import React from "react";

export default function Payment_SuccessHero() {
  return (
    <div className="hero-section">
      <div className="check-ring">✓</div>
      <h1>Payment Successful!</h1>
      <p>Your booking is confirmed. Get ready for an unforgettable journey.</p>

      <div className="progress-steps">
        <div className="step-item">
          <div className="step-dot">✓</div> Booked
        </div>
        <div className="step-line"></div>
        <div className="step-item">
          <div className="step-dot">✓</div> Paid
        </div>
        <div className="step-line"></div>
        <div className="step-item">
          <div className="step-dot">✓</div> Confirmed
        </div>
        <div className="step-line"></div>
        <div className="step-item">
          <div className="step-dot pending">✈</div> Travel
        </div>
      </div>
    </div>
  );
}