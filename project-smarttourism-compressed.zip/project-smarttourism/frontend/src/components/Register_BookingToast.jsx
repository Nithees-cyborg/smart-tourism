import React from "react";

export default function Register_BookingToast({ show, message }) {
  return (
    <div className={`toast ${show ? "show" : ""}`} id="toast">
      <i className="fa-solid fa-circle-check"></i>
      <span id="toastMsg">{message}</span>
    </div>
  );
}