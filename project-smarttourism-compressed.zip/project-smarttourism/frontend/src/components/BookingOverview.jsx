import React from "react";

/**
 * BookingOverview
 * -----------------------------------------------------------------------
 * Enhanced Overview Stage before proceeding to Hotel/Transport Selection.
 * Reuses core CSS variables while isolating its structural styling.
 * -----------------------------------------------------------------------
 */

const FALLBACK_IMAGES = [
  "https://picsum.photos/seed/bkov1/900/700",
  "https://picsum.photos/seed/bkov2/900/700",
  "https://picsum.photos/seed/bkov3/900/700",
  "https://picsum.photos/seed/bkov4/900/700",
];

const FALLBACK_PKG = {
  code: "GST-001",
  destination: "Bali",
  package_name: "Bali Highlights, Solo Edition",
  tagline: "Rice terraces, clifftop temples, and sunset beach clubs — paced for one.",
  duration: "6 Days / 5 Nights",
  rating: "4.8",
  price: "42,999",
  highlights: ["Private guide", "4-star stays", "Airport transfers"],
  placesCovered: [
    { name: "Ubud", image: "https://picsum.photos/seed/ubud/900/700" },
    { name: "Uluwatu", image: "https://picsum.photos/seed/uluwatu/900/700" },
    { name: "Seminyak", image: "https://picsum.photos/seed/seminyak/900/700" },
  ],
};

const PROCESS_STEPS = [
  {
    label: "Booking overview",
    title: "You are here",
    detail: "A quick look at your trip before you lock anything in.",
    icon: "here",
  },
  {
    label: "Step 2",
    title: "Hotel booking",
    detail: "Pick your room and dates for every stop on the itinerary.",
    icon: "hotel",
  },
  {
    label: "Step 3",
    title: "Transport booking",
    detail: "Choose trains, transfers, or flights between each stop.",
    icon: "transport",
  },
  {
    label: "Step 4",
    title: "Confirmed",
    detail: "Your full trip dossier lands in your inbox, ready to go.",
    icon: "confirmed",
  },
];

const ICONS = {
  here: "M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11ZM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  hotel: "M3 21V9a2 2 0 0 1 2-2h4v14M13 21V7a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v14M3 21h18M7 11h.01M7 15h.01M17 9h.01M17 13h.01M17 17h.01",
  transport: "M4 15a3 3 0 0 0 3 3l-1.5 2.5h9L13 18a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v8ZM4 11h12",
  confirmed: "M4 12.5l5 5L20 7",
};

function StepIcon({ name, size = 20 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={ICONS[name] || ICONS.confirmed} />
    </svg>
  );
}

function cycleFill(arr, n) {
  if (!arr || arr.length === 0) return [];
  const out = [];
  for (let i = 0; i < n; i++) out.push(arr[i % arr.length]);
  return out;
}

export default function BookingOverview({
  pkg = FALLBACK_PKG,
  images,
  onBack,
  onBookHotel,
  hotelHref = "/hotels",
}) {
  const placeImages = pkg.placesCovered?.length > 0 ? pkg.placesCovered.map((p) => p.image) : null;
  const placeNames = pkg.placesCovered?.length > 0 ? pkg.placesCovered.map((p) => p.name) : null;

  const sourceImages = images?.length > 0 ? images : placeImages || FALLBACK_IMAGES;
  const sourceNames = images?.length > 0 ? null : placeNames;

  const gallery = cycleFill(sourceImages, 4);
  const galleryNames = sourceNames ? cycleFill(sourceNames, 4) : null;

  const [mainImage, ...restImages] = gallery;
  const [mainName] = galleryNames || [];

  const handleBookHotel = (e) => {
    if (onBookHotel) {
      e.preventDefault();
      onBookHotel();
    }
  };

  return (
    <section className="bkov-wrap">
      <style>{`
        .bkov-wrap {
          position: relative;
          padding: 60px 6vw 100px;
          background-color: var(--paper, #faf9f6);
          color: var(--ink, #111111);
          overflow: hidden;
        }

        /* Ambient Dynamic Light Effects */
        .bkov-glow {
          position: absolute;
          inset: 0;
          pointer-events: none;
          z-index: 0;
        }

        .bkov-glow::before,
        .bkov-glow::after {
          content: "";
          position: absolute;
          width: 500px;
          height: 500px;
          border-radius: 50%;
          filter: blur(120px);
          opacity: 0.15;
          mix-blend-mode: multiply;
        }

        .bkov-glow::before {
          top: -200px;
          right: -100px;
          background: radial-gradient(circle, var(--gold, #d4af37), transparent 70%);
        }

        .bkov-glow::after {
          bottom: -200px;
          left: -100px;
          background: radial-gradient(circle, var(--gold-deep, #aa7c11), transparent 70%);
        }

        .bkov-inner {
          position: relative;
          z-index: 1;
          max-width: 1200px;
          margin: 0 auto;
        }

        /* Typography & Header Elements */
        .bkov-back {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: none;
          border: none;
          color: var(--ink-soft, #555555);
          font-family: var(--font-body, inherit);
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          padding: 0;
          margin-bottom: 28px;
          text-decoration: none;
          transition: color 0.2s ease, transform 0.2s ease;
        }

        .bkov-back:hover {
          color: var(--gold-deep, #aa7c11);
          transform: translateX(-2px);
        }

        .bkov-eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          font-family: var(--font-mono, monospace);
          font-size: 12px;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: var(--gold-deep, #aa7c11);
          margin-bottom: 12px;
          font-weight: 600;
        }

        .bkov-eyebrow::before {
          content: "";
          width: 24px;
          height: 1px;
          background: var(--gold-deep, #aa7c11);
          display: inline-block;
        }

        .bkov-title {
          font-family: var(--font-display, serif);
          font-weight: 700;
          font-size: clamp(32px, 4.2vw, 48px);
          margin: 0 0 12px;
          line-height: 1.15;
          letter-spacing: -0.02em;
        }

        .bkov-sub {
          color: var(--ink-soft, #555555);
          font-size: 16px;
          line-height: 1.6;
          max-width: 680px;
          margin: 0 0 44px;
        }

        /* Realigned Premium Gallery Setup */
        .bkov-gallery {
          display: grid;
          grid-template-columns: 1.5fr 1fr;
          gap: 16px;
          margin-bottom: 60px;
        }

        .bkov-gallery-main {
          position: relative;
          border-radius: var(--radius, 12px);
          overflow: hidden;
          min-height: 400px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.06);
        }

        .bkov-gallery-main img {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
        }

        .bkov-gallery-main:hover img {
          transform: scale(1.03);
        }

        .bkov-gallery-main::after {
          content: "";
          position: absolute;
          inset: 0;
          background: linear-gradient(to top, rgba(0, 0, 0, 0.75) 0%, rgba(0, 0, 0, 0.2) 40%, rgba(0, 0, 0, 0) 100%);
          z-index: 1;
        }

        .bkov-gallery-stamp {
          position: absolute;
          top: 20px;
          left: 20px;
          z-index: 2;
          font-family: var(--font-mono, monospace);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.1em;
          color: #ffffff;
          background: rgba(0, 0, 0, 0.6);
          border: 1px solid rgba(255, 255, 255, 0.2);
          padding: 6px 12px;
          border-radius: 4px;
          backdrop-filter: blur(8px);
        }

        .bkov-gallery-caption {
          position: absolute;
          bottom: 24px;
          left: 24px;
          right: 24px;
          z-index: 2;
          color: #ffffff;
        }

        .bkov-gallery-caption h3 {
          font-family: var(--font-display, serif);
          font-size: clamp(20px, 2.5vw, 28px);
          font-weight: 600;
          margin: 0;
          text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }

        .bkov-gallery-caption span {
          display: inline-block;
          font-family: var(--font-mono, monospace);
          font-size: 12px;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          background: rgba(255, 255, 255, 0.2);
          backdrop-filter: blur(4px);
          padding: 3px 8px;
          border-radius: 4px;
          margin-top: 8px;
        }

        .bkov-gallery-side {
          display: grid;
          grid-template-rows: 1.2fr 1fr;
          gap: 16px;
        }

        .bkov-gallery-thumb-row {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .bkov-thumb {
          position: relative;
          border-radius: var(--radius-sm, 8px);
          overflow: hidden;
          background: #e5e5e5;
          box-shadow: 0 10px 25px rgba(0,0,0,0.04);
        }

        .bkov-thumb img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.5s cubic-bezier(0.25, 1, 0.5, 1);
        }

        .bkov-thumb:hover img {
          transform: scale(1.05);
        }

        .bkov-thumb::after {
          content: "";
          position: absolute;
          inset: 0;
          background: linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 50%);
          z-index: 1;
        }

        .bkov-thumb-label {
          position: absolute;
          bottom: 12px;
          left: 14px;
          right: 14px;
          z-index: 2;
          color: #ffffff;
          font-family: var(--font-mono, monospace);
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* Sections and Unified Headers */
        .bkov-section {
          margin-bottom: 64px;
        }

        .bkov-section h2 {
          font-family: var(--font-display, serif);
          font-size: 24px;
          font-weight: 600;
          margin: 0 0 28px;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .bkov-section h2::before {
          content: "";
          width: 30px;
          height: 2px;
          background: var(--gold, #d4af37);
          display: inline-block;
        }

        /* Modernized Timeline Layout */
        .bkov-steps {
          position: relative;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
        }

        .bkov-steps::before {
          content: "";
          position: absolute;
          top: 40px;
          left: 10%;
          right: 10%;
          height: 0;
          border-top: 2px dashed var(--line-strong, #dddddd);
          z-index: 0;
        }

        .bkov-step {
          position: relative;
          z-index: 1;
          background: var(--paper-card, #ffffff);
          border: 1px solid var(--line, #eeeeee);
          border-radius: var(--radius-sm, 8px);
          padding: 24px 20px;
          transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .bkov-step.is-current {
          border-color: var(--gold, #d4af37);
          box-shadow: 0 15px 35px rgba(212, 175, 55, 0.1);
        }

        .bkov-step-icon {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: var(--paper-dim, #f0ede6);
          color: var(--gold-deep, #aa7c11);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
          transition: background-color 0.3s ease, color 0.3s ease;
        }

        .bkov-step.is-current .bkov-step-icon {
          background: var(--gold, #d4af37);
          color: #ffffff;
        }

        .bkov-step-label {
          font-family: var(--font-mono, monospace);
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--ink-faint, #888888);
          display: block;
          margin-bottom: 6px;
        }

        .bkov-step-title {
          font-weight: 700;
          font-size: 16px;
          margin-bottom: 8px;
        }

        .bkov-step-detail {
          font-size: 13.5px;
          line-height: 1.5;
          color: var(--ink-soft, #555555);
        }

        /* Enhanced Flex Reason Cards */
        .bkov-reasons {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .bkov-reason {
          display: flex;
          gap: 16px;
          align-items: flex-start;
          background: var(--paper-dim, #f0ede6);
          border-radius: var(--radius-sm, 8px);
          padding: 20px;
        }

        .bkov-reason-mark {
          flex-shrink: 0;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: var(--gold, #d4af37);
          color: var(--paper-card, #ffffff);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          font-weight: 700;
        }

        .bkov-reason p {
          margin: 0;
          font-size: 14.5px;
          line-height: 1.6;
          color: var(--ink-soft, #555555);
        }

        .bkov-reason strong {
          color: var(--ink, #111111);
        }

        /* What's Next Progress Track Line alignment */
        .bkov-next-list {
          list-style: none;
          margin: 0;
          padding: 0;
          border-left: 2px solid var(--line-strong, #dddddd);
        }

        .bkov-next-list li {
          position: relative;
          padding: 0 0 28px 28px;
          font-size: 15px;
          line-height: 1.6;
          color: var(--ink-soft, #555555);
        }

        .bkov-next-list li:last-child {
          padding-bottom: 0;
        }

        .bkov-next-list li::before {
          content: "";
          position: absolute;
          left: -7px;
          top: 4px;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: var(--paper, #faf9f6);
          border: 2px solid var(--gold-deep, #aa7c11);
        }

        .bkov-next-list strong {
          color: var(--ink, #111111);
        }

        /* Premium Box Bottom Callout */
        .bkov-cta {
          position: relative;
          z-index: 1;
          background: var(--paper-card, #ffffff);
          border: 1px solid var(--line-strong, #dddddd);
          border-radius: var(--radius, 12px);
          box-shadow: 0 15px 40px rgba(0,0,0,0.04);
          padding: 36px 40px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
        }

        .bkov-cta-text h3 {
          font-family: var(--font-display, serif);
          font-size: 24px;
          font-weight: 600;
          margin: 0 0 8px;
        }

        .bkov-cta-text p {
          font-size: 14px;
          color: var(--ink-soft, #555555);
          margin: 0;
          max-width: 480px;
          line-height: 1.5;
        }

        .bkov-cta-btn {
          font-family: var(--font-body, inherit);
          font-weight: 700;
          font-size: 15px;
          color: var(--paper, #faf9f6);
          background: var(--ink, #111111);
          border: none;
          border-radius: 999px;
          padding: 16px 36px;
          cursor: pointer;
          text-decoration: none;
          white-space: nowrap;
          transition: background-color 0.25s, transform 0.2s;
          display: inline-block;
          box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .bkov-cta-btn:hover {
          background: var(--gold-deep, #aa7c11);
          transform: translateY(-2px);
        }

        /* Adaptive Tablet Layouts */
        @media (max-width: 960px) {
          .bkov-gallery { grid-template-columns: 1fr; }
          .bkov-gallery-main { min-height: 320px; }
          .bkov-gallery-side { grid-template-rows: none; }
          .bkov-steps { grid-template-columns: repeat(2, 1fr); gap: 16px; }
          .bkov-steps::before { display: none; }
        }

        /* Adaptive Mobile Viewports */
        @media (max-width: 600px) {
          .bkov-wrap { padding: 40px 20px 60px; }
          .bkov-steps { grid-template-columns: 1fr; }
          .bkov-reasons { grid-template-columns: 1fr; }
          .bkov-cta { flex-direction: column; align-items: flex-start; padding: 24px; }
          .bkov-cta-btn { width: 100%; text-align: center; }
        }

        @media (prefers-reduced-motion: reduce) {
          .bkov-gallery-main img, .bkov-thumb img, .bkov-cta-btn { transition: none !important; transform: none !important; }
        }
      `}</style>

      <div className="bkov-glow" aria-hidden="true" />

      <div className="bkov-inner">
        {onBack && (
          <button className="bkov-back" onClick={onBack}>
            ← Back to package details
          </button>
        )}

        <span className="bkov-eyebrow">Step 1 of 4 · Booking overview</span>
        <h1 className="bkov-title">You're one step from {pkg.destination}</h1>
        <p className="bkov-sub">
          Here's a quick look at {pkg.package_name} before you lock in your hotel and
          transport — same trip, same price, just laid out clearly first.
        </p>

        {/* ---------- Responsive Img Gallery ---------- */}
        <div className="bkov-gallery">
          <div className="bkov-gallery-main">
            <img src={mainImage} alt={mainName || pkg.destination} loading="lazy" />
            <span className="bkov-gallery-stamp">{pkg.code}</span>
            <div className="bkov-gallery-caption">
              <h3>{pkg.package_name}</h3>
              {mainName && <span>{mainName}</span>}
            </div>
          </div>
          <div className="bkov-gallery-side">
            <div className="bkov-thumb">
              <img src={restImages[0]} alt={galleryNames?.[1] || `${pkg.destination} detail 1`} loading="lazy" />
              {galleryNames?.[1] && <span className="bkov-thumb-label">{galleryNames[1]}</span>}
            </div>
            <div className="bkov-gallery-thumb-row">
              <div className="bkov-thumb">
                <img src={restImages[1]} alt={galleryNames?.[2] || `${pkg.destination} detail 2`} loading="lazy" />
                {galleryNames?.[2] && <span className="bkov-thumb-label">{galleryNames[2]}</span>}
              </div>
              <div className="bkov-thumb">
                <img src={restImages[2]} alt={galleryNames?.[3] || `${pkg.destination} detail 3`} loading="lazy" />
                {galleryNames?.[3] && <span className="bkov-thumb-label">{galleryNames[3]}</span>}
              </div>
            </div>
          </div>
        </div>

        {/* ---------- Progress Grid Track ---------- */}
        <div className="bkov-section">
          <h2>Your booking, at a glance</h2>
          <div className="bkov-steps">
            {PROCESS_STEPS.map((step, i) => (
              <div className={`bkov-step ${i === 0 ? "is-current" : ""}`} key={step.title}>
                <span className="bkov-step-icon">
                  <StepIcon name={step.icon} />
                </span>
                <span className="bkov-step-label">{step.label}</span>
                <div className="bkov-step-title">{step.title}</div>
                <p className="bkov-step-detail">{step.detail}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ---------- Grid Reason Cards ---------- */}
        <div className="bkov-section">
          <h2>Why {pkg.package_name} is a solid pick</h2>
          <div className="bkov-reasons">
            <div className="bkov-reason">
              <span className="bkov-reason-mark">★</span>
              <p>
                Rated <strong>{pkg.rating}</strong> by solo travelers who've taken this
                exact route — the itinerary is already tested.
              </p>
            </div>
            <div className="bkov-reason">
              <span className="bkov-reason-mark">₹</span>
              <p>
                <strong>₹{pkg.price} onwards</strong>, per person, with no surprise
                add-ons — hotel and transport pricing you choose next is shown up front.
              </p>
            </div>
            <div className="bkov-reason">
              <span className="bkov-reason-mark">⏱</span>
              <p>
                A realistic <strong>{pkg.duration}</strong> pace — enough time at each
                stop, no red-eye connections stitched together.
              </p>
            </div>
            <div className="bkov-reason">
              <span className="bkov-reason-mark">✓</span>
              <p>
                Includes{" "}
                <strong>{pkg.highlights ? pkg.highlights.join(", ") : "guided highlights"}</strong>{" "}
                — the parts of this trip travelers ask about most.
              </p>
            </div>
          </div>
        </div>

        {/* ---------- Timed Event Progression ---------- */}
        <div className="bkov-section">
          <h2>What's next</h2>
          <ul className="bkov-next-list">
            <li>
              <strong>Hotel booking</strong> — pick your room for every stop on this
              itinerary. Prices update live as you choose.
            </li>
            <li>
              <strong>Transport booking</strong> — trains, private transfers, or flights
              between stops, based on what's included in this package.
            </li>
            <li>
              <strong>Confirmation</strong> — your full trip dossier, tickets, and
              hotel vouchers land in your inbox, ready before departure.
            </li>
          </ul>
        </div>

        {/* ---------- Dynamic Footer Layout ---------- */}
        <div className="bkov-cta">
          <div className="bkov-cta-text">
            <h3>Ready to pick your hotel?</h3>
            <p>This takes about two minutes — your package details carry over automatically.</p>
          </div>
          <a href={hotelHref} className="bkov-cta-btn" onClick={handleBookHotel}>
            Book Hotel
          </a>
        </div>
      </div>
    </section>
  );
}