import { useState } from "react";

const testimonials = [
  {
    quote: "Everything was confirmed within hours — hotel, flights, and a guide who actually knew the back streets.",
    initials: "MR",
    bg: "var(--teal)",
    color: "#fff",
    name: "Meera R.",
    trip: "Trip GST-0114",
  },
  {
    quote: "First trip where the itinerary didn't feel held together with tape. One trip number, four bookings, zero stress.",
    initials: "DK",
    bg: "var(--gold)",
    color: "var(--navy)",
    name: "Daniel K.",
    trip: "Trip GST-0098",
  },
  {
    quote: "We changed our dates twice and the desk re-confirmed everything same day. Worth it for that alone.",
    initials: "PA",
    bg: "var(--navy)",
    color: "#fff",
    name: "Priya & Arjun",
    trip: "Trip GST-0142",
  },
];

const faqs = [
  {
    q: "Can I book just a flight, without a full package?",
    a: "Yes — every service on this page can be booked on its own or bundled together.",
  },
  {
    q: "What happens if my flight changes last-minute?",
    a: "Our 24/7 desk re-confirms your hotel and guide automatically and texts you the new schedule.",
  },
  {
    q: "Do I need to pay for the whole trip upfront?",
    a: "Most bookings need a deposit to confirm; the balance is due before departure, not before booking.",
  },
  {
    q: "Are your tour guides licensed?",
    a: "Yes, every guide listed under GDE—04 is locally licensed and vetted by our travel desk.",
  },
];

function Servicestestimonialsfaq() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <section className="svc-testimonials">
        <div className="section-head on-light reveal">
          <p className="eyebrow">Verified Travelers</p>
          <h2>Heard at the gate.</h2>
          <p>A few notes from trips booked the same way yours will be.</p>
        </div>

        <div className="svc-testi-grid">
          {testimonials.map((t) => (
            <div className="svc-testi-card reveal" key={t.name}>
              <div className="svc-postmark">
                <i className="fa-solid fa-stamp"></i>
              </div>
              <p className="quote">"{t.quote}"</p>
              <div className="svc-testi-foot">
                <div className="svc-avatar" style={{ background: t.bg, color: t.color }}>
                  {t.initials}
                </div>
                <div className="who">
                  <b>{t.name}</b>
                  <span>{t.trip}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="svc-faq">
        <div className="section-head on-light reveal">
          <p className="eyebrow">Before You Ask</p>
          <h2>Questions, answered.</h2>
          <p>The four things every traveler checks before booking.</p>
        </div>

        <div className="svc-faq-list reveal">
          {faqs.map((item, i) => {
            const isOpen = openIndex === i;
            return (
              <div className={`svc-faq-item${isOpen ? " open" : ""}`} key={item.q}>
                <button
                  className="svc-faq-q"
                  aria-expanded={isOpen}
                  onClick={() => setOpenIndex(isOpen ? -1 : i)}
                >
                  <span className="qnum">{`Q0${i + 1}`}</span>
                  <span className="qtext">{item.q}</span>
                  <i className="fa-solid fa-chevron-down"></i>
                </button>
                <div className="svc-faq-answer">
                  <p>{item.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="svc-cta-band">
        <p className="eyebrow on-dark">Boarding Soon</p>
        <h2>Ready when you are.</h2>
        <p>Tell us where, and we'll have the stay, the seat, and the guide confirmed within the day.</p>
        <a href="/contact/" className="btn-gold">Plan My Trip</a>
      </section>
    </>
  );
}

export default Servicestestimonialsfaq;