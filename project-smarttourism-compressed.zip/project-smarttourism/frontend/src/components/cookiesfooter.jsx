import React from "react";

export default function CookiesFooter({ onManagePreferences }) {
  return (
    <footer className="site-footer">
      Global Smart Tourism &mdash;{" "}
      <button
        className="inline-link-btn"
        onClick={onManagePreferences}
        style={{ fontSize: "13px" }}
      >
        Manage Cookie Preferences
      </button>{" "}
      &middot; <a href="/">Back to Home</a>
    </footer>
  );
}
