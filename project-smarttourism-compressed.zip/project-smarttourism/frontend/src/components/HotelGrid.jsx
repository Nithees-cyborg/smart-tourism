import React from "react";
import HotelCard from "./HotelCard";

export default function HotelGrid({ hotels, onSelectHotel }) {
  return (
    <div className="hotel-grid" id="hotelGrid">
      {hotels.map((hotel) => (
        <HotelCard key={hotel.id} hotel={hotel} onClick={onSelectHotel} />
      ))}

      <div className={`no-records ${hotels.length === 0 ? "active" : ""}`} id="noResults">
        <i className="fa-regular fa-folder-open"></i>
        <p>No hotels match your search. Try a different name or destination.</p>
      </div>
    </div>
  );
}