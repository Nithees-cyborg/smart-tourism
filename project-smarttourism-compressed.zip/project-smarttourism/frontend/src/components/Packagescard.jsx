import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Packagescard({ pkg, index }) {
  const navigate = useNavigate();
  const cardRef = useRef(null);

  const [inView, setInView] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [imgSrc, setImgSrc] = useState(pkg.image);
  const [wishlisted, setWishlisted] = useState(false);

  useEffect(() => {
    const node = cardRef.current;

    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      {
        threshold: 0.1,
      }
    );

    observer.observe(node);

    return () => observer.disconnect();
  }, []);

  const handleImgError = () => {
    setImgSrc(
      `https://source.unsplash.com/600x400/?${encodeURIComponent(
        pkg.destination + " travel"
      )}`
    );
  };

  const handleBooking = () => {
    console.log("Package ID =", pkg.id);

    if (!pkg.id) {
      alert("Package ID not found.");
      return;
    }

    // redirect to Hotels page, passing the package id
    navigate(`/hotels/${pkg.id}`);
  };

  return (
    <div
      ref={cardRef}
      className={`pkg-card ${inView ? "in-view" : ""}`}
      style={{
        transitionDelay: `${index * 0.05}s`,
      }}
    >
      <div className="card-img">
        <img
          src={imgSrc}
          alt={pkg.destination}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          onError={handleImgError}
          className={loaded ? "loaded" : ""}
        />

        <div className="card-img-overlay"></div>

        <div className="dest-badge">
          <i className="fa-solid fa-location-dot"></i>
          {pkg.destination}
        </div>

        <button
          className={`wishlist-btn ${wishlisted ? "active" : ""}`}
          onClick={() => setWishlisted(!wishlisted)}
          type="button"
        >
          <i
            className={
              wishlisted
                ? "fa-solid fa-heart"
                : "fa-regular fa-heart"
            }
          ></i>
        </button>

        <div className="price-badge">
          ₹{pkg.price}
        </div>
      </div>

      <div className="card-body">
        <h3>{pkg.package_name}</h3>

        <div className="card-chips">
          <span className="chip">
            <i className="fa-solid fa-location-dot"></i>
            {pkg.destination}
          </span>

          <span className="chip">
            <i className="fa-solid fa-clock"></i>
            {pkg.duration}
          </span>

          <span className="chip">
            ⭐ {pkg.rating || 4.8}
          </span>
        </div>

        <p className="card-desc">
          {pkg.description}
        </p>

        <button
          className="btn-book"
          type="button"
          onClick={handleBooking}
        >
          <i className="fa-solid fa-bolt"></i>
          Book Now
        </button>
      </div>
    </div>
  );
}