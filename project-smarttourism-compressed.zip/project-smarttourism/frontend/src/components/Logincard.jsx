import { useRef } from "react";
import Loginheader from "./Loginheader";
import Loginform from "./Loginform";
import Loginsocial from "./Loginsocial";
import Loginfooter from "./Loginfooter";

/**
 * Logincard.jsx
 * The glass card itself: theme toggle, scan-line, brand header, error list,
 * the form, social buttons, and footer. Handles the 3D mouse-tilt effect.
 */
export default function Logincard({
  darkMode,
  onToggleTheme,
  errors = [],
  onSubmit,
  isSubmitting,
  csrfToken,
}) {
  const cardRef = useRef(null);

  const handleMouseMove = (e) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = (e.clientX - cx) / rect.width;
    const dy = (e.clientY - cy) / rect.height;

    card.style.transform = `perspective(900px) rotateY(${dx * 6}deg) rotateX(${
      -dy * 5
    }deg)`;
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;

    card.style.transition = "transform 0.6s ease";
    card.style.transform = "";

    setTimeout(() => {
      if (card) card.style.transition = "";
    }, 600);
  };

  return (
    <div className="login-wrapper">
      <div
        className="login-card"
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <div className="scan-line" />

        {/* Dark / Light Mode Toggle */}
        <button
          className="theme-toggle"
          type="button"
          aria-label="Toggle dark mode"
          onClick={onToggleTheme}
        >
          {darkMode ? "☀️" : "🌙"}
        </button>

        {/* Logo */}
        <div className="login-logo">
          <img
            src="/logo.png"
            alt="Global Smart Tourism"
            className="login-logo-img"
          />
          <h2 className="login-logo-title">
            Global Smart Tourism
          </h2>
        </div>

        <Loginheader />

        {errors.length > 0 && (
          <div className="error-list">
            <strong>Please fix the following:</strong>
            <ul>
              {errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        <Loginform
          onSubmit={onSubmit}
          isSubmitting={isSubmitting}
          csrfToken={csrfToken}
        />

        <Loginsocial />

        <Loginfooter />
      </div>
    </div>
  );
}