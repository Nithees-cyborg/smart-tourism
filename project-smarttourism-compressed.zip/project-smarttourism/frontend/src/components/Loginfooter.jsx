/**
 * Loginfooter.jsx
 * "New here? Create a free account" link + trust badges row.
 */
export default function Loginfooter() {
  return (
    <>
      <div className="signup-row">
        New here? <a href="/signup/">Create a free account →</a>
      </div>

      <div className="trust-badges">
        <div className="trust-item">
          <div className="trust-dot" />
          256-bit SSL
        </div>
        <div className="trust-item">
          <div className="trust-dot" />
          SOC 2 certified
        </div>
        <div className="trust-item">
          <div className="trust-dot" />
          GDPR compliant
        </div>
      </div>
    </>
  );
}