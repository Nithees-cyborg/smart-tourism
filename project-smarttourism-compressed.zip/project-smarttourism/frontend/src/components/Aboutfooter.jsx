import { useEffect, useState } from "react";

export function Aboutcta() {
  return (
    <div className="cta-wrap">
      <div className="pass reveal">
        <div className="pass-main">
          <p className="eyebrow">Ready to Travel?</p>
          <h2>Let's Plan Your<br /><em>Next Adventure</em></h2>
          <p>
            Whether it's a solo escape, a family holiday, or a honeymoon you've been planning for
            years — we're here to make it happen, exactly the way you imagined it.
          </p>
          <div className="hero-btns">
            <a href="/packages/" className="btn primary">
              <i className="fa-solid fa-map-location-dot"></i> Browse Packages
            </a>
            <a href="/contact/" className="btn ghost">
              <i className="fa-solid fa-phone"></i> Talk to an Expert
            </a>
          </div>
        </div>
        <div className="pass-stub">
          <div className="stub-row">Passenger<b>You</b></div>
          <div className="stub-row">Destination<b>Anywhere You Choose</b></div>
          <div className="stub-row">Status<b style={{ color: "var(--gold)" }}>Confirmed</b></div>
        </div>
      </div>
    </div>
  );
}

export function Aboutfooter() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <footer className="footer">
        <div className="footer-top">
          <div className="footer-brand">
            <h3>Global <em>Smart</em> Tourism</h3>
            <p>
              Premium travel operations and destination management — delivering unforgettable global
              experiences since 2012.
            </p>
            <div className="socials">
              <a href="#" className="soc-btn" aria-label="Facebook"><i className="fa-brands fa-facebook-f"></i></a>
              <a href="#" className="soc-btn" aria-label="Instagram"><i className="fa-brands fa-instagram"></i></a>
              <a href="#" className="soc-btn" aria-label="X / Twitter"><i className="fa-brands fa-x-twitter"></i></a>
              <a href="#" className="soc-btn" aria-label="LinkedIn"><i className="fa-brands fa-linkedin-in"></i></a>
              <a href="#" className="soc-btn" aria-label="YouTube"><i className="fa-brands fa-youtube"></i></a>
            </div>
          </div>

          <div className="footer-col">
            <h4>Explore</h4>
            <ul>
              <li><a href="/packages/">Tour Packages</a></li>
              <li><a href="/hotels/">Partner Hotels</a></li>
              <li><a href="/bookings/">My Bookings</a></li>
              <li><a href="/payments/">Payments</a></li>
              <li><a href="/about/">About Us</a></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Destinations</h4>
            <ul>
              <li><a href="/packages/">Goa</a></li>
              <li><a href="/packages/">Kerala</a></li>
              <li><a href="/packages/">Dubai</a></li>
              <li><a href="/packages/">Maldives</a></li>
              <li><a href="/packages/">Paris</a></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Contact Us</h4>
            <div className="footer-contact-item"><i className="fa-solid fa-envelope"></i> support@gst.com</div>
            <div className="footer-contact-item"><i className="fa-solid fa-phone"></i> +91 98765 43210</div>
            <div className="footer-contact-item"><i className="fa-solid fa-location-dot"></i> Mumbai &middot; Dubai &middot; Coimbatore</div>
            <div className="footer-contact-item"><i className="fa-solid fa-clock"></i> Mon–Sat, 9am–7pm</div>
          </div>
        </div>

        <div className="footer-bottom">
          <span>&copy; 2026 Global Smart Tourism. All Rights Reserved.</span>
          <div className="footer-legal">
            <a href="/privacy/">Privacy Policy</a>
            <a href="/terms/">Terms of Use</a>
            <a href="/cookies/">Cookies</a>
          </div>
        </div>
      </footer>

      <button
        className={`to-top${showTop ? " show" : ""}`}
        aria-label="Back to top"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        <i className="fa-solid fa-arrow-up"></i>
      </button>
    </>
  );
}

export default Aboutfooter;