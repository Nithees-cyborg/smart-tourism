import React from "react";
import payImg from "../assets/images/pay.jpg";

export default function Payment_SuccessCustomerCard({ booking, paymentMethod }) {
  return (
    <div className="card">
      <div className="card-title">👤 Customer Details</div>

      <div className="info-row">
        <span className="info-label">Name</span>
        <span className="info-val">{booking.customer.full_name}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Email</span>
        <span className="info-val">{booking.customer.email}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Phone</span>
        <span className="info-val">{booking.customer.phone}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Payment via</span>
        <span className="info-val">{paymentMethod}</span>
      </div>

      <div className="img-wrapper">
        <img src={payImg} alt="Destination" />
        <div className="img-caption">{booking.package.destination}</div>
      </div>
    </div>
  );
}