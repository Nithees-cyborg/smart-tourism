import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function ContactFormSection() {
  const navigate = useNavigate();
  const [status, setStatus] = useState({ sending: false, sent: false, error: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));

    setStatus({ sending: true, sent: false, error: "" });

    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/api/contact/",
        {
          name: data.name,
          email: data.email,
          phone: data.phone,
          subject: data.subject,
          message: data.message,
        },
        { withCredentials: true }
      );

      setStatus({ sending: false, sent: true, error: "" });
      e.target.reset();

      // Send the backend-generated ref id + timestamp to the success page
      navigate("/contact-success", {
        state: {
          refId: res.data.ref_id,
          submittedOn: res.data.created_at,
        },
      });
    } catch (err) {
      const msg =
        err.response?.data?.message ||
        err.response?.data?.detail ||
        "Something went wrong. Please try again.";
      setStatus({ sending: false, sent: false, error: msg });
    }
  };

  return (
    <div className="contact-wrap">
      <div className="container">

        <div className="card contact-form reveal">
          <div className="card-head">
            <p className="eyebrow">We Reply Within 1 Hour</p>
            <h2>Send Us a Message</h2>
            <p>Fill in the details below and a travel specialist will get back to you — usually the same day.</p>
          </div>

          {status.sent && <div className="form-success">Thanks — your message has been sent!</div>}
          {status.error && <div className="form-error">{status.error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="field-row">
              <input type="text" name="name" placeholder="Full Name" required />
              <input type="text" name="phone" placeholder="Phone Number" required />
            </div>

            <input type="email" name="email" placeholder="Email Address" required />

            <select name="subject" defaultValue="" required>
              <option value="" disabled>What's this about?</option>
              <option value="general">General Inquiry</option>
              <option value="package">Package Booking</option>
              <option value="hotel">Hotel Reservation</option>
              <option value="cancellation">Cancellation / Refund</option>
              <option value="visa">Visa Assistance</option>
              <option value="group">Group / Corporate Booking</option>
            </select>

            <textarea name="message" rows="6" placeholder="Type your message..." required></textarea>

            <label className="consent">
              <input type="checkbox" name="updates" />
              Send me occasional trip ideas and seasonal offers. No spam, unsubscribe anytime.
            </label>

            <button type="submit" disabled={status.sending}>
              <i className="fa-solid fa-paper-plane"></i> {status.sending ? "Sending..." : "Send Message"}
            </button>
          </form>

          <p className="form-note">Prefer to talk it through? Call <a href="tel:+919876543210">+91 98765 43210</a> — we're up at 3am too.</p>
        </div>

        <div className="card contact-info reveal">
          <div className="card-head">
            <p className="eyebrow">Customer Care, Anytime</p>
            <h2>Talk to a Human</h2>
          </div>

          <div className="info-list">
            <div className="info-tile"><i className="fa-solid fa-phone"></i><div><b>+91 98765 43210</b><span>General bookings &amp; enquiries</span></div></div>
            <div className="info-tile"><i className="fa-solid fa-headset"></i><div><b>+91 91234 56780</b><span>Existing booking support</span></div></div>
            <div className="info-tile"><i className="fa-solid fa-envelope"></i><div><b>support@globalsmarttourism.com</b><span>General questions</span></div></div>
            <div className="info-tile"><i className="fa-solid fa-suitcase-rolling"></i><div><b>bookings@globalsmarttourism.com</b><span>Existing trips &amp; reservations</span></div></div>
            <div className="info-tile"><i className="fa-solid fa-location-dot"></i><div><b>Chennai, Tamil Nadu, India</b><span>Customer care centre — walk-ins welcome</span></div></div>
            <div className="info-tile"><i className="fa-solid fa-clock"></i><div><b>24/7 Travel Assistance</b><span>Someone's always on call</span></div></div>
          </div>

          <div className="support-box">
            <h3><i className="fa-solid fa-circle-question"></i> Need Immediate Help?</h3>
            <p>Our tourism experts are available 24/7 to help with package bookings, hotel reservations, cancellations, refunds, visa assistance, and on-trip guidance — wherever you are in the world.</p>
          </div>

          <div className="info-socials">
            <a href="#" aria-label="Facebook"><i className="fa-brands fa-facebook-f"></i></a>
            <a href="#" aria-label="Instagram"><i className="fa-brands fa-instagram"></i></a>
            <a href="#" aria-label="X / Twitter"><i className="fa-brands fa-x-twitter"></i></a>
            <a href="#" aria-label="LinkedIn"><i className="fa-brands fa-linkedin-in"></i></a>
            <a href="#" aria-label="WhatsApp"><i className="fa-brands fa-whatsapp"></i></a>
          </div>
        </div>

      </div>
    </div>
  );
}