import React from "react";

const CHIP_KEYWORDS = ["Trending", "Bestseller", "New", "Beach", "Mountains", "Culture"];

export default function Packagesgrid({ packages, search, onSelectChip, onClear, onSelectPackage }) {
  return (
    <section className="pkg-section" id="packages">
      <div className="pkg-section-head">
        <span className="pkg-eyebrow">Single-traveler packages</span>
        <h2>Pick a place. See the whole trip.</h2>
        <p>
          Every card shows the price for one traveler up front. Tap any package to see the
          full day-by-day itinerary, places covered, and transport details before you book.
        </p>
      </div>

      <div className="pkg-toolbar">
        {CHIP_KEYWORDS.map((kw) => (
          <button
            key={kw}
            className={`pkg-chip ${search.toLowerCase() === kw.toLowerCase() ? "active" : ""}`}
            onClick={() => onSelectChip(kw)}
          >
            {kw}
          </button>
        ))}
        {search && (
          <button className="pkg-clear" onClick={onClear}>
            Clear filter “{search}”
          </button>
        )}
      </div>

      <p className="pkg-result-count">
        {packages.length} package{packages.length !== 1 ? "s" : ""} found
      </p>

      {packages.length === 0 ? (
        <div className="pkg-empty">
          No packages match “{search}”. Try a different destination or clear the filter.
        </div>
      ) : (
        <div className="pkg-grid">
          {packages.map((pkg) => (
            <button
              key={pkg.id}
              className="pkg-card"
              onClick={() => onSelectPackage(pkg.id)}
              aria-label={`View details for ${pkg.package_name}`}
            >
              <div className="pkg-card-media">
                <img src={pkg.image} alt={pkg.destination} loading="lazy" />
                <span className="pkg-code">{pkg.code}</span>
                {pkg.tag && (
                  <span className="pkg-stamp">
                    <span>{pkg.tag}</span>
                  </span>
                )}
                <span className="pkg-card-dest">{pkg.destination}</span>
              </div>

              <div className="pkg-card-body">
                <div className="pkg-card-name">{pkg.package_name}</div>
                <div className="pkg-tagline">{pkg.tagline || pkg.description}</div>

                <div className="pkg-highlights">
                  {pkg.highlights?.slice(0, 3).map((h) => (
                    <span className="pkg-highlight-chip" key={h}>
                      {h}
                    </span>
                  ))}
                </div>

                <div className="pkg-card-meta">
                  <span>{pkg.duration}</span>
                  <span className="pkg-rating">★ {pkg.rating}</span>
                </div>

                <div className="pkg-card-footer">
                  <div>
                    <span className="pkg-price-label">Per person</span>
                    <span className="pkg-price">
                      ₹{pkg.price} <small>onwards</small>
                    </span>
                  </div>
                  <span className="pkg-view-btn">View details</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}