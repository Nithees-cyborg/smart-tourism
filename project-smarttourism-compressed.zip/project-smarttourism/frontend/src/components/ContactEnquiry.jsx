import { useState } from 'react';

export default function ContactEnquiry() {
  const [dateFocused, setDateFocused] = useState(false);
  const [dateValue, setDateValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    console.log('Enquiry submitted:', data);
    // TODO: connect to your API
  };

  return (
    <div className="sec enquiry-sec">
      <div className="enquiry-card reveal">
        <div className="enquiry-text">
          <p className="eyebrow on-dark">Plan My Trip</p>
          <h2>Get a Free Custom Quote</h2>
          <p>Tell us where you want to go and when, and a specialist will put together a tailored itinerary and price — usually within a few hours.</p>
          <ul className="enquiry-points">
            <li><i className="fa-solid fa-check"></i> No obligation, completely free</li>
            <li><i className="fa-solid fa-check"></i> Personalized itinerary, not a template</li>
            <li><i className="fa-solid fa-check"></i> Best price guarantee on every package</li>
          </ul>
        </div>

        <form className="enquiry-form" onSubmit={handleSubmit}>
          <div className="field-row">
            <input type="text" name="enquiry_destination" placeholder="Destination (e.g. Goa, Dubai)" required />
            <input
              type={dateFocused || dateValue ? 'date' : 'text'}
              name="enquiry_date"
              placeholder="Travel Date"
              value={dateValue}
              onFocus={() => setDateFocused(true)}
              onBlur={() => !dateValue && setDateFocused(false)}
              onChange={(e) => setDateValue(e.target.value)}
              required
            />
          </div>

          <div className="field-row">
            <select name="enquiry_travelers" defaultValue="" required>
              <option value="" disabled>Number of Travelers</option>
              <option value="1">1 Traveler</option>
              <option value="2">2 Travelers</option>
              <option value="3-5">3–5 Travelers</option>
              <option value="6+">6+ Travelers</option>
            </select>

            <select name="enquiry_budget" defaultValue="" required>
              <option value="" disabled>Budget (per person)</option>
              <option value="under-25k">Under ₹25,000</option>
              <option value="25k-50k">₹25,000 – ₹50,000</option>
              <option value="50k-1l">₹50,000 – ₹1,00,000</option>
              <option value="1l-plus">₹1,00,000+</option>
            </select>
          </div>

          <input type="tel" name="enquiry_phone" placeholder="Phone Number" required />

          <button type="submit"><i className="fa-solid fa-paper-plane"></i> Request My Quote</button>
          <p className="enquiry-note">No spam — just a tailored quote from a real travel specialist.</p>
        </form>
      </div>
    </div>
  );
}