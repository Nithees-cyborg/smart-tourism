import React from "react";
import logo from "../assets/logo.png"; // adjust path to wherever your logo actually lives

export default function Packagesfooter() {
  const [imgFailed, setImgFailed] = React.useState(false);

  return (
    <footer
      id="contact"
      style={{
        borderTop: "1px solid var(--line)",
        padding: "40px 6vw",
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "space-between",
        gap: 20,
        fontSize: 13.5,
        color: "var(--ink-soft)",
      }}
    >
      <div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            marginBottom: 10,
          }}
        >
          {!imgFailed ? (
            <img
              src={logo}
              alt="Global Smart Tourism Logo"
              onError={() => setImgFailed(true)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                objectFit: "cover",
                flexShrink: 0,
              }}
            />
          ) : (
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                flexShrink: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "linear-gradient(135deg, var(--gold-deep), var(--gold, #e3a83e))",
                color: "#fff",
                fontSize: 14,
              }}
            >
              <i className="fa-solid fa-earth-asia"></i>
            </div>
          )}
          <div
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: 18,
              color: "var(--ink)",
            }}
          >
            Global <span style={{ color: "var(--gold-deep)" }}>Smart</span> Tourism
          </div>
        </div>
        <p style={{ maxWidth: 320, margin: 0 }}>
          Single-traveler tour packages, planned down to the day.
        </p>
      </div>
      <div>© {new Date().getFullYear()} Global Smart Tourism. All rights reserved.</div>
    </footer>
  );
}