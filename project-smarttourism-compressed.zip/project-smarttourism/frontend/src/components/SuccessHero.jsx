import React from "react";

// Green hero/banner section with the check mark and progress steps
export default function SuccessHero() {
  return (
    <div className="hero-section">
      <div className="check-ring">✓</div>
      <h1>Payment Successful &amp; Booking Confirmed!</h1>
      <p>
        Thank you for choosing <strong>Global Smart Tourism</strong>. Your
        journey is all set.
      </p>

      <div className="progress-bar">
        <div className="step">
          <div className="step-dot">✓</div> Booked
        </div>
        <div className="step-line"></div>

        <div className="step">
          <div className="step-dot">✓</div> Payment Done
        </div>
        <div className="step-line"></div>

        <div className="step">
          <div className="step-dot">✓</div> Confirmed
        </div>
        <div className="step-line"></div>

        <div className="step">
          <div className="step-dot pending">✈</div> Travel
        </div>
      </div>
    </div>
  );
}