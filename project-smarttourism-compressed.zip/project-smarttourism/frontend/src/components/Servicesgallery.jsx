const postcards = [
  { name: "Stay", img: "/images/hotel.jpg", alt: "A luxury hotel booked through Global Smart Tourism" },
  { name: "Flight", img: "/images/flight.jpg", alt: "A flight booked through Global Smart Tourism" },
  { name: "Package", img: "/images/package.jpg", alt: "A holiday package booked through Global Smart Tourism" },
  { name: "Guide", img: "/images/guide.jpg", alt: "A tour guide booked through Global Smart Tourism" },
];

function Servicesgallery() {
  return (
    <section className="svc-gallery">
      <div className="section-head on-dark reveal">
        <p className="eyebrow on-dark">From The Road</p>
        <h2>What's already booked, today.</h2>
        <p>A quick look at the four services in motion — postmarked and confirmed.</p>
      </div>

      <div className="svc-gallery-grid">
        {postcards.map((p) => (
          <div className="svc-postcard reveal" key={p.name}>
            <div className="svc-tape"></div>
            <img src={p.img} alt={p.alt} />
            <div className="svc-postcard-cap">
              <span className="name">{p.name}</span>
              <span className="stamp">Confirmed</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Servicesgallery;