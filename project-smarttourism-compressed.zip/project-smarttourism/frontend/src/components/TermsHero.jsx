export default function TermsHero() {
  return (
    <section
      className="legal-hero"
      style={{
        backgroundImage:
          "linear-gradient(175deg, rgba(16,45,89,.93) 0%, rgba(8,18,38,.96) 100%), url(/terms.jpg)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="legal-hero-inner">
        <p className="legal-crumb">
          <a href="/">Home</a>
          <span>/</span>Terms of Use
        </p>
        <p className="eyebrow on-dark">Legal</p>
        <h1>
          The <em>Fine Print</em>, Written Plainly
        </h1>
        <p>
          These Terms of Use govern your access to and use of Global Smart Tourism's website, app,
          and booking services. By booking a trip with us or creating an account, you're agreeing to
          the terms below — so it's worth a read before you click "Confirm Booking."
        </p>
        <div className="legal-meta">
          <span className="legal-meta-item">
            Effective Date: <b>January 1, 2026</b>
          </span>
          <span className="legal-meta-item">
            Last Updated: <b>June 29, 2026</b>
          </span>
        </div>
      </div>
    </section>
  );
}