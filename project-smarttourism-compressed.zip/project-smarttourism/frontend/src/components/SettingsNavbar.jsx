import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Home,
  Info,
  Briefcase,
  ArrowLeft,
  UserCircle2,
} from "lucide-react";
import logo from "../assets/logo.png"; // adjust path to wherever logo.png actually lives

const LINKS = [
  { to: "/", label: "Home", Icon: Home },
  { to: "/about", label: "About", Icon: Info },
  { to: "/services", label: "Services", Icon: Briefcase },
];

export default function SettingsNavbar() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="settings-navbar">
      <div className="settings-logo">
        <Link to="/">
          <img src={logo} alt="Global Smart Tourism" height={28} />
          <span>Global Smart Tourism</span>
        </Link>
      </div>

      <ul className="settings-nav-links">
        {LINKS.map(({ to, label, Icon }) => (
          <li key={to}>
            <Link to={to} className={location.pathname === to ? "active" : ""}>
              <Icon size={16} strokeWidth={2.25} />
              {label}
            </Link>
          </li>
        ))}

        <li>
          <button
            type="button"
            className="nav-back-btn"
            onClick={() => navigate(-1)}
            aria-label="Go back"
          >
            <ArrowLeft size={16} strokeWidth={2.25} />
            Back
          </button>
        </li>
      </ul>

      <div className="settings-profile">
        <button className="profile-btn" aria-label="Account">
          <UserCircle2 size={24} strokeWidth={2} />
        </button>
      </div>
    </nav>
  );
}