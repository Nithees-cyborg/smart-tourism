import { useState } from 'react';

const faqs = [
  { q: 'How fast will I actually get a reply?', a: "Form and email enquiries are answered within one business hour during the day, and by the next morning if sent overnight. For anything urgent — a flight delay, a hotel issue, a cancellation in progress — call the support line; it's staffed 24/7." },
  { q: 'Can I change or cancel a booking I already made?', a: 'Yes. Select "Cancellation / Refund" in the form above, or call our support line directly, and include your booking reference. Most changes are confirmed within a few hours, subject to the hotel or airline\'s own policy.' },
  { q: 'Do you help with visa applications?', a: 'We do — our visa assistance covers document checklists, appointment scheduling, and application tracking for most destinations we sell packages to. Select "Visa Assistance" in the form and a specialist will outline exactly what\'s needed for your destination.' },
  { q: 'Is there a faster way to reach you than email?', a: 'Phone and WhatsApp are both faster than email for time-sensitive questions. Use the WhatsApp icon above or call +91 98765 43210 directly — both are monitored around the clock.' },
  { q: 'Do you handle group or corporate bookings?', a: 'Yes, for groups of 8 or more, or recurring corporate travel. Select "Group / Corporate Booking" in the form with your headcount and rough dates, and a dedicated specialist will follow up with group rates.' },
];

export default function ContactMapFaq() {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <>
      <div className="map-bg">
        <div className="sec">
          <div className="map-grid">
            <div className="map-text reveal">
              <p className="eyebrow">Find Us</p>
              <h2>Our Chennai Care Centre</h2>
              <p>Head office support is based in Chennai, with regional travel desks in Mumbai, Dubai, and Coimbatore for in-person consultations closer to you.</p>
              <div className="map-detail"><i className="fa-solid fa-location-dot"></i><div><b>Address</b><span>Global Smart Tourism, Chennai, Tamil Nadu, India</span></div></div>
              <div className="map-detail"><i className="fa-solid fa-clock"></i><div><b>Walk-in Hours</b><span>Mon–Sat, 9am–7pm · Phone &amp; chat support 24/7</span></div></div>
              <div className="map-detail"><i className="fa-solid fa-car"></i><div><b>Parking</b><span>Free visitor parking available on-site</span></div></div>
              <a href="https://www.google.com/maps/search/?api=1&query=Chennai,Tamil+Nadu,India" target="_blank" rel="noopener noreferrer" className="btn outline" style={{ marginTop: 10 }}>
                <i className="fa-solid fa-diamond-turn-right"></i> Get Directions
              </a>
            </div>
            <div className="map-frame reveal">
              <iframe
                src="https://maps.google.com/maps?q=Chennai,%20Tamil%20Nadu,%20India&t=&z=12&ie=UTF8&iwloc=&output=embed"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
                title="Map showing Global Smart Tourism's Chennai care centre"
              ></iframe>
            </div>
          </div>
        </div>
      </div>

      <div className="sec">
        <div className="sec-head reveal">
          <p className="eyebrow" style={{ justifyContent: 'center' }}>Before You Reach Out</p>
          <h2 className="sec-title">Quick Answers</h2>
          <p className="sec-sub">The questions we hear most, answered up front.</p>
        </div>
        <div className="faq-list">
          {faqs.map((f, i) => (
            <details
              className="faq-item reveal"
              key={f.q}
              open={openIndex === i}
              onClick={(e) => {
                e.preventDefault();
                setOpenIndex(openIndex === i ? null : i);
              }}
            >
              <summary>{f.q}</summary>
              <p>{f.a}</p>
            </details>
          ))}
        </div>
      </div>

      <div className="status-strip">
        <span className="status-dot"></span>
        <p>Our support line is online right now &mdash; call <a href="tel:+919876543210">+91 98765 43210</a> or use the form above.</p>
      </div>
    </>
  );
}