import React from 'react';

export default function Signupfooter() {
  return (
    <>
      <div className="login-row">
        Already have an account? <a href="/login/">Sign in →</a>
      </div>

      <div className="trust-badges">
        <div className="trust-item">
          <div className="trust-dot" />
          256-bit SSL
        </div>
        <div className="trust-item">
          <div className="trust-dot" />
          Free forever
        </div>
        <div className="trust-item">
          <div className="trust-dot" />
          No spam
        </div>
      </div>
    </>
  );
}