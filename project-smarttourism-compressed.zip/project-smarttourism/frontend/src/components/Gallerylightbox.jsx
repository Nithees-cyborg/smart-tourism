import React, { useEffect, useRef, useState } from 'react';

const Gallerylightbox = ({
  images,
  categories,
  currentIndex,
  setCurrentIndex,
  isOpen,
  closeLightbox,
  favorites,
  toggleFavorite,
}) => {
  const [loaded, setLoaded] = useState(false);
  const filmstripRef = useRef(null);

  const navLightbox = (direction) => {
    setCurrentIndex((prev) => (prev + direction + images.length) % images.length);
  };

  useEffect(() => {
    setLoaded(false);
  }, [currentIndex]);

  useEffect(() => {
    if (!isOpen) return undefined;

    const handleKey = (e) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') navLightbox(-1);
      if (e.key === 'ArrowRight') navLightbox(1);
      if (e.key.toLowerCase() === 'f') toggleFavorite(currentIndex);
    };

    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, currentIndex]);

  useEffect(() => {
    const activeThumb = filmstripRef.current?.querySelector('.active-thumb');
    if (activeThumb) {
      activeThumb.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  }, [currentIndex]);

  if (!isOpen) return null;

  const isFav = favorites.has(currentIndex);

  return (
    <div
      className="lightbox-overlay active"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeLightbox();
      }}
    >
      <div className="lightbox-toolbar">
        <button
          className={`lightbox-action ${isFav ? 'is-favorited' : ''}`}
          onClick={() => toggleFavorite(currentIndex)}
          aria-label="Save to favorites"
        >
          <i className={isFav ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}></i>
        </button>
        <a className="lightbox-action" href={images[currentIndex]} download aria-label="Download photo">
          <i className="fa-solid fa-download"></i>
        </a>
      </div>

      <button className="lightbox-close" onClick={closeLightbox} aria-label="Close">
        <i className="fa-solid fa-xmark"></i>
      </button>

      <div className="lightbox-stage">
        <button className="lightbox-nav lightbox-prev" onClick={() => navLightbox(-1)} aria-label="Previous photo">
          <i className="fa-solid fa-chevron-left"></i>
        </button>
        <img
          id="lightboxImg"
          src={images[currentIndex]}
          alt={`Gallery photo ${currentIndex + 1}`}
          className={loaded ? 'is-loaded' : ''}
          onLoad={() => setLoaded(true)}
        />
        <button className="lightbox-nav lightbox-next" onClick={() => navLightbox(1)} aria-label="Next photo">
          <i className="fa-solid fa-chevron-right"></i>
        </button>
      </div>

      <div className="lightbox-meta">
        <span>{String(currentIndex + 1).padStart(2, '0')} / {images.length}</span>
        &nbsp;&middot;&nbsp;
        <span>{categories[currentIndex]}</span>
      </div>

      <div className="lightbox-filmstrip" ref={filmstripRef}>
        {images.map((src, idx) => (
          <img
            key={idx}
            src={src}
            className={`filmstrip-thumb ${idx === currentIndex ? 'active-thumb' : ''}`}
            onClick={() => setCurrentIndex(idx)}
            alt={`Thumbnail ${idx + 1}`}
            loading="lazy"
          />
        ))}
      </div>
    </div>
  );
};

export default Gallerylightbox;