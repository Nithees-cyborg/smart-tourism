import React from "react";

const STATS = [
  { value: "33+", label: "Curated destinations" },
  { value: "4.8", label: "Average trip rating" },
  { value: "1", label: "Traveler minimum" },
  { value: "24/7", label: "Trip support" },
];

export default function Packagesstats() {
  return (
    <section
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
        gap: 24,
        padding: "0 6vw 60px",
        maxWidth: 1100,
        margin: "0 auto",
      }}
    >
      {STATS.map((s) => (
        <div key={s.label} style={{ textAlign: "center" }}>
          <div
            style={{
              fontFamily: "var(--font-display)",
              fontSize: 34,
              fontWeight: 600,
              color: "var(--gold-deep)",
            }}
          >
            {s.value}
          </div>
          <div style={{ fontSize: 13, color: "var(--ink-soft)", marginTop: 4 }}>{s.label}</div>
        </div>
      ))}
    </section>
  );
}