import { useEffect, useState } from "react";

export default function TermsFooter() {
  const [showToTop, setShowToTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowToTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <>
      <footer className="footer">
        <div className="footer-top">
          <div className="footer-brand">
            <h3>
              Global <em>Smart</em> Tourism
            </h3>
            <p>
              Premium travel operations and destination management — delivering unforgettable global
              experiences since 2012.
            </p>
            <div className="socials">
              <a href="#" className="soc-btn" aria-label="Facebook"><i className="fa-brands fa-facebook-f"></i></a>
              <a href="#" className="soc-btn" aria-label="Instagram"><i className="fa-brands fa-instagram"></i></a>
              <a href="#" className="soc-btn" aria-label="X / Twitter"><i className="fa-brands fa-x-twitter"></i></a>
              <a href="#" className="soc-btn" aria-label="LinkedIn"><i className="fa-brands fa-linkedin-in"></i></a>
              <a href="#" className="soc-btn" aria-label="YouTube"><i className="fa-brands fa-youtube"></i></a>
            </div>
          </div>

          <div className="footer-col">
            <h4>Explore</h4>
            <ul>
              <li><a href="/packages/">Tour Packages</a></li>
              <li><a href="/hotels/">Partner Hotels</a></li>
              <li><a href="/bookings/">My Bookings</a></li>
              <li><a href="/payments/">Payments</a></li>
              <li><a href="/about/">About Us</a></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Destinations</h4>
            <ul>
              <li><a href="/packages/">Goa</a></li>
              <li><a href="/packages/">Kerala</a></li>
              <li><a href="/packages/">Dubai</a></li>
              <li><a href="/packages/">Maldives</a></li>
              <li><a href="/packages/">Paris</a></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Contact Us</h4>
            <div className="footer-contact-item"><i className="fa-solid fa-envelope"></i> support@gst.com</div>
            <div className="footer-contact-item"><i className="fa-solid fa-phone"></i> +91 98765 43210</div>
            <div className="footer-contact-item"><i className="fa-solid fa-location-dot"></i> Mumbai &middot; Dubai &middot; Coimbatore</div>
            <div className="footer-contact-item"><i className="fa-solid fa-clock"></i> Mon–Sat, 9am–7pm</div>
          </div>
        </div>

        <div className="footer-bottom">
          <span>&copy; 2026 Global Smart Tourism. All Rights Reserved.</span>
          <div className="footer-legal">
            <a href="/privacy/">Privacy Policy</a>
            <a href="/terms/" className="active">Terms of Use</a>
            <a href="/cookies/">Cookies</a>
          </div>
        </div>
      </footer>

      <button
        className={`to-top${showToTop ? " show" : ""}`}
        aria-label="Back to top"
        onClick={scrollToTop}
      >
        <i className="fa-solid fa-arrow-up"></i>
      </button>
    </>
  );
}