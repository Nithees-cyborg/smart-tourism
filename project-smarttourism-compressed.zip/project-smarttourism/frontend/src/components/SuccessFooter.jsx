import React from "react";

// Bottom dark support bar
export default function SuccessFooter() {
  return (
    <div className="support-bar">
      <div className="sup-item">📞 +91 98765 00000</div>
      <div className="sup-item">✉ support@globaltourism.com</div>
      <div className="sup-item">🕐 24/7 Customer Support</div>
    </div>
  );
}