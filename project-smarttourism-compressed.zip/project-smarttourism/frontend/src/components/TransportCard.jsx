// TransportCard.jsx (src/components/TransportCard.jsx)
import { Car, Bus as BusIcon, Star, Clock, Users, MapPin } from "lucide-react";

export default function TransportCard({ option, selected, onSelect }) {
  const isCab = option.mode === "cab";

  return (
    <button
      type="button"
      onClick={() => onSelect(option.id)}
      className={`fc-card ${selected ? "fc-selected" : ""}`}
      aria-pressed={selected}
    >
      {option.rating >= 4.5 && (
        <div className="fc-top-badge">
          <Star size={12} fill="currentColor" /> Top Rated
        </div>
      )}

      <div className="tc-photo" style={{ backgroundImage: `url(${option.image})` }} />

      <div className="fc-main">
        <div className="fc-header">
          <div className="fc-airline">
            <div className="fc-icon-wrapper">
              {isCab ? (
                <Car size={16} className="fc-plane-icon" />
              ) : (
                <BusIcon size={16} className="fc-plane-icon" />
              )}
            </div>
            <div className="fc-airline-info">
              <span className="fc-airline-name">{isCab ? option.provider : option.operator}</span>
              <span className="fc-flight-num">{isCab ? option.vehicleType : option.busType}</span>
            </div>
          </div>
          <span className="fc-cabin-badge">
            {isCab ? `${option.capacity} seater` : `${option.seatsAvailable} seats left`}
          </span>
        </div>

        {isCab ? (
          <div className="tc-cab-row">
            <div className="tc-cab-meta">
              <Clock size={14} /> Pickup in {option.etaMins} mins
            </div>
            <div className="tc-cab-meta">
              <MapPin size={14} /> Trip time {option.duration}
            </div>
          </div>
        ) : (
          <div className="fc-route">
            <div className="fc-time block-start">
              <div className="fc-time-val">{option.departTime}</div>
              <div className="fc-time-code">Boarding</div>
            </div>

            <div className="fc-mid">
              <div className="fc-mid-meta">{option.duration}</div>
              <div className="fc-mid-line">
                <span className="fc-dot" />
                <div className="fc-clock-wrapper">
                  <Clock size={12} />
                </div>
                <span className="fc-dot" />
              </div>
              <div className="fc-duration">{option.boardingPoint}</div>
            </div>

            <div className="fc-time block-end">
              <div className="fc-time-val">{option.arriveTime}</div>
              <div className="fc-time-code">{option.destinationCity}</div>
            </div>
          </div>
        )}

        <div className="fc-perks">
          <span className="fc-perk-item">
            <Users size={14} /> {isCab ? "Private ride" : "Reserved seat"}
          </span>
          {option.amenities.map((a) => (
            <span className="fc-perk-item" key={a}>
              · {a}
            </span>
          ))}
        </div>

        {isCab && option.dayCount > 1 && (
          <div className="tc-multiday-note">
            ₹{option.perDayPrice.toLocaleString("en-IN")} × {option.dayCount} days
          </div>
        )}
      </div>

      <div className="fc-divider">
        <span className="fc-notch fc-notch-top" />
        <span className="fc-notch fc-notch-bottom" />
      </div>

      <div className="fc-price-section">
        <div className="fc-price-meta">
          <span className="fc-price-from">{isCab ? "Estimated Fare" : "Fare per seat"}</span>
          <div className="fc-price-val">₹{option.price.toLocaleString("en-IN")}</div>
        </div>
        <div className={`fc-select-pill ${selected ? "fc-pill-selected" : ""}`}>
          {selected ? "Selected" : "Select"}
        </div>
      </div>
    </button>
  );
}