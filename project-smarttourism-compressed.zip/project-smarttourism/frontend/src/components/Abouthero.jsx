export default function Abouthero() {
  return (
    <section className="hero">
      <div className="hero-left">
        <p className="hero-crumb">
          <a href="/">Home</a><span>/</span>About Us
        </p>
        <h1>
          Every Itinerary Starts<br />With a <em>Reason to Go</em>
        </h1>
        <p>
          Founded in 2012, Global Smart Tourism was built on one belief: a great trip isn't about
          ticking places off a list. It's about arriving somewhere and feeling it change you — and
          having someone who's actually been there plan the route.
        </p>
        <div className="hero-btns">
          <a href="/packages/" className="btn primary">
            <i className="fa-solid fa-route"></i> Browse Packages
          </a>
          <a href="/contact/" className="btn ghost">
            <i className="fa-solid fa-comments"></i> Talk to an Expert
          </a>
        </div>
        <div className="hero-stats">
          <div className="h-stat"><b>50K<span>+</span></b><small>Travellers Served</small></div>
          <div className="h-stat"><b>120<span>+</span></b><small>Destinations</small></div>
          <div className="h-stat"><b>14<span>+</span></b><small>Years of Trust</small></div>
          <div className="h-stat"><b>4.9<span>★</span></b><small>Avg. Rating</small></div>
        </div>
      </div>

      <div className="hero-right">
        <div className="mosaic">
          <div className="mosaic-cell"><img src="/images/kerala.jpg" alt="Backwaters of Kerala" /></div>
          <div className="mosaic-cell"><img src="/images/dubai.jpg" alt="Dubai skyline" /></div>
          <div className="mosaic-cell"><img src="/images/goa.jpg" alt="Goa coastline" /></div>
          <div className="mosaic-cell"><img src="/images/maldives.jpg" alt="Maldives overwater villas" /></div>
          <div className="mosaic-cell"><img src="/images/paris.jpg" alt="Paris rooftops" /></div>
        </div>
        <svg className="route-svg" viewBox="0 0 760 800" preserveAspectRatio="none" aria-hidden="true">
          <path className="route-path" d="M -40 120 C 160 60, 260 260, 420 210 S 700 70, 800 160"></path>
          <circle className="route-dot" cx="800" cy="160" r="6"></circle>
          <text className="route-plane" x="755" y="120" fill="var(--gold)">&#9992;</text>
        </svg>
        <div className="route-tag">
          <i className="fa-solid fa-location-dot"></i> 120+ destinations routed since 2012
        </div>
      </div>
    </section>
  );
}