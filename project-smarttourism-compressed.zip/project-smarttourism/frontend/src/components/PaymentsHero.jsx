import React from "react";

export default function PaymentsHero() {
  return (
    <div className="page-hero">
      <h1>Complete Your Booking</h1>
      <p>You're just one step away from your dream destination</p>
      <div className="trust-strip">
        <div className="trust-item"><div className="trust-dot"></div> Instant Confirmation</div>
        <div className="trust-item"><div className="trust-dot"></div> 100% Refund Guarantee</div>
        <div className="trust-item"><div className="trust-dot"></div> 24/7 Support</div>
        <div className="trust-item"><div className="trust-dot"></div> Safe &amp; Encrypted</div>
      </div>
    </div>
  );
}