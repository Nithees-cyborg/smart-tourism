import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CalendarCheck,
  Compass,
  Briefcase,
  Wallet,
  Navigation,
  RotateCcw,
  Gift,
  Headset,
  ArrowRight,
  ShieldCheck,
  Globe2,
  Users2,
  Star,
} from "lucide-react";
import { fetchDestinations } from "../components/DashboardApi";

// "invoices" is handled specially below: Invoice.jsx reads booking/payment
// from router state (there's no backend bookings endpoint to fetch by id),
// so that one action navigates with state instead of using a plain href.
const quickActions = [
  { href: "/packages/", Icon: CalendarCheck, label: "Trips" },
  { href: "/packages/", Icon: Compass, label: "Explore Packages" },
  { href: "/career/", Icon: Briefcase, label: "Career" },
  { Icon: Wallet, label: "Payments & Invoices", key: "invoices" },
  { href: "/gallery/", Icon: Navigation, label: "Amazing Destinations" },
  { href: "/refunds/", Icon: RotateCcw, label: "Refunds" },
  { href: "/rewards/", Icon: Gift, label: "Rewards" },
  { href: "/contact/", Icon: Headset, label: "Support" },
];

const trustMilestones = [
  { Icon: CalendarCheck, value: "15+", label: "Years in Business" },
  { Icon: Users2, value: "50,000+", label: "Travellers Served" },
  { Icon: Globe2, value: "120+", label: "Destinations Covered" },
  { Icon: Star, value: "4.8/5", label: "Average Rating" },
];

function TrustAndStory() {
  return (
    <div className="panel panel--glass trust-panel">
      <div className="panel-head">
        <h3>Building Trust, One Trip at a Time</h3>
        <a href="/about/">
          Our story <ArrowRight size={13} strokeWidth={2.5} />
        </a>
      </div>

      <div className="trust-body">
        <div className="trust-copy">
          <span className="trust-eyebrow">
            <ShieldCheck size={13} strokeWidth={2.5} /> Since 2009
          </span>
          <p className="trust-lead">
            For over fifteen years, Global Smart Tourism has helped travellers turn once-in-a-lifetime
            ideas into carefully planned, dependable trips. What started as a small desk booking
            regional getaways has grown into a full-service agency trusted by tens of thousands of
            travellers across more than a hundred destinations.
          </p>
          <p className="trust-lead trust-lead--muted">
            Every itinerary is backed by real partner hotels, verified flight availability, and a
            support team that stays reachable long after the booking is confirmed — because trust,
            once earned, is what keeps travellers coming back.
          </p>

          <div className="trust-milestones">
            {trustMilestones.map((m) => (
              <div className="trust-milestone" key={m.label}>
                <div className="trust-milestone-icon">
                  <m.Icon size={16} strokeWidth={2.25} />
                </div>
                <div>
                  <div className="trust-milestone-value">{m.value}</div>
                  <div className="trust-milestone-label">{m.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="trust-images">
          <img
            className="trust-img trust-img--tall"
            src="https://picsum.photos/seed/travel-team-office/500/620"
            alt="Global Smart Tourism team at work"
            loading="lazy"
          />
          <img
            className="trust-img trust-img--short"
            src="https://picsum.photos/seed/happy-travellers-group/500/300"
            alt="Travellers on a Global Smart Tourism trip"
            loading="lazy"
          />
        </div>
      </div>
    </div>
  );
}

export default function QuickActionsAndDestinations() {
  const navigate = useNavigate();
  const [destinations, setDestinations] = useState([]);
  const [moreDestinations, setMoreDestinations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    fetchDestinations()
      .then((data) => {
        if (!alive) return;
        setDestinations(data.filter((d) => d.is_featured));
        setMoreDestinations(data.filter((d) => !d.is_featured));
      })
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, []);

  const handleInvoiceClick = () => {
    let saved = null;
    try {
      const raw = localStorage.getItem("lastBooking");
      saved = raw ? JSON.parse(raw) : null;
    } catch (err) {
      console.error("Failed to read last booking:", err);
    }

    if (saved?.booking) {
      navigate("/invoice", { state: { booking: saved.booking, payment: saved.payment } });
    } else {
      // No booking made yet — nothing for Invoice.jsx to render, so send
      // the user somewhere useful instead of a page that immediately
      // redirects them back out.
      navigate("/packages/");
    }
  };

  return (
    <>
      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Quick Actions</h3>
        </div>
        <div className="quick-grid">
          {quickActions.map((q, i) =>
            q.key === "invoices" ? (
              <button
                type="button"
                className="quick-btn"
                key={q.label}
                style={{ "--i": i }}
                onClick={handleInvoiceClick}
              >
                <div className="quick-icon">
                  <q.Icon size={18} strokeWidth={2.15} />
                </div>
                <span className="quick-label">{q.label}</span>
              </button>
            ) : (
              <a href={q.href} className="quick-btn" key={q.label} style={{ "--i": i }}>
                <div className="quick-icon">
                  <q.Icon size={18} strokeWidth={2.15} />
                </div>
                <span className="quick-label">{q.label}</span>
              </a>
            )
          )}
        </div>
      </div>

      <div className="panel panel--glass france-fill-panel">
        <img
          src="/france.jpg"
          alt="France travel destination"
          className="france-fill-img"
          loading="lazy"
        />
      </div>

      <TrustAndStory />

      <div className="panel panel--glass">
        <div className="panel-head">
          <h3>Featured Destinations</h3>
          <a href="/packages/">
            View all <ArrowRight size={13} strokeWidth={2.5} />
          </a>
        </div>

        {loading ? (
          <div className="dest-scroll">
            {[0, 1, 2].map((i) => <div className="dest-card dest-card--skel" key={i} />)}
          </div>
        ) : (
          <div className="dest-scroll">
            {destinations.map((d) => (
              <div className="dest-card" key={d.id}>
                <img src={d.image} alt={d.name} loading="lazy" />
                <div className="dest-overlay"></div>
                <div className="dest-tag">{d.tag}</div>
                <div className="dest-name">{d.name}</div>
              </div>
            ))}
          </div>
        )}

        <div className="dest-more-grid">
          {moreDestinations.map((d) => (
            <div className="dest-mini" key={d.id}>
              <img src={d.image} alt={d.name} loading="lazy" />
              <div className="dest-mini-veil">
                <span className="dest-mini-name">{d.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}