import React from "react";

export default function CookiesNavbar({ onToggleTheme }) {
  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = "/";
    }
  };

  return (
    <nav className="navbar">
      <a href="/" className="brand">
        <img
          src="/logo.png"
          alt="Global Smart Tourism Logo"
          className="brand-logo"
          onError={(e) => {
            e.currentTarget.style.display = "none";
            e.currentTarget.nextElementSibling.style.display = "flex";
          }}
        />
        <div className="brand-icon">
          <i className="fa-solid fa-earth-asia"></i>
        </div>
        <span className="brand-name">
          Global <em>Smart</em> Tourism
        </span>
      </a>
      <ul>
        <li>
          <button className="back-btn" onClick={handleBack} aria-label="Go back">
            <i className="fa-solid fa-arrow-left"></i> Back
          </button>
        </li>
        <li>
          <button
            className="theme-toggle-btn"
            aria-label="Toggle dark mode"
            onClick={onToggleTheme}
          >
            <i className="fa-solid fa-moon"></i>
          </button>
        </li>
      </ul>
    </nav>
  );
}