const services = [
  {
    code: "STAY—01",
    icon: "fa-solid fa-hotel",
    title: "Luxury Hotels",
    desc: "Premium hotels and resorts, pre-vetted for comfort and price, in every major destination on the map.",
  },
  {
    code: "FLT—02",
    icon: "fa-solid fa-plane",
    title: "Flight Booking",
    desc: "Domestic and international fares with instant confirmation — no holds, no waiting on a callback.",
  },
  {
    code: "PKG—03",
    icon: "fa-solid fa-earth-americas",
    title: "Holiday Packages",
    desc: "Built-to-order domestic and international itineraries, bundled to fit your dates and your budget.",
  },
  {
    code: "GDE—04",
    icon: "fa-solid fa-user-tie",
    title: "Tour Guides",
    desc: "Licensed local guides who know the shortcuts, the history, and the best table in town.",
  },
];

function Servicescards() {
  return (
    <section className="svc-services">
      <div className="section-head on-light reveal">
        <p className="eyebrow">Service Manifest</p>
        <h2>Four services. One itinerary.</h2>
        <p>
          Book what you need or the full route — every service below is
          confirmed and tracked under your trip number.
        </p>
      </div>

      <div className="svc-service-grid">
        {services.map((s) => (
          <div className="svc-service-card reveal" key={s.code}>
            <div className="svc-card-stub">
              <div className="svc-seal">
                <i className={s.icon}></i>
              </div>
              <span className="svc-route-code">{s.code}</span>
            </div>
            <div className="svc-card-main">
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
              <div className="svc-barcode"></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Servicescards;