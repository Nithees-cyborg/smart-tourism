export default function ContactHero() {
  return (
    <section
      className="hero"
      style={{ backgroundImage: `linear-gradient(180deg, rgba(8,18,38,.82), rgba(8,18,38,.62) 50%, rgba(8,18,38,.92)), url("/images/contact-bg.jpg")` }}
    >
      <p className="hero-crumb"><a href="/">Home</a><span>/</span>Contact Us</p>
      <h1>Let's Start Planning Your <em>Next Trip</em></h1>
      <p>Questions about a package, a booking, or a visa? Our travel specialists reply within one business hour — every day of the week, no chatbot in between.</p>
      <div className="quick-pills">
        <a href="tel:+919876543210" className="q-pill"><i className="fa-solid fa-phone"></i> +91 98765 43210</a>
        <a href="mailto:support@globalsmarttourism.com" className="q-pill"><i className="fa-solid fa-envelope"></i> support@globalsmarttourism.com</a>
        <span className="q-pill"><i className="fa-solid fa-location-dot"></i> Chennai, Tamil Nadu</span>
        <span className="q-pill"><i className="fa-solid fa-clock"></i> 24/7 Travel Assistance</span>
      </div>
    </section>
  );
}