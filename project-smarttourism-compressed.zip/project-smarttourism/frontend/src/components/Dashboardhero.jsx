import { useState, useRef, useEffect } from "react";
import {
  MapPin,
  Plane,
  Users,
  Radio,
  Compass,
  Bell,
  CalendarCheck,
  IndianRupee,
  UserPlus,
  CheckCheck,
  ArrowLeft,
} from "lucide-react";

const COMPANY_NAME = "Global Smart Tourism";

// Maps the backend's activity "type" field to an icon + friendly title
const ACTIVITY_ICON = {
  booking: CalendarCheck,
  payment: IndianRupee,
  customer: UserPlus,
};

const ACTIVITY_TITLE = {
  booking: "New booking",
  payment: "Payment received",
  customer: "New customer registered",
};

/**
 * Dashboardhero.jsx
 * Top brand bar + greeting + a live activity pulse showing real-time
 * bookings across the agency, plus a colorful notification bell.
 * Both the ticker and the bell are driven by /api/dashboard/activity/,
 * which returns real Booking/Payment/Customer rows with server-computed
 * "time ago" strings — no hardcoded names or fake timings.
 */
export default function Hero() {
  const [notifications, setNotifications] = useState([]);
  const [notifLoading, setNotifLoading] = useState(true);
  const [liveFeed, setLiveFeed] = useState([]);
  const [panelOpen, setPanelOpen] = useState(false);
  const [onlineCount, setOnlineCount] = useState(214);
  const panelRef = useRef(null);
  const bellRef = useRef(null);

  const unreadCount = notifications.filter((n) => n.unread).length;

  useEffect(() => {
    function handleClickOutside(e) {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target) &&
        bellRef.current &&
        !bellRef.current.contains(e.target)
      ) {
        setPanelOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    function handleEsc(e) {
      if (e.key === "Escape") setPanelOpen(false);
    }
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      setOnlineCount((c) => c + (Math.random() > 0.5 ? 1 : -1));
    }, 4000);
    return () => clearInterval(id);
  }, []);

  // Pulls real bookings/payments/new-customers from /api/dashboard/activity/
  // and feeds BOTH the notification bell and the scrolling ticker below.
  useEffect(() => {
    let cancelled = false;

    async function loadActivity() {
      try {
        const res = await fetch("/api/dashboard/activity/", { credentials: "include" });
        const data = await res.json();
        if (cancelled || !Array.isArray(data)) return;

        // ---- Notification panel: every activity type ----
        setNotifications((prev) => {
          const prevReadKeys = new Set(prev.filter((n) => !n.unread).map((n) => n.key));
          return data.map((item) => {
            const key = `${item.type}-${item.text}-${item.time_ago}`;
            return {
              id: key,
              key,
              type: item.type,
              Icon: ACTIVITY_ICON[item.type] || Bell,
              title: ACTIVITY_TITLE[item.type] || "Activity update",
              detail: item.text,
              time: item.time_ago,
              unread: !prevReadKeys.has(key),
            };
          });
        });

        // ---- Ticker: bookings + new customers read best as a "pulse" ----
        const tickerItems = data
          .filter((item) => item.type === "booking" || item.type === "customer")
          .map((item, i) => ({
            id: `${item.type}-${i}-${item.time_ago}`,
            Icon: item.type === "booking" ? Plane : Users,
            text: item.text,
            time: item.time_ago,
          }));
        setLiveFeed(tickerItems);
      } catch (err) {
        console.error("Failed to load /api/dashboard/activity/:", err);
      } finally {
        if (!cancelled) setNotifLoading(false);
      }
    }

    loadActivity();
    const interval = setInterval(loadActivity, 20000); // refresh every 20s
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const markAllRead = () => {
    setNotifications((list) => list.map((n) => ({ ...n, unread: false })));
  };

  const markOneRead = (id) => {
    setNotifications((list) =>
      list.map((n) => (n.id === id ? { ...n, unread: false } : n))
    );
  };

  return (
    <section className="dash-hero">
      <div className="dash-topbar">
        <div className="dash-topbar__brand">
          <span className="dash-topbar__mark">
            <img src="/logo.png" alt={COMPANY_NAME} className="dash-topbar__logo-img" />
          </span>
          <span className="dash-topbar__name">{COMPANY_NAME}</span>
        </div>

        <div className="dash-topbar__actions">
          <div className="dash-notif-wrap">
            <button
              ref={bellRef}
              className={`dash-topbar__icon-btn ${unreadCount > 0 ? "has-unread" : ""}`}
              aria-label="Notifications"
              aria-expanded={panelOpen}
              onClick={() => setPanelOpen((o) => !o)}
            >
              <Bell size={17} strokeWidth={2.15} />
              {unreadCount > 0 && (
                <span className="dash-topbar__badge">
                  <span className="dash-topbar__badge-ping" />
                </span>
              )}
            </button>

            {panelOpen && (
              <div className="dash-notif-panel" ref={panelRef} role="menu">
                <div className="dash-notif-panel__head">
                  <h4>
                    Notifications
                    {unreadCount > 0 && (
                      <span className="dash-notif-panel__count">{unreadCount}</span>
                    )}
                  </h4>
                  {unreadCount > 0 && (
                    <button className="dash-notif-panel__mark-all" onClick={markAllRead}>
                      <CheckCheck size={13} strokeWidth={2.25} />
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="dash-notif-panel__list">
                  {notifLoading && (
                    <div style={{ padding: "14px 16px", fontSize: "13px", color: "#64748b" }}>
                      Loading recent activity...
                    </div>
                  )}
                  {!notifLoading && notifications.length === 0 && (
                    <div className="dash-notif-empty">
                      <span className="dash-notif-empty__icon">🎉</span>
                      You're all caught up.
                    </div>
                  )}
                  {notifications.map((n, i) => (
                    <button
                      key={n.id}
                      className={`dash-notif-item ${n.unread ? "is-unread" : ""}`}
                      style={{ "--i": i }}
                      onClick={() => markOneRead(n.id)}
                    >
                      <span className={`dash-notif-item__icon dash-notif-item__icon--${n.type}`}>
                        <n.Icon size={15} strokeWidth={2.25} />
                      </span>
                      <span className="dash-notif-item__body">
                        <span className="dash-notif-item__title">{n.title}</span>
                        <span className="dash-notif-item__detail">{n.detail}</span>
                        <span className="dash-notif-item__time">{n.time}</span>
                      </span>
                      {n.unread && <span className="dash-notif-item__dot" aria-hidden="true" />}
                    </button>
                  ))}
                </div>

                <button className="dash-notif-panel__footer" onClick={() => setPanelOpen(false)}>
                  <ArrowLeft size={14} strokeWidth={2.5} />
                  Back
                </button>
              </div>
            )}
          </div>

          <div className="dash-topbar__profile">
            <div className="dash-topbar__avatar">GS</div>
            <span className="dash-topbar__profile-text">
              <strong>Global Smart Tourism</strong>
              <em>Customer Portal</em>
            </span>
          </div>
        </div>
      </div>

      <div className="dash-hero__intro">
        <span className="dash-hero__eyebrow">
          <Compass size={14} strokeWidth={2.5} /> Agency overview
        </span>
        <h1 className="dash-hero__title">
          Good to see you back. <br />
          Here's where every trip stands today.
        </h1>
        <p className="dash-hero__sub">
          A live look at bookings happening right now across your agency.
        </p>
      </div>

      <div className="dash-live">
        <div className="dash-live__rail">
          <div className="dash-live__marquee" aria-hidden="false">
            <div className="dash-live__track">
              {liveFeed.length === 0 ? (
                <span className="dash-live__item">
                  <span className="dash-live__item-icon">
                    <MapPin size={14} strokeWidth={2.25} />
                  </span>
                  No recent activity yet
                </span>
              ) : (
                [...liveFeed, ...liveFeed].map((item, i) => (
                  <span className="dash-live__item" key={`${item.id}-${i}`}>
                    <span className="dash-live__item-icon">
                      <item.Icon size={14} strokeWidth={2.25} />
                    </span>
                    {item.text}
                    <span className="dash-live__item-time">{item.time}</span>
                  </span>
                ))
              )}
            </div>
          </div>
          <span className="dash-live__badge">
            <span className="dash-live__dot" />
            LIVE
          </span>
        </div>

        <div className="dash-live__stats">
          <div className="dash-live__stat">
            <Radio size={15} strokeWidth={2.25} />
            <div>
              <strong>{onlineCount}</strong>
              <span>travelers online</span>
            </div>
          </div>
          <div className="dash-live__stat">
            <CalendarCheck size={15} strokeWidth={2.25} />
            <div>
              <strong>37</strong>
              <span>bookings today</span>
            </div>
          </div>
          <div className="dash-live__stat">
            <IndianRupee size={15} strokeWidth={2.25} />
            <div>
              <strong>₹9.4L</strong>
              <span>revenue today</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}