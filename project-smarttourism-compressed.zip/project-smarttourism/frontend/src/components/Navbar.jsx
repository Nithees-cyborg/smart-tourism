import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home,
  Info,
  Briefcase,
  Mail,
  LogIn,
  ShieldCheck,
  Rocket,
  Sun,
  Moon,
} from "lucide-react";
import "../components/Navbar.css";

export default function Navbar({ theme, toggleTheme }) {
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    handler();
    window.addEventListener("scroll", handler, { passive: true });

    return () => window.removeEventListener("scroll", handler);
  }, []);

  const isActive = (href) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <nav className={`navbar ${theme}${scrolled ? " scrolled" : ""}`}>
      {/* Logo */}
      <Link to="/" className="brand">
        <div className="brand-logo">
          <img src="/logo.png" alt="Global Smart Tourism" className="dash-nav__logo-img" />
          <span className="dash-nav__logo-text">Global Smart Tourism</span>
        </div>
      </Link>

      {/* Navigation */}
      <ul className="nav-links">
        <li>
          <Link to="/" className={isActive("/") ? "is-active" : ""}>
            <Home size={15} strokeWidth={2.25} />
            Home
          </Link>
        </li>

        <li>
          <Link to="/about" className={isActive("/about") ? "is-active" : ""}>
            <Info size={15} strokeWidth={2.25} />
            About
          </Link>
        </li>

        <li>
          <Link to="/services" className={isActive("/services") ? "is-active" : ""}>
            <Briefcase size={15} strokeWidth={2.25} />
            Services
          </Link>
        </li>

        <li>
          <Link to="/contact" className={isActive("/contact") ? "is-active" : ""}>
            <Mail size={15} strokeWidth={2.25} />
            Contact
          </Link>
        </li>

        <li>
          <Link to="/login" className={isActive("/login") ? "is-active" : ""}>
            <LogIn size={15} strokeWidth={2.25} />
            Login
          </Link>
        </li>

        <li>
          <Link to="/signup" className="nav-cta">
            <Rocket size={15} strokeWidth={2.5} />
            Get Started
          </Link>
        </li>

        <li>
          <button className="theme-toggle-btn" onClick={toggleTheme} aria-label="Toggle Dark Mode">
            {theme === "dark" ? <Sun size={16} strokeWidth={2.25} /> : <Moon size={16} strokeWidth={2.25} />}
          </button>
        </li>
      </ul>
    </nav>
  );
}