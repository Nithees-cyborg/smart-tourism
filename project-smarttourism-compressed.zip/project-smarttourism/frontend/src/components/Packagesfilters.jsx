import React from "react";

const CHIPS = ["Beach", "Heritage", "Mountain", "Luxury", "Adventure", "Island", "City"];

export default function Packagesfilters({ search, onSelectChip, onClear }) {
  return (
    <>
      <div className="grid-head">
        <div className="grid-head-left">
          <h2>Available Packages</h2>
          <p>{search ? `Results for "${search}"` : "All curated travel plans"}</p>
        </div>
        {search && (
          <a
            href="#"
            className="clear-link"
            onClick={(e) => {
              e.preventDefault();
              onClear();
            }}
          >
            <i className="fa-solid fa-xmark"></i> Clear filter
          </a>
        )}
      </div>

      <div className="filter-chips">
        <a
          href="#"
          className={`f-chip ${!search ? "f-chip-active" : ""}`}
          onClick={(e) => {
            e.preventDefault();
            onClear();
          }}
        >
          All
        </a>
        {CHIPS.map((c) => (
          <a
            href="#"
            className="f-chip"
            key={c}
            onClick={(e) => {
              e.preventDefault();
              onSelectChip(c);
            }}
          >
            {c === "Mountain" ? "Mountains" : c === "City" ? "City Breaks" : c === "Island" ? "Islands" : c}
          </a>
        ))}
      </div>
    </>
  );
}