import { useEffect, useRef, useState } from "react";

const TOC = [
  { id: "acceptance", label: "1. Acceptance of Terms" },
  { id: "eligibility", label: "2. Eligibility & Accounts" },
  { id: "bookings", label: "3. Bookings & Payments" },
  { id: "cancellations", label: "4. Cancellations & Refunds" },
  { id: "responsibilities", label: "5. Traveller Responsibilities" },
  { id: "pricing", label: "6. Pricing & Availability" },
  { id: "ip", label: "7. Intellectual Property" },
  { id: "liability", label: "8. Limitation of Liability" },
  { id: "thirdparty", label: "9. Third-Party Services" },
  { id: "disputes", label: "10. Disputes & Governing Law" },
  { id: "termination", label: "11. Termination" },
  { id: "changes", label: "12. Changes to These Terms" },
  { id: "contact", label: "13. Contact Us" },
];

export default function TermsContent() {
  const [activeId, setActiveId] = useState(TOC[0].id);
  const sectionRefs = useRef({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveId(entry.target.id);
        });
      },
      { rootMargin: "-40% 0px -50% 0px" }
    );

    Object.values(sectionRefs.current).forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const registerRef = (id) => (el) => {
    sectionRefs.current[id] = el;
  };

  return (
    <div className="legal-shell">
      <aside className="legal-toc">
        <span className="legal-toc-label">On This Page</span>
        <ul id="tocList">
          {TOC.map((item) => (
            <li key={item.id}>
              <a
                href={`#${item.id}`}
                className={activeId === item.id ? "active" : ""}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </aside>

      <main className="legal-content">
        <div className="legal-section" id="acceptance" ref={registerRef("acceptance")}>
          <span className="legal-num">01</span>
          <h2>Acceptance of Terms</h2>
          <p>
            By accessing or using Global Smart Tourism's website, mobile app, or booking services
            (the "Services"), you agree to be bound by these Terms of Use and our Privacy Policy. If
            you're using the Services on behalf of a group or organisation, you confirm you have the
            authority to bind that group to these terms.
          </p>
        </div>

        <div className="legal-section" id="eligibility" ref={registerRef("eligibility")}>
          <span className="legal-num">02</span>
          <h2>Eligibility &amp; Account Registration</h2>
          <p>
            You must be at least 18 years old and capable of entering a legally binding contract to
            create an account or make a booking with us. When you register, you agree to:
          </p>
          <ul>
            <li>Provide accurate, current, and complete information.</li>
            <li>Keep your login credentials confidential and notify us immediately of any unauthorised use.</li>
            <li>Accept responsibility for all activity that occurs under your account.</li>
          </ul>
        </div>

        <div className="legal-section" id="bookings" ref={registerRef("bookings")}>
          <span className="legal-num">03</span>
          <h2>Bookings &amp; Payments</h2>
          <p>
            When you submit a booking request, you're making an offer to purchase the selected
            travel service at the listed price. A booking is only confirmed once you receive a
            confirmation email or in-app notice from us — not merely upon submitting payment details.
          </p>
          <ul>
            <li>Full or partial payment may be required at the time of booking, depending on the package and supplier policy.</li>
            <li>Prices are quoted in Indian Rupees (₹) unless stated otherwise, and may be subject to currency conversion fees for international cards.</li>
            <li>You are responsible for ensuring your name and travel details exactly match your government-issued ID or passport, as airlines and hotels may deny boarding or check-in for mismatches.</li>
          </ul>
        </div>

        <div className="legal-section" id="cancellations" ref={registerRef("cancellations")}>
          <span className="legal-num">04</span>
          <h2>Cancellations &amp; Refunds</h2>
          <p>
            Cancellation policies vary by package, hotel, and airline, and are displayed at the time
            of booking. As a general guide:
          </p>
          <table className="legal-table">
            <tbody>
              <tr>
                <th>Timing</th>
                <th>Refund</th>
              </tr>
              <tr>
                <td>30+ days before travel</td>
                <td>90% of total amount (excluding processing fees)</td>
              </tr>
              <tr>
                <td>15–29 days before travel</td>
                <td>50% of total amount</td>
              </tr>
              <tr>
                <td>Less than 15 days before travel</td>
                <td>Non-refundable, unless the supplier's policy states otherwise</td>
              </tr>
            </tbody>
          </table>
          <p>
            Some discounted or promotional fares are non-refundable regardless of timing — this will
            always be disclosed before you complete payment. Refunds, where applicable, are processed
            within 7–10 business days to the original payment method.
          </p>
          <div className="legal-callout warn">
            <i className="fa-solid fa-triangle-exclamation"></i>
            Flights, visas, and certain third-party-operated tours may carry stricter cancellation
            terms set by the supplier, which GST cannot override.
          </div>
        </div>

        <div className="legal-section" id="responsibilities" ref={registerRef("responsibilities")}>
          <span className="legal-num">05</span>
          <h2>Traveller Responsibilities</h2>
          <ul>
            <li>You are responsible for holding a valid passport, visa, and any required travel documentation for your destination.</li>
            <li>You are responsible for checking destination-specific health, safety, and entry requirements before departure.</li>
            <li>You agree to behave respectfully toward staff, guides, fellow travellers, and local communities throughout your trip.</li>
            <li>We strongly recommend purchasing travel insurance; certain packages may require it as a condition of booking.</li>
          </ul>
        </div>

        <div className="legal-section" id="pricing" ref={registerRef("pricing")}>
          <span className="legal-num">06</span>
          <h2>Pricing &amp; Availability</h2>
          <p>
            All prices and availability are subject to change without notice until a booking is
            confirmed. In the rare case of a pricing error due to a technical glitch, we reserve the
            right to cancel the booking and issue a full refund, or contact you with a corrected
            price before proceeding.
          </p>
        </div>

        <div className="legal-section" id="ip" ref={registerRef("ip")}>
          <span className="legal-num">07</span>
          <h2>Intellectual Property</h2>
          <p>
            All content on our Services — including text, images, logos, itineraries, and design —
            is owned by or licensed to Global Smart Tourism and is protected by applicable
            intellectual property laws. You may not copy, reproduce, or redistribute our content for
            commercial purposes without written permission.
          </p>
        </div>

        <div className="legal-section" id="liability" ref={registerRef("liability")}>
          <span className="legal-num">08</span>
          <h2>Limitation of Liability</h2>
          <p>
            Global Smart Tourism acts as an intermediary connecting you with airlines, hotels, and
            local operators. While we carefully vet our partners, we are not liable for:
          </p>
          <ul>
            <li>Acts, errors, or omissions of third-party suppliers, including flight delays, hotel overbookings, or service quality at independently operated properties.</li>
            <li>Loss or damage arising from events outside our reasonable control, including natural disasters, strikes, or government travel restrictions.</li>
            <li>Indirect, incidental, or consequential damages arising from use of our Services, to the maximum extent permitted by law.</li>
          </ul>
          <p>
            Where liability cannot be excluded under applicable law, our total liability is limited
            to the amount you paid for the specific booking in question.
          </p>
        </div>

        <div className="legal-section" id="thirdparty" ref={registerRef("thirdparty")}>
          <span className="legal-num">09</span>
          <h2>Third-Party Services &amp; Links</h2>
          <p>
            Our Services may link to or integrate with third-party websites, payment processors, or
            supplier platforms. We are not responsible for the content, accuracy, or practices of
            these third parties, and your use of them is governed by their own terms and privacy
            policies.
          </p>
        </div>

        <div className="legal-section" id="disputes" ref={registerRef("disputes")}>
          <span className="legal-num">10</span>
          <h2>Disputes &amp; Governing Law</h2>
          <p>
            These Terms are governed by the laws of India. Any dispute arising out of or relating to
            these Terms or your use of our Services will first be attempted to be resolved through
            good-faith negotiation, and failing that, through arbitration or the courts of Mumbai,
            Maharashtra, which shall have exclusive jurisdiction.
          </p>
        </div>

        <div className="legal-section" id="termination" ref={registerRef("termination")}>
          <span className="legal-num">11</span>
          <h2>Termination</h2>
          <p>
            We may suspend or terminate your account if you violate these Terms, engage in
            fraudulent activity, or misuse the Services. You may close your account at any time by
            contacting support; confirmed bookings will still be honoured subject to their individual
            cancellation terms.
          </p>
        </div>

        <div className="legal-section" id="changes" ref={registerRef("changes")}>
          <span className="legal-num">12</span>
          <h2>Changes to These Terms</h2>
          <p>
            We may revise these Terms periodically to reflect changes in our Services or legal
            obligations. Continued use of the Services after changes take effect constitutes
            acceptance of the revised Terms. We'll always update the "Last Updated" date above when
            changes are made.
          </p>
        </div>

        <div className="legal-section" id="contact" ref={registerRef("contact")}>
          <span className="legal-num">13</span>
          <h2>Contact Us</h2>
          <p>Questions about these Terms? Our support team is happy to help.</p>
          <div className="legal-contact-box">
            <h3>Global Smart Tourism — Support Team</h3>
            <div className="footer-contact-item">
              <i className="fa-solid fa-envelope"></i> support@gst.com
            </div>
            <div className="footer-contact-item">
              <i className="fa-solid fa-phone"></i> +91 98765 43210
            </div>
            <div className="footer-contact-item">
              <i className="fa-solid fa-location-dot"></i> Mumbai &middot; Dubai &middot; Coimbatore
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}