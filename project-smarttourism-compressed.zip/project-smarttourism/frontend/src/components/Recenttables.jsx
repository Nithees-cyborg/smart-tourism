const avatarColors = ["blue", "teal", "purple", "green", "gold"];

const demoBookings = [
  { id: 112, customer: "Rahul Mehta", pkg: "Dubai Luxury Tour", amount: "85,000", status: "confirmed", date: "Jun 28, 2026" },
  { id: 111, customer: "Priya Nair", pkg: "Kerala Backwaters", amount: "48,000", status: "pending", date: "Jun 27, 2026" },
  { id: 110, customer: "Aakash Sharma", pkg: "Maldives Escape", amount: "1,10,000", status: "confirmed", date: "Jun 26, 2026" },
  { id: 109, customer: "Sneha Roy", pkg: "Goa Beach Getaway", amount: "32,000", status: "cancelled", date: "Jun 25, 2026" },
  { id: 108, customer: "Vikram Patel", pkg: "Singapore Explorer", amount: "62,000", status: "pending", date: "Jun 24, 2026" },
];

export default function RecentTables({ customers = [], bookings = [] }) {
  const bookingRows = bookings.length ? bookings : demoBookings;

  return (
    <>
      {/* Recent Customers */}
      <div className="panel">
        <div className="panel-head" style={{ paddingBottom: 0 }}>
          <h3>Recent Customers</h3>
          <a href="/customers/">
            All customers <i className="fa-solid fa-arrow-right"></i>
          </a>
        </div>
        <div className="data-table-wrap" style={{ padding: "16px 0 0" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Email</th>
                <th>City</th>
                <th>Country</th>
              </tr>
            </thead>
            <tbody>
              {customers.length ? (
                customers.map((c, i) => (
                  <tr key={c.id || i}>
                    <td>
                      <div className="name-cell">
                        <div className={`avatar ${avatarColors[i % avatarColors.length]}`}>
                          {c.full_name?.charAt(0).toUpperCase()}
                        </div>
                        {c.full_name}
                      </div>
                    </td>
                    <td>{c.email}</td>
                    <td>{c.city}</td>
                    <td>{c.country}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} style={{ textAlign: "center", color: "var(--muted)", padding: 32 }}>
                    No customers yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Bookings */}
      <div className="panel">
        <div className="panel-head" style={{ paddingBottom: 0 }}>
          <h3>Recent Bookings</h3>
          <a href="/bookings/">
            All bookings <i className="fa-solid fa-arrow-right"></i>
          </a>
        </div>
        <div className="data-table-wrap" style={{ padding: "16px 0 0" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Customer</th>
                <th>Package</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {bookingRows.map((b, i) => (
                <tr key={b.id}>
                  <td style={{ fontWeight: 700, color: "var(--muted)" }}>#{b.id}</td>
                  <td>
                    <div className="name-cell">
                      <div className={`avatar ${avatarColors[i % avatarColors.length]}`}>
                        {b.customer?.charAt(0).toUpperCase()}
                      </div>
                      {b.customer}
                    </div>
                  </td>
                  <td>{b.pkg}</td>
                  <td style={{ fontWeight: 700, color: "var(--heading)" }}>₹{b.amount}</td>
                  <td>
                    <span className={`badge badge-${b.status}`}>
                      <span className={`status-dot dot-${b.status}`}></span>
                      {b.status.charAt(0).toUpperCase() + b.status.slice(1)}
                    </span>
                  </td>
                  <td style={{ color: "var(--muted)" }}>{b.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Platform Highlights */}
      <div className="panel">
        <div className="panel-head">
          <h3>Platform Highlights</h3>
        </div>
        <div className="info-strip" style={{ padding: "20px 24px 24px" }}>
          <div className="info-chip">
            <div className="info-chip-icon" style={{ background: "rgba(21,89,194,0.1)", color: "var(--ocean)" }}>
              <i className="fa-solid fa-globe"></i>
            </div>
            <div className="info-chip-text">
              <div className="ic-label">Countries Covered</div>
              <div className="ic-val">24 Nations</div>
            </div>
          </div>
          <div className="info-chip">
            <div className="info-chip-icon" style={{ background: "rgba(16,185,129,0.1)", color: "var(--green)" }}>
              <i className="fa-solid fa-star"></i>
            </div>
            <div className="info-chip-text">
              <div className="ic-label">Avg. Rating</div>
              <div className="ic-val">4.8 / 5.0</div>
            </div>
          </div>
          <div className="info-chip">
            <div className="info-chip-icon" style={{ background: "rgba(240,180,41,0.1)", color: "#d97706" }}>
              <i className="fa-solid fa-award"></i>
            </div>
            <div className="info-chip-text">
              <div className="ic-label">Awards Won</div>
              <div className="ic-val">12 This Year</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}