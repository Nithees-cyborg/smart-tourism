const popular = [
  { img: "https://picsum.photos/seed/santorini-greece/700/900", tag: "Trending", name: "Santorini, Greece", sub: "7D historic island escape", price: "₹1,25,000", big: true },
  { img: "https://picsum.photos/seed/kyoto-japan/700/500", tag: "Culture", name: "Kyoto, Japan", sub: "6D temple trail", price: "₹1,45,000" },
  { img: "https://picsum.photos/seed/queenstown-nz/700/500", tag: "Adventure", name: "Queenstown, NZ", sub: "8D South Island loop", price: "₹2,05,000" },
  { img: "https://picsum.photos/seed/marrakech-morocco/700/500", tag: "Desert", name: "Marrakech, Morocco", sub: "6D Sahara trail", price: "₹92,000" },
  { img: "https://picsum.photos/seed/zermatt-switzerland/700/500", tag: "Alps", name: "Zermatt, Switzerland", sub: "8D Panorama tour", price: "₹2,15,000" },
];

export default function PopularDestinations() {
  return (
    <div style={{ padding: "8px 0" }}>
      <div style={{ padding: "0 44px" }}>
        <p className="section-eyebrow">Handpicked For You</p>
        <h2 className="section-title">Popular Destinations Right Now</h2>
      </div>
      <div className="dest-grid">
        {popular.map((d) => (
          <div className={`dest-card ${d.big ? "big" : ""}`} key={d.name}>
            <img src={d.img} alt={d.name} loading="lazy" />
            <div className="dest-card-veil"></div>
            <div className="dest-card-price">{d.price}</div>
            <div className="dest-card-body">
              <span className="dest-card-tag">{d.tag}</span>
              <div className="dest-card-name">{d.name}</div>
              <div className="dest-card-sub">{d.sub}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}