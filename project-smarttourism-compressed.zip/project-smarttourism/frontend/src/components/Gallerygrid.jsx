import React, { useEffect, useRef } from 'react';

const Gallerygrid = ({
  images,
  categories,
  currentCategory,
  favoritesOnly,
  favorites,
  toggleFavorite,
  openLightbox,
}) => {
  const gridRef = useRef(null);

  // Scroll-reveal animation for tiles
  useEffect(() => {
    const items = gridRef.current.querySelectorAll('.gallery-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    items.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // Hover tilt effect (desktop pointer only)
  useEffect(() => {
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return undefined;

    const items = gridRef.current.querySelectorAll('.gallery-item');
    const cleanups = [];

    items.forEach((el) => {
      const onMove = (e) => {
        const rect = el.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        el.style.transform = `translateY(0) rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 7).toFixed(2)}deg)`;
      };
      const onLeave = () => {
        el.style.transform = '';
      };
      el.addEventListener('mousemove', onMove);
      el.addEventListener('mouseleave', onLeave);
      cleanups.push(() => {
        el.removeEventListener('mousemove', onMove);
        el.removeEventListener('mouseleave', onLeave);
      });
    });

    return () => cleanups.forEach((fn) => fn());
  }, []);

  return (
    <div className="gallery-grid" ref={gridRef}>
      {images.map((src, idx) => {
        const category = categories[idx];
        const isHidden =
          (currentCategory !== 'all' && category !== currentCategory) ||
          (favoritesOnly && !favorites.has(idx));
        const isFav = favorites.has(idx);

        return (
          <figure
            key={idx}
            className={`gallery-item ${isHidden ? 'is-hidden-filter' : ''}`}
            onClick={() => openLightbox(idx)}
          >
            <img src={src} alt={`Gallery photo ${idx + 1} - ${category}`} loading="lazy" />
            <div className="gallery-overlay"><i className="fa-solid fa-expand"></i></div>
            <span className="gallery-tag">{category}</span>
            <span className="gallery-index">{String(idx + 1).padStart(2, '0')}</span>
            <button
              className={`fav-btn ${isFav ? 'is-favorited' : ''}`}
              onClick={(e) => {
                e.stopPropagation();
                toggleFavorite(idx);
              }}
              aria-label="Save to favorites"
            >
              <i className={isFav ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}></i>
            </button>
          </figure>
        );
      })}
    </div>
  );
};

export default Gallerygrid;