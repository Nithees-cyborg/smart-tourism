const features = [
  {
    icon: "fa-solid fa-shield-halved",
    title: "Verified Partners Only",
    desc: "Every hotel, airline, and guide on our network is vetted and re-checked each season.",
  },
  {
    icon: "fa-solid fa-bolt",
    title: "Real-Time Confirmation",
    desc: 'No "pending" bookings. Your stay and seat are locked in the moment you pay.',
  },
  {
    icon: "fa-solid fa-headset",
    title: "24/7 Travel Desk",
    desc: "Delays, swaps, or a missed connection — someone picks up, day or night.",
  },
  {
    icon: "fa-solid fa-receipt",
    title: "Transparent Pricing",
    desc: "The fare you see at checkout is the fare you pay. No surprise add-ons at the gate.",
  },
];

function Serviceswhyus() {
  return (
    <section className="svc-why-us">
      <div className="section-head on-dark reveal">
        <p className="eyebrow on-dark">Why Book With Us</p>
        <h2>The fine print, made simple.</h2>
        <p>Every trip number comes with the same four guarantees, no matter which service you book.</p>
      </div>

      <div className="svc-feature-grid">
        {features.map((f) => (
          <div className="svc-feature-card reveal" key={f.title}>
            <div className="svc-feature-icon">
              <i className={f.icon}></i>
            </div>
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Serviceswhyus;