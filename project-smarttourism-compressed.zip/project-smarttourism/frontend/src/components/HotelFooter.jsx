import React from "react";

export default function HotelFooter() {
  return (
    <footer className="site-footer">
      Global Smart Tourism — Hotel data shown is for demonstration purposes
      within this project.
    </footer>
  );
}