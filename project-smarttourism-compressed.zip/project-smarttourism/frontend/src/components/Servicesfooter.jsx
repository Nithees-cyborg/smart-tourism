import logo from "../assets/images/logo.png";

function Servicesfooter() {
  return (
    <footer className="svc-footer">
      <div className="svc-footer-grid">
        <div className="svc-footer-brand-block">
          <div className="svc-footer-brand">
            <img src={logo} alt="Global Smart Tourism logo" />
            Global Smart Tourism
          </div>
          <p>One trip number for every booking — hotels, flights, packages, and guides, confirmed the same day.</p>
          <div className="svc-social-row">
            <a href="#" aria-label="Instagram"><i className="fa-brands fa-instagram"></i></a>
            <a href="#" aria-label="Facebook"><i className="fa-brands fa-facebook-f"></i></a>
            <a href="#" aria-label="X"><i className="fa-brands fa-x-twitter"></i></a>
          </div>
        </div>

        <div className="svc-footer-col">
          <h4>Company</h4>
          <ul>
            <li><a href="/about/">About</a></li>
            <li><a href="/careers/">Careers</a></li>
            <li><a href="/contact/">Contact</a></li>
          </ul>
        </div>

        <div className="svc-footer-col">
          <h4>Services</h4>
          <ul>
            <li><a href="/services/">Hotels</a></li>
            <li><a href="/services/">Flights</a></li>
            <li><a href="/packages/">Packages</a></li>
            <li><a href="/services/">Guides</a></li>
          </ul>
        </div>

        <div className="svc-footer-col svc-newsletter">
          <h4>Trip Alerts</h4>
          <p>Fare drops and new routes, once a week, no spam.</p>
          <form action="#" method="get" onSubmit={(e) => e.preventDefault()}>
            <input type="email" placeholder="you@email.com" aria-label="Email address" />
            <button type="submit"><i className="fa-solid fa-paper-plane"></i></button>
          </form>
        </div>
      </div>

      <div className="svc-footer-meta">
        <span>&copy; 2026 GLOBAL SMART TOURISM</span>
        <span>TRIP NO. GST-0001 — ALL BOOKINGS CONFIRMED</span>
      </div>
    </footer>
  );
}

export default Servicesfooter;