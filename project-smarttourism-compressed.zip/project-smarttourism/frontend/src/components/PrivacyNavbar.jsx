import React, { useEffect, useState } from "react";
import logo from "/logo.png";

export default function PrivacyNavbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = "/";
    }
  };

  return (
    <nav className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <a href="/" className="brand">
        <img
          src={logo}
          alt="Global Smart Tourism logo"
          onError={(e) => {
            e.currentTarget.style.display = "none";
            e.currentTarget.nextElementSibling.style.display = "flex";
          }}
        />
        <div className="brand-mark">
          <i className="fa-solid fa-route"></i>
        </div>
        <span className="brand-name">
          Global <em>Smart</em> Tourism
        </span>
      </a>

      <div className="nav-links">
        <button className="back-btn cta-pill" onClick={handleBack} aria-label="Go back">
          <i className="fa-solid fa-arrow-left"></i> Back
        </button>
      </div>
    </nav>
  );
}