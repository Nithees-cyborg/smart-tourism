import React from "react";

export default function CookiesBanner({
  bannerVisible,
  floatBtnVisible,
  onManagePreferences,
  onRejectAll,
  onAcceptAll,
}) {
  return (
    <>
      {/* ===== Consent Banner ===== */}
      <div className={`cookie-banner${bannerVisible ? " show" : ""}`}>
        <div className="cookie-banner-icon">
          <i className="fa-solid fa-cookie-bite"></i>
        </div>
        <div className="cookie-banner-text">
          <h4>We use cookies</h4>
          <p>
            We use cookies and similar technologies for essential
            functionality, analytics, and marketing. Manage your choices
            anytime.
          </p>
        </div>
        <div className="cookie-banner-actions">
          <button className="btn-cookie btn-cookie-outline" onClick={onManagePreferences}>
            Manage Preferences
          </button>
          <button className="btn-cookie btn-cookie-ghost" onClick={onRejectAll}>
            Reject All
          </button>
          <button className="btn-cookie btn-cookie-primary" onClick={onAcceptAll}>
            Accept All
          </button>
        </div>
      </div>

      {/* ===== Floating reopen button ===== */}
      <button
        className={`cookie-float-btn${floatBtnVisible ? " show" : ""}`}
        onClick={onManagePreferences}
      >
        <i className="fa-solid fa-cookie-bite"></i> Cookie Settings
      </button>
    </>
  );
}
