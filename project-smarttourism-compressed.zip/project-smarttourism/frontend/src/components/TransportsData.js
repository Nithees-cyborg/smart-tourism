// TransportsData.js (src/components/TransportsData.js)
// Ground-transport (cab & bus) data layer for getting around within the
// selected package's destination. Reads destinations from PACKAGES_DATA,
// and pickup/arrangement points from the package's own places — not an
// external city list.

import PACKAGES_DATA from "../components/packagesData";

export const AIRPORT_INFO = {
  IND: { country: "India", airport: "DEL", city: "Delhi" },
  LAK: { country: "India", airport: "AGX", city: "Agatti" },
  MRU: { country: "Mauritius", airport: "MRU", city: "Port Louis" },
  TML: { country: "India", airport: "MAA", city: "Chennai" },
  RUS: { country: "Russia", airport: "SVO", city: "Moscow" },
  KSA: { country: "Saudi Arabia", airport: "RUH", city: "Riyadh" },
  SCO: { country: "United Kingdom", airport: "EDI", city: "Edinburgh" },
  POR: { country: "Portugal", airport: "LIS", city: "Lisbon" },
  ARG: { country: "Argentina", airport: "EZE", city: "Buenos Aires" },
  KOR: { country: "South Korea", airport: "ICN", city: "Seoul" },
  BAL: { country: "Indonesia", airport: "DPS", city: "Denpasar" },
  SWI: { country: "Switzerland", airport: "ZRH", city: "Zurich" },
  VIE: { country: "Vietnam", airport: "HAN", city: "Hanoi" },
  KEN: { country: "Kenya", airport: "NBO", city: "Nairobi" },
  JPN: { country: "Japan", airport: "NRT", city: "Tokyo" },
  THA: { country: "Thailand", airport: "BKK", city: "Bangkok" },
  SIN: { country: "Singapore", airport: "SIN", city: "Singapore" },
  UAE: { country: "United Arab Emirates", airport: "DXB", city: "Dubai" },
  MDV: { country: "Maldives", airport: "MLE", city: "Malé" },
  NEP: { country: "Nepal", airport: "KTM", city: "Kathmandu" },
  SRI: { country: "Sri Lanka", airport: "CMB", city: "Colombo" },
  KAS: { country: "India", airport: "SXR", city: "Srinagar" },
  AND: { country: "India", airport: "IXZ", city: "Port Blair" },
  TUR: { country: "Turkey", airport: "IST", city: "Istanbul" },
  GRE: { country: "Greece", airport: "ATH", city: "Athens" },
  ITA: { country: "Italy", airport: "FCO", city: "Rome" },
  FRA: { country: "France", airport: "CDG", city: "Paris" },
  ICE: { country: "Iceland", airport: "KEF", city: "Reykjavík" },
  NZL: { country: "New Zealand", airport: "CHC", city: "Christchurch" },
  EGY: { country: "Egypt", airport: "CAI", city: "Cairo" },
  MOR: { country: "Morocco", airport: "RAK", city: "Marrakech" },
  PER: { country: "Peru", airport: "CUZ", city: "Cusco" },
  BHU: { country: "Bhutan", airport: "PBH", city: "Paro" },
};

const CAB_PROVIDERS = [
  { name: "Ola Cabs", vehicleTypes: ["Sedan", "SUV", "Hatchback"] },
  { name: "Uber", vehicleTypes: ["Sedan", "SUV", "Prime Sedan"] },
  { name: "MeruCabs", vehicleTypes: ["Sedan", "Hatchback"] },
  { name: "City Cab Co.", vehicleTypes: ["SUV", "Sedan"] },
];

const BUS_OPERATORS = [
  { name: "VRL Travels", busTypes: ["AC Sleeper", "Non-AC Seater"] },
  { name: "SRS Travels", busTypes: ["Volvo Multi-Axle A/C Sleeper", "AC Seater"] },
  { name: "Orange Tours", busTypes: ["Non-AC Sleeper", "AC Seater"] },
  { name: "KPN Travels", busTypes: ["Volvo A/C Sleeper", "Non-AC Seater"] },
];

const CAB_AMENITIES_POOL = [
  "AC",
  "Music System",
  "Phone Charger",
  "Bottled Water",
  "GPS Tracking",
  "Sanitized Cabin",
];

const BUS_AMENITIES_POOL = [
  "Charging Point",
  "Blanket & Pillow",
  "Water Bottle",
  "Reading Light",
  "CCTV Onboard",
  "Live Tracking",
];

// ---- Fixed image per specific model (NOT random). ----
// Save these exact filenames in your /public folder.
export const CAR_IMAGE_MAP = {
  Sedan: "/car1.jpg",
  SUV: "/car2.jpg",
  Hatchback: "/car3.jpg",
  "Prime Sedan": "/car4.jpg",
};

export const BUS_IMAGE_MAP = {
  "AC Sleeper": "/bus1.jpg",
  "Non-AC Seater": "/bus2.jpg",
  "Volvo Multi-Axle A/C Sleeper": "/bus3.jpg",
  "AC Seater": "/bus4.jpg",
  "Non-AC Sleeper": "/bus5.jpg",
  "Volvo A/C Sleeper": "/bus6.jpg",
};

function seededRandom(seed) {
  let value = 0;
  for (let i = 0; i < seed.length; i++) {
    value = (value * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return function next() {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function formatTime(minutes) {
  const h = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${String(h12).padStart(2, "0")}:${String(m).padStart(2, "0")} ${period}`;
}

function formatDuration(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h ${m}m`;
}

export function getDestinations() {
  return PACKAGES_DATA.map((pkg) => {
    const info = AIRPORT_INFO[pkg.code] || { country: "—", airport: "—", city: pkg.destination };
    return {
      id: pkg.id,
      code: pkg.code,
      destination: pkg.destination,
      packageName: pkg.package_name,
      image: pkg.image,
      price: pkg.price,
      duration: pkg.duration,
      country: info.country,
      airportCode: info.airport,
      airportCity: info.city,
    };
  });
}

export function getPackageById(id) {
  return PACKAGES_DATA.find((pkg) => pkg.id === id) || null;
}

/**
 * Returns arrangement/pickup point options drawn from the selected
 * package's own places — not an external city list. Falls back to the
 * destination's main city if the package has no placesCovered/itinerary.
 */
export function getArrangementPoints(pkg) {
  if (!pkg) return [];

  const points = [];

  if (pkg.placesCovered?.length) {
    pkg.placesCovered.forEach((p) => points.push(p.name));
  }

  if (points.length === 0 && pkg.itinerary?.length) {
    pkg.itinerary.forEach((day) => {
      if (day.title) points.push(day.title);
    });
  }

  if (points.length === 0) {
    const info = AIRPORT_INFO[pkg.code];
    points.push(info?.city || pkg.destination);
  }

  // De-duplicate while preserving order
  return [...new Set(points)];
}

/**
 * Generates cab or bus transport options deterministically for a route.
 * mode: "cab" | "bus"
 * origin: pickup/arrangement point (from getArrangementPoints)
 * date: from-date (YYYY-MM-DD)
 * toDate: optional end-date for multi-day hire (cabs only affects price)
 * Each option gets a fixed image based on its specific vehicle/bus type.
 */
export function generateTransportOptions({ origin, destinationCode, date, toDate, mode, count = 6 }) {
  const info = AIRPORT_INFO[destinationCode];
  if (!info) return [];

  const seed = `${mode}-${origin}-${info.city}-${date || "default"}-${toDate || ""}`;
  const rand = seededRandom(seed);

  // Number of days the transport is needed for (min 1)
  let dayCount = 1;
  if (date && toDate) {
    const d1 = new Date(date);
    const d2 = new Date(toDate);
    const diff = Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
    dayCount = diff > 0 ? diff + 1 : 1;
  }

  const options = [];

  if (mode === "cab") {
    const basePrice = 1400;
    const baseDuration = 200; // minutes

    for (let i = 0; i < count; i++) {
      const provider = CAB_PROVIDERS[Math.floor(rand() * CAB_PROVIDERS.length)];
      const vehicleType = provider.vehicleTypes[Math.floor(rand() * provider.vehicleTypes.length)];
      const capacity = vehicleType === "SUV" ? 6 : vehicleType === "Hatchback" ? 4 : 4;
      const priceMultiplier = vehicleType === "SUV" ? 1.5 : vehicleType === "Prime Sedan" ? 1.25 : 1;

      const durationJitter = Math.floor(rand() * 90);
      const duration = baseDuration + durationJitter;

      const etaMins = 5 + Math.floor(rand() * 15);
      const priceJitter = Math.floor(rand() * basePrice * 0.5);
      const perDayPrice = Math.floor((basePrice + priceJitter) * priceMultiplier);
      const price = perDayPrice * dayCount;

      const rating = parseFloat((4.0 + rand() * 1.0).toFixed(1));
      const amenities = [
        CAB_AMENITIES_POOL[Math.floor(rand() * CAB_AMENITIES_POOL.length)],
        CAB_AMENITIES_POOL[Math.floor(rand() * CAB_AMENITIES_POOL.length)],
      ];

      options.push({
        id: `${seed}-${i}`,
        mode: "cab",
        provider: provider.name,
        vehicleType,
        image: CAR_IMAGE_MAP[vehicleType] || "/car1.jpg",
        capacity,
        etaMins,
        duration: formatDuration(duration),
        dayCount,
        perDayPrice,
        price: Math.max(price, 900),
        rating,
        amenities,
        pickupPoint: origin,
        destinationCity: info.city,
        country: info.country,
      });
    }
  } else {
    const basePrice = 700;
    const baseDuration = 420; // minutes

    for (let i = 0; i < count; i++) {
      const operator = BUS_OPERATORS[Math.floor(rand() * BUS_OPERATORS.length)];
      const busType = operator.busTypes[Math.floor(rand() * operator.busTypes.length)];
      const priceMultiplier = busType.toLowerCase().includes("sleeper") ? 1.4 : 1;

      const durationJitter = Math.floor(rand() * 120);
      const duration = baseDuration + durationJitter;

      const departMinutes = Math.floor(rand() * (23 * 60));
      const arriveMinutes = (departMinutes + duration) % (24 * 60);

      const priceJitter = Math.floor(rand() * basePrice * 0.5);
      const price = Math.floor((basePrice + priceJitter) * priceMultiplier);

      const seatsAvailable = 4 + Math.floor(rand() * 30);
      const rating = parseFloat((3.8 + rand() * 1.2).toFixed(1));
      const amenities = [
        BUS_AMENITIES_POOL[Math.floor(rand() * BUS_AMENITIES_POOL.length)],
        BUS_AMENITIES_POOL[Math.floor(rand() * BUS_AMENITIES_POOL.length)],
      ];

      options.push({
        id: `${seed}-${i}`,
        mode: "bus",
        operator: operator.name,
        busType,
        image: BUS_IMAGE_MAP[busType] || "/bus1.jpg",
        departTime: formatTime(departMinutes),
        arriveTime: formatTime(arriveMinutes),
        duration: formatDuration(duration),
        seatsAvailable,
        price: Math.max(price, 450),
        rating,
        amenities,
        boardingPoint: origin,
        destinationCity: info.city,
        country: info.country,
      });
    }
  }

  return options.sort((a, b) => a.price - b.price);
}