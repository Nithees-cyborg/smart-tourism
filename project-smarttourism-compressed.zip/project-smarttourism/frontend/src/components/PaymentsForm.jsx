import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const PAYMENT_METHODS = [
  { value: "Credit Card", iconClass: "mi-card", iconLabel: "CARD", display: "Credit / Debit Card" },
  { value: "Google Pay", iconClass: "mi-gp", iconLabel: "GP", display: "Google Pay" },
  { value: "PhonePe", iconClass: "mi-pp", iconLabel: "Pe", display: "PhonePe" },
  { value: "Paytm", iconClass: "mi-paytm", iconLabel: "PTM", display: "Paytm" },
  { value: "UPI", iconClass: "mi-upi", iconLabel: "UPI", display: "UPI Payment" },
  { value: "Net Banking", iconClass: "mi-nb", iconLabel: "NB", display: "Net Banking" },
];

export default function PaymentsForm({ totalAmount, onSubmit, isSubmitting }) {
  const navigate = useNavigate();

  const [paymentMethod, setPaymentMethod] = useState("Credit Card");
  const [cardName, setCardName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      // onSubmit should perform the actual payment/booking API call
      // and resolve with the booking object (or { booking } / response data).
      const result = await onSubmit({
        payment_method: paymentMethod,
        card_name: cardName,
        card_number: cardNumber,
        expiry,
        cvv,
      });

      // Redirect to the success page and hand the booking data over
      // via route state, so Payment_Success.jsx can read it directly.
      navigate("/payment-success", {
        state: {
          booking: result?.booking ?? result,
          paymentMethod,
        },
      });
    } catch (err) {
      console.error("Payment failed:", err);
      setError(
        err?.message || "Payment failed. Please check your details and try again."
      );
    }
  };

  return (
    <div className="card">
      <div className="card-title">💳 Secure Payment Gateway</div>

      <div className="logos-row">
        <div className="logo-chip">VISA</div>
        <div className="logo-chip">MasterCard</div>
        <div className="logo-chip">UPI</div>
        <div className="logo-chip">Paytm</div>
        <div className="logo-chip">PhonePe</div>
        <div className="logo-chip">Google Pay</div>
        <div className="logo-chip">Net Banking</div>
      </div>

      {error && <div className="payment-error">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="methods-label">Choose payment method</div>
        <div className="payment-method">
          {PAYMENT_METHODS.map((method) => (
            <label key={method.value}>
              <input
                type="radio"
                name="payment_method"
                value={method.value}
                checked={paymentMethod === method.value}
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              <span className={`method-icon ${method.iconClass}`}>{method.iconLabel}</span>
              {method.display}
            </label>
          ))}
        </div>

        <div className="divider"></div>

        <div className="methods-label">Card Details</div>

        <div className="form-group">
          <label>Cardholder Name</label>
          <input
            type="text"
            name="card_name"
            placeholder="Name as on card"
            value={cardName}
            onChange={(e) => setCardName(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Card Number</label>
          <input
            type="text"
            name="card_number"
            placeholder="1234  5678  9012  3456"
            maxLength={19}
            value={cardNumber}
            onChange={(e) => setCardNumber(e.target.value)}
          />
        </div>

        <div className="row">
          <div className="form-group">
            <label>Expiry Date</label>
            <input
              type="text"
              name="expiry"
              placeholder="MM / YY"
              maxLength={5}
              value={expiry}
              onChange={(e) => setExpiry(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>CVV</label>
            <input
              type="password"
              name="cvv"
              placeholder="•••"
              maxLength={3}
              value={cvv}
              onChange={(e) => setCvv(e.target.value)}
            />
          </div>
        </div>

        <button className="pay-btn" type="submit" disabled={isSubmitting}>
          🔒 {isSubmitting ? "Processing..." : `Pay ₹ ${totalAmount} Now`}
        </button>
      </form>

      <div className="ssl-row">
        🛡 256-bit SSL Encrypted &nbsp;·&nbsp; PCI DSS Compliant
      </div>
    </div>
  );
}