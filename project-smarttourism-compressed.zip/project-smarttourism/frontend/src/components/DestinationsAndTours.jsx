import { DESTINATIONS, HOW_STEPS, TOURS, MARQUEE_ITEMS } from "./data";

export function DestinationsSection() {
  return (
    <div className="sec">
      <div className="sec-head reveal">
        <div className="sec-eye">Explore the World</div>
        <h2 className="sec-title">Popular Destinations</h2>
        <p className="sec-sub">Voted by over 50,000 travellers — places that earn a second visit.</p>
      </div>
      <div className="dest-grid">
        {DESTINATIONS.map((d, i) => (
          <div key={i} className={`dest-card${d.big ? " big tilt-card" : ""} reveal`} style={{ transitionDelay: `${i * 80}ms` }}>
            <img src={d.img} alt={d.name} />
            <div className="dest-card-veil"></div>
            <div className="dest-card-price">{d.price}</div>
            <div className="dest-card-body">
              <div className="dest-card-tag">{d.tag}</div>
              <div className="dest-card-name">{d.name}</div>
              {d.sub && <div className="dest-card-sub">{d.sub}</div>}
            </div>
          </div>
        ))}
      </div>
      <div className="view-all">
        <a href="/packages" className="btn-outline">View All Destinations <i className="fa-solid fa-arrow-right"></i></a>
      </div>
    </div>
  );
}

export function HowItWorks() {
  return (
    <div className="how-bg">
      <div className="how-sec">
        <div className="sec-head reveal">
          <div className="sec-eye">Simple Process</div>
          <h2 className="sec-title">Plan Your Trip in 4 Steps</h2>
          <p className="sec-sub">From browsing to boarding — we handle everything in between.</p>
        </div>
        <div className="how-grid">
          {HOW_STEPS.map((s, i) => (
            <div key={i} className="how-card reveal" style={{ transitionDelay: `${i * 80}ms` }}>
              <div className="how-step-num">Step {s.num}</div>
              <div className={`how-icon ${s.color}`}><i className={`fa-solid ${s.icon}`}></i></div>
              <div className="how-title">{s.title}</div>
              <div className="how-desc">{s.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ToursSection() {
  return (
    <div className="sec">
      <div className="sec-head reveal">
        <div className="sec-eye">Top Picks</div>
        <h2 className="sec-title">Trending Tour Packages</h2>
        <p className="sec-sub">Our most-booked packages this season — loved for good reason.</p>
      </div>
      <div className="tours-strip">
        {TOURS.map((t, i) => (
          <div key={i} className="tour-card reveal" style={{ transitionDelay: `${i * 80}ms` }}>
            <div className="tour-img">
              <img src={t.img} alt={t.name} />
              <div className="tour-price">{t.price}</div>
            </div>
            <div className="tour-body">
              <div className="tour-name">{t.name}</div>
              <div className="tour-meta">
                <div className="tour-chip"><i className="fa-solid fa-clock"></i>{t.days}</div>
                <div className="tour-chip"><i className="fa-solid fa-star" style={{ color: "var(--gold)" }}></i>{t.rating}</div>
                <div className="tour-chip"><i className={`fa-solid ${t.chip.icon}`}></i>{t.chip.label}</div>
              </div>
              <a href="/packages" className="tour-book">View Package</a>
            </div>
          </div>
        ))}
      </div>
      <div className="view-all" style={{ marginTop: "32px" }}>
        <a href="/packages" className="btn-outline">See All Packages <i className="fa-solid fa-arrow-right"></i></a>
      </div>
    </div>
  );
}

export function Marquee() {
  const doubled = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS];
  return (
    <div className="marquee-wrap">
      <div className="marquee-label">Why Travellers Choose Us</div>
      <div className="marquee-track">
        {doubled.map((it, i) => (
          <div key={i} className="marquee-item">
            <i className={`fa-solid ${it.icon}`}></i>{it.label}
          </div>
        ))}
      </div>
    </div>
  );
}