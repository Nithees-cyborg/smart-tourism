import React, { useState, useEffect } from "react";
import {
  User,
  Lock,
  SlidersHorizontal,
  Bell,
  Save,
  Eye,
  EyeOff,
  Check,
  AlertCircle,
  Loader2,
} from "lucide-react";

const TABS = [
  { key: "profile", label: "Profile", Icon: User },
  { key: "security", label: "Security", Icon: Lock },
  { key: "preferences", label: "Preferences", Icon: SlidersHorizontal },
  { key: "notifications", label: "Notifications", Icon: Bell },
];

const LANGUAGES = ["English", "Hindi", "Tamil", "French", "Arabic"];

function ToggleSwitch({ checked, onChange, label, description }) {
  return (
    <label className="toggle-row">
      <span className="toggle-row__text">
        <span className="toggle-row__label">{label}</span>
        {description && <span className="toggle-row__desc">{description}</span>}
      </span>
      <span className={`toggle-switch ${checked ? "is-on" : ""}`}>
        <input
          type="checkbox"
          checked={checked}
          onChange={onChange}
          aria-label={label}
        />
        <span className="toggle-switch__track">
          <span className="toggle-switch__thumb" />
        </span>
      </span>
    </label>
  );
}

export default function SettingsSections() {
  const [activeTab, setActiveTab] = useState("profile");

  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    city: "",
    country: "",
    language: "English",
    theme: typeof window !== "undefined" ? localStorage.getItem("gst-theme") || "light" : "light",
    current_password: "",
    new_password: "",
    confirm_password: "",
    email_notifications: true,
    sms_notifications: false,
    booking_alerts: true,
    marketing_emails: false,
  });

  const [showPasswords, setShowPasswords] = useState({
    current: false,
    next: false,
    confirm: false,
  });

  const [errors, setErrors] = useState({});
  const [saveState, setSaveState] = useState("idle"); // idle | saving | saved | error

  // Load any previously saved profile data on mount (per-browser persistence)
  useEffect(() => {
    try {
      const saved = localStorage.getItem("gst-profile");
      if (saved) {
        const parsed = JSON.parse(saved);
        setForm((f) => ({ ...f, ...parsed, current_password: "", new_password: "", confirm_password: "" }));
      }
    } catch {
      // ignore corrupt/missing storage
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: null }));
  };

  const handleToggle = (name) => (e) => {
    setForm((prev) => ({ ...prev, [name]: e.target.checked }));
  };

  // Apply theme live as soon as it's changed, same key the Dashboard reads
  const handleThemeChange = (e) => {
    const value = e.target.value;
    setForm((prev) => ({ ...prev, theme: value }));
    document.documentElement.setAttribute("data-theme", value);
    try {
      localStorage.setItem("gst-theme", value);
    } catch {
      // storage unavailable — theme still applies for this session
    }
  };

  const togglePasswordVisibility = (field) => () => {
    setShowPasswords((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const validate = () => {
    const next = {};

    if (!form.full_name.trim()) next.full_name = "Full name is required.";
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(form.email.trim())) next.email = "Enter a valid email address.";
    if (form.phone && !/^[\d\s+()-]{7,15}$/.test(form.phone.trim())) {
      next.phone = "Enter a valid phone number.";
    }

    // Only validate password fields if the person is actually trying to change it
    const wantsPasswordChange =
      form.current_password || form.new_password || form.confirm_password;

    if (wantsPasswordChange) {
      if (!form.current_password) next.current_password = "Enter your current password.";
      if (!form.new_password) {
        next.new_password = "Enter a new password.";
      } else if (form.new_password.length < 8) {
        next.new_password = "Password must be at least 8 characters.";
      }
      if (form.new_password !== form.confirm_password) {
        next.confirm_password = "Passwords do not match.";
      }
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      setSaveState("error");
      // Jump to whichever tab has the first error, so it's actually visible
      if (errors.full_name || errors.email || errors.phone) setActiveTab("profile");
      else if (errors.current_password || errors.new_password || errors.confirm_password) {
        setActiveTab("security");
      }
      return;
    }

    setSaveState("saving");

    // Persist the non-sensitive profile fields; never store passwords client-side
    const { current_password, new_password, confirm_password, ...persistable } = form;

    try {
      await new Promise((resolve) => setTimeout(resolve, 700)); // simulate a real save request
      localStorage.setItem("gst-profile", JSON.stringify(persistable));
      setSaveState("saved");
      setForm((prev) => ({ ...prev, current_password: "", new_password: "", confirm_password: "" }));
      setTimeout(() => setSaveState("idle"), 2500);
    } catch {
      setSaveState("error");
    }
  };

  return (
    <div className="settings-wrapper">
      <div className="settings-header">
        <p className="settings-eyebrow">Account</p>
        <h1>Settings</h1>
        <p className="settings-sub">Manage your profile, security, and preferences.</p>
      </div>

      <form onSubmit={handleSubmit} className="settings-layout">
        {/* ---------- Tab rail ---------- */}
        <div className="settings-tabs" role="tablist" aria-label="Settings sections">
          {TABS.map(({ key, label, Icon }) => (
            <button
              type="button"
              key={key}
              role="tab"
              aria-selected={activeTab === key}
              className={`settings-tab ${activeTab === key ? "is-active" : ""}`}
              onClick={() => setActiveTab(key)}
            >
              <Icon size={17} strokeWidth={2.25} />
              {label}
            </button>
          ))}
        </div>

        {/* ---------- Panels ---------- */}
        <div className="settings-panels">
          {activeTab === "profile" && (
            <div className="settings-card">
              <h2>
                <User size={19} strokeWidth={2.25} /> Profile
              </h2>
              <p className="settings-card__hint">
                This information is shown across your agency dashboard.
              </p>

              <div className="field-group">
                <label>Full name</label>
                <input
                  type="text"
                  name="full_name"
                  placeholder="e.g. Ananya Sharma"
                  value={form.full_name}
                  onChange={handleChange}
                  className={errors.full_name ? "has-error" : ""}
                />
                {errors.full_name && <span className="field-error"><AlertCircle size={12} /> {errors.full_name}</span>}
              </div>

              <div className="field-group">
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={handleChange}
                  className={errors.email ? "has-error" : ""}
                />
                {errors.email && <span className="field-error"><AlertCircle size={12} /> {errors.email}</span>}
              </div>

              <div className="field-row">
                <div className="field-group">
                  <label>Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    placeholder="+91 12345 67890"
                    value={form.phone}
                    onChange={handleChange}
                    className={errors.phone ? "has-error" : ""}
                  />
                  {errors.phone && <span className="field-error"><AlertCircle size={12} /> {errors.phone}</span>}
                </div>

                <div className="field-group">
                  <label>City</label>
                  <input
                    type="text"
                    name="city"
                    placeholder="Coimbatore"
                    value={form.city}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="field-group">
                <label>Country</label>
                <input
                  type="text"
                  name="country"
                  placeholder="India"
                  value={form.country}
                  onChange={handleChange}
                />
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div className="settings-card">
              <h2>
                <Lock size={19} strokeWidth={2.25} /> Security
              </h2>
              <p className="settings-card__hint">
                Leave these blank if you don't want to change your password.
              </p>

              <div className="field-group">
                <label>Current password</label>
                <div className="password-field">
                  <input
                    type={showPasswords.current ? "text" : "password"}
                    name="current_password"
                    placeholder="••••••••"
                    value={form.current_password}
                    onChange={handleChange}
                    className={errors.current_password ? "has-error" : ""}
                  />
                  <button type="button" className="password-toggle" onClick={togglePasswordVisibility("current")}>
                    {showPasswords.current ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.current_password && (
                  <span className="field-error"><AlertCircle size={12} /> {errors.current_password}</span>
                )}
              </div>

              <div className="field-group">
                <label>New password</label>
                <div className="password-field">
                  <input
                    type={showPasswords.next ? "text" : "password"}
                    name="new_password"
                    placeholder="At least 8 characters"
                    value={form.new_password}
                    onChange={handleChange}
                    className={errors.new_password ? "has-error" : ""}
                  />
                  <button type="button" className="password-toggle" onClick={togglePasswordVisibility("next")}>
                    {showPasswords.next ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.new_password && (
                  <span className="field-error"><AlertCircle size={12} /> {errors.new_password}</span>
                )}
              </div>

              <div className="field-group">
                <label>Confirm new password</label>
                <div className="password-field">
                  <input
                    type={showPasswords.confirm ? "text" : "password"}
                    name="confirm_password"
                    placeholder="Re-enter new password"
                    value={form.confirm_password}
                    onChange={handleChange}
                    className={errors.confirm_password ? "has-error" : ""}
                  />
                  <button type="button" className="password-toggle" onClick={togglePasswordVisibility("confirm")}>
                    {showPasswords.confirm ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.confirm_password && (
                  <span className="field-error"><AlertCircle size={12} /> {errors.confirm_password}</span>
                )}
              </div>
            </div>
          )}

          {activeTab === "preferences" && (
            <div className="settings-card">
              <h2>
                <SlidersHorizontal size={19} strokeWidth={2.25} /> Preferences
              </h2>
              <p className="settings-card__hint">Choose your language and how the dashboard looks.</p>

              <div className="field-group">
                <label>Language</label>
                <select name="language" value={form.language} onChange={handleChange}>
                  {LANGUAGES.map((lang) => (
                    <option key={lang}>{lang}</option>
                  ))}
                </select>
              </div>

              <div className="field-group">
                <label>Theme</label>
                <div className="theme-picker">
                  <button
                    type="button"
                    className={`theme-option ${form.theme === "light" ? "is-active" : ""}`}
                    onClick={() => handleThemeChange({ target: { value: "light" } })}
                  >
                    <span className="theme-swatch theme-swatch--light" />
                    Light
                  </button>
                  <button
                    type="button"
                    className={`theme-option ${form.theme === "dark" ? "is-active" : ""}`}
                    onClick={() => handleThemeChange({ target: { value: "dark" } })}
                  >
                    <span className="theme-swatch theme-swatch--dark" />
                    Dark
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "notifications" && (
            <div className="settings-card">
              <h2>
                <Bell size={19} strokeWidth={2.25} /> Notifications
              </h2>
              <p className="settings-card__hint">Choose what you'd like to be notified about.</p>

              <ToggleSwitch
                label="Email notifications"
                description="Booking confirmations, receipts, and account activity."
                checked={form.email_notifications}
                onChange={handleToggle("email_notifications")}
              />
              <ToggleSwitch
                label="SMS notifications"
                description="Time-sensitive alerts sent to your phone."
                checked={form.sms_notifications}
                onChange={handleToggle("sms_notifications")}
              />
              <ToggleSwitch
                label="Booking alerts"
                description="Get notified the moment a booking status changes."
                checked={form.booking_alerts}
                onChange={handleToggle("booking_alerts")}
              />
              <ToggleSwitch
                label="Marketing emails"
                description="Occasional offers, new packages, and travel guides."
                checked={form.marketing_emails}
                onChange={handleToggle("marketing_emails")}
              />
            </div>
          )}

          <button type="submit" className={`save-btn save-btn--${saveState}`} disabled={saveState === "saving"}>
            {saveState === "saving" && <><Loader2 size={18} className="spin" /> Saving...</>}
            {saveState === "saved" && <><Check size={18} /> Saved!</>}
            {saveState === "error" && <><AlertCircle size={18} /> Fix the errors above</>}
            {saveState === "idle" && <><Save size={18} /> Save Changes</>}
          </button>
        </div>
      </form>
    </div>
  );
}