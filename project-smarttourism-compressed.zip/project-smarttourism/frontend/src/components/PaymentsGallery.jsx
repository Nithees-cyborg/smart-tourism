import React from "react";

export default function PaymentsGallery({ images }) {
  return (
    <div className="card">
      <div className="card-title">🖼 Destination Gallery</div>
      <div className="gallery-strip">
        {images.map((src, i) => (
          <img key={i} src={src} alt={`Destination ${i + 1}`} className="gallery-img" />
        ))}
      </div>
    </div>
  );
}