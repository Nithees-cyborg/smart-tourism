import React from "react";

const REASONS = [
  {
    title: "Priced for solo travel",
    text: "No group minimums or shared-room surprises — every price shown is for one traveler.",
  },
  {
    title: "Full itinerary upfront",
    text: "See the exact day-by-day plan, places covered and transport before you enquire.",
  },
  {
    title: "Local, licensed guides",
    text: "Every package is run with vetted local operators and English-speaking guides.",
  },
  {
    title: "Flexible dates",
    text: "Shift your travel window at no extra cost up to 15 days before departure.",
  },
];

export default function Packageswhyus() {
  return (
    <section className="pkg-section" id="why-us" style={{ background: "var(--paper-dim)" }}>
      <div className="pkg-section-head">
        <span className="pkg-eyebrow">Why travelers choose us</span>
        <h2>Built for people who travel alone, well.</h2>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
          gap: 24,
        }}
      >
        {REASONS.map((r, i) => (
          <div
            key={r.title}
            style={{
              background: "var(--paper-card)",
              border: "1px solid var(--line)",
              borderRadius: "var(--radius)",
              padding: "26px 22px",
            }}
          >
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 12,
                color: "var(--gold-deep)",
                marginBottom: 12,
              }}
            >
              {String(i + 1).padStart(2, "0")}
            </div>
            <h3
              style={{
                fontFamily: "var(--font-display)",
                fontSize: 18,
                fontWeight: 600,
                margin: "0 0 8px",
              }}
            >
              {r.title}
            </h3>
            <p style={{ fontSize: 14, color: "var(--ink-soft)", lineHeight: 1.6, margin: 0 }}>
              {r.text}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}