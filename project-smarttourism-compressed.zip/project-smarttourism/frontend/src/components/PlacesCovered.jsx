import React, { useRef, useState } from "react";

/**
 * PlacesCovered — Global Smart Tourism edition
 * -----------------------------------------------------------------------
 * <PlacesCovered
 *   places={pkg.placesCovered}
 *   destination={pkg.destination}
 *   transport={pkg.transport}
 *   inclusions={pkg.inclusions}
 *   bookNowHref="/hotels"
 * />
 *
 * Fix in this version:
 * - transport / inclusions items were only showing an icon with no text.
 *   That happens when the real package data uses different field names
 *   than this component expected (e.g. plain strings, or `title`/`label`/
 *   `desc`/`type` instead of `name`/`description`/`icon`).
 * - Added `normalizeListItem()` below, which accepts ANY of these shapes
 *   and always produces a real name + description to render:
 *     "Private car transfer"                          (plain string)
 *     { title: "Private car", desc: "..." }            (alt keys)
 *     { label: "Private car", details: "...", type: "car" }
 *     { name: "Private car", description: "...", icon: "car" } (original shape)
 * -----------------------------------------------------------------------
 */

/* ------------------------------------------------------------------ */
/* DEMO DATA — replace every field below with your real trip content.  */
/* ------------------------------------------------------------------ */

const FALLBACK_PLACES = [
  { name: "Moscow", image: "https://picsum.photos/seed/moscow-kremlin/900/700", description: "Start in the capital: Red Square, the Kremlin's gold domes, and the marble stations of the Moscow Metro. Two full days to walk the old city before the train east." },
  { name: "St. Petersburg", image: "https://picsum.photos/seed/st-petersburg-canals/900/700", description: "Russia's 'Venice of the North' — the Hermitage, Peterhof's fountains, and a slow evening cruise along the canals as the palaces light up." },
  { name: "Golden Ring (Suzdal)", image: "https://picsum.photos/seed/golden-ring-suzdal/900/700", description: "A day trip into the countryside: onion-domed monasteries, wooden villages, and the kind of small-town Russia most itineraries skip entirely." },
];

const FALLBACK_TRANSPORT = [
  { name: "High-speed Sapsan train", icon: "train", description: "Moscow to St. Petersburg in under 4 hours, seat reserved." },
  { name: "Private airport transfers", icon: "car", description: "Door-to-door pickup and drop-off at every city, no shared shuttles." },
  { name: "Canal boat cruise", icon: "boat", description: "An evening cruise through St. Petersburg's canals, included." },
  { name: "Private day coach", icon: "bus", description: "Air-conditioned vehicle for the Golden Ring day trip, with driver." },
  { name: "Domestic flight (optional)", icon: "plane", description: "Fast-track add-on if you'd rather fly back to Moscow than train it." },
  { name: "Metro day pass", icon: "ticket", description: "Unlimited city metro travel for the days you're exploring solo." },
];

const FALLBACK_INCLUSIONS = [
  { name: "4-star accommodation", icon: "bed", description: "Centrally located hotels, every night of the itinerary." },
  { name: "Daily breakfast", icon: "food", description: "Full breakfast included at every hotel stay." },
  { name: "English-speaking guide", icon: "guide", description: "A local guide for every city tour and day trip." },
  { name: "Entry tickets", icon: "ticket", description: "Kremlin, Hermitage, Peterhof, and every listed sight — prepaid." },
  { name: "Travel insurance", icon: "shield", description: "Medical and trip-cancellation cover for the full trip length." },
  { name: "24/7 support line", icon: "headset", description: "A number to call any time, any day, while you're on the ground." },
];

/* ------------------------------------------------------------------ */
/* Tiny inline icon set — no external icon library required.           */
/* ------------------------------------------------------------------ */

const ICONS = {
  train: "M4 15a3 3 0 0 0 3 3l-1.5 2.5h9L13 18a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v8ZM4 11h12M8.5 18.5h.01M15.5 18.5h.01M7 7h10",
  car: "M4 16V11l2-5h12l2 5v5M4 16a1.5 1.5 0 0 0 3 0M17 16a1.5 1.5 0 0 0 3 0M4 16h2m11 0h3M4 11h16",
  boat: "M3 15h18l-2 5H5l-2-5ZM6 15V7l6-3 6 3v8M9 7h6M12 4v3",
  bus: "M4 16V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10M4 16a1.5 1.5 0 0 0 3 0M17 16a1.5 1.5 0 0 0 3 0M4 16h2m11 0h3M4 12h16M8 9h8",
  plane: "M12 3v7l7 4v2l-7-2-2 5H8l1-5-7 2v-2l7-4V5a2 2 0 0 1 4-2Z",
  ticket: "M4 9a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1.5a1.5 1.5 0 0 0 0 3V15a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1.5a1.5 1.5 0 0 0 0-3V9ZM10 7v10",
  bed: "M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7M3 18v-2h18v2M3 16v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1M13 13a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1",
  food: "M6 3v7a2 2 0 0 0 4 0V3M8 10v11M17 3c-1.5 1.5-2 3-2 5s.5 3.5 2 5v8",
  guide: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 3.6-7 8-7s8 3 8 7",
  shield: "M12 3l8 3v6c0 5-3.4 8.5-8 9-4.6-.5-8-4-8-9V6l8-3Z",
  headset: "M4 13v-1a8 8 0 0 1 16 0v1M4 13v4a2 2 0 0 0 2 2h1v-7H5a1 1 0 0 0-1 1ZM20 13v4a2 2 0 0 1-2 2h-1v-7h2a1 1 0 0 1 1 1ZM8 19v1a2 2 0 0 0 2 2h2",
  hotel: "M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7M3 18v-2h18v2",
  flight: "M12 3v7l7 4v2l-7-2-2 5H8l1-5-7 2v-2l7-4V5a2 2 0 0 1 4-2Z",
  meal: "M6 3v7a2 2 0 0 0 4 0V3M8 10v11M17 3c-1.5 1.5-2 3-2 5s.5 3.5 2 5v8",
  insurance: "M12 3l8 3v6c0 5-3.4 8.5-8 9-4.6-.5-8-4-8-9V6l8-3Z",
  support: "M4 13v-1a8 8 0 0 1 16 0v1M4 13v4a2 2 0 0 0 2 2h1v-7H5a1 1 0 0 0-1 1ZM20 13v4a2 2 0 0 1-2 2h-1v-7h2a1 1 0 0 1 1 1ZM8 19v1a2 2 0 0 0 2 2h2",
};

function Icon({ name, size = 20 }) {
  const d = ICONS[name] || ICONS.ticket;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Normalizer — accepts whatever shape your real package data is in    */
/* and always produces a { key, name, description, icon } to render.   */
/* ------------------------------------------------------------------ */

function normalizeListItem(item, index, fallbackIcon = "ticket") {
  // Case 1: plain string, e.g. transport: ["Private car transfer", "Domestic flight"]
  if (typeof item === "string") {
    return { key: `${item}-${index}`, name: item, description: "", icon: fallbackIcon };
  }

  // Case 2: something falsy/unexpected — render a safe placeholder instead of blank
  if (!item || typeof item !== "object") {
    return { key: `item-${index}`, name: "Included", description: "", icon: fallbackIcon };
  }

  // Case 3: object with any of the common alternate key names
  const name =
    item.name || item.title || item.label || item.type || item.service || "Included";
  const description =
    item.description || item.desc || item.details || item.summary || item.note || "";
  const icon =
    item.icon || item.iconName || (ICONS[item.type] ? item.type : fallbackIcon);

  return { key: `${name}-${index}`, name, description, icon };
}

/* ------------------------------------------------------------------ */
/* Logo — self-contained SVG mark, no logo.png file required.          */
/* ------------------------------------------------------------------ */

function Logo({ companyName = "Global Smart Tourism" }) {
  const [first, ...rest] = companyName.split(" ");
  const restText = rest.join(" ");
  return (
    <div className="pc-logo">
      <span className="pc-logo-mark" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 40 40" fill="none">
          <circle cx="20" cy="20" r="20" fill="url(#pc-logo-grad)" />
          <path d="M6 22c4-5 8 5 12 0s8-5 12 0" stroke="#f7f4ee" strokeWidth="2.4" strokeLinecap="round" fill="none" />
          <path d="M6 16c4-5 8 5 12 0s8-5 12 0" stroke="#f7f4ee" strokeWidth="2.4" strokeLinecap="round" fill="none" opacity="0.55" />
          <defs>
            <linearGradient id="pc-logo-grad" x1="0" y1="0" x2="40" y2="40">
              <stop offset="0%" stopColor="#2f6a5e" />
              <stop offset="100%" stopColor="#17332d" />
            </linearGradient>
          </defs>
        </svg>
      </span>
      <span className="pc-logo-text">
        {first} <span className="pc-logo-accent">{restText}</span>
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main component                                                       */
/* ------------------------------------------------------------------ */

export default function PlacesCovered({
  places = FALLBACK_PLACES,
  destination = "This Trip",
  transport = FALLBACK_TRANSPORT,
  inclusions = FALLBACK_INCLUSIONS,
  bookNowHref = "/booking-overview",
  onBookNow,
  companyName = "Global Smart Tourism",
}) {
  const [activeIdx, setActiveIdx] = useState(null);
  const cardRefs = useRef([]);

  if (!places || places.length === 0) return null;

  const scrollToCard = (i) => {
    setActiveIdx(i);
    cardRefs.current[i]?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const handleBookNow = (e) => {
    if (onBookNow) {
      e.preventDefault();
      onBookNow();
    }
  };

  return (
    <section className="pc-wrap">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Work+Sans:wght@400;500;600&display=swap');

        .pc-wrap {
          --ink: #f4f1ea;
          --navy: #0a0e1a;
          --navy-deep: #05070d;
          --navy-soft: #0d1428;
          --panel: rgba(244,241,234,0.045);
          --teal: #3fae94;
          --teal-dark: #17332d;
          --gold: #e3a94a;
          --gold-soft: rgba(227,169,74,0.35);
          --line: rgba(244,241,234,0.12);
          --btn-ink: #10182b;
          font-family: 'Work Sans', -apple-system, sans-serif;
          color: var(--ink);
          background: linear-gradient(180deg, var(--navy-deep) 0%, var(--navy) 55%, var(--navy-soft) 100%);
          padding: 40px 24px 64px;
          border-radius: 20px;
          position: relative;
          overflow: hidden;
        }

        .pc-bg { position: absolute; inset: 0; z-index: 0; overflow: hidden; pointer-events: none; }
        .pc-bg-grid {
          position: absolute; inset: -1px;
          background-image:
            linear-gradient(rgba(244,241,234,0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(244,241,234,0.05) 1px, transparent 1px);
          background-size: 42px 42px;
          -webkit-mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, black 0%, transparent 75%);
          mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, black 0%, transparent 75%);
          opacity: 0.7;
        }
        .pc-bg-stars {
          position: absolute; inset: 0; background-repeat: no-repeat;
          background-image:
            radial-gradient(1.5px 1.5px at 12% 22%, rgba(244,241,234,0.55), transparent),
            radial-gradient(1.5px 1.5px at 28% 68%, rgba(244,241,234,0.35), transparent),
            radial-gradient(1px 1px at 42% 12%, rgba(244,241,234,0.4), transparent),
            radial-gradient(1.5px 1.5px at 58% 48%, rgba(244,241,234,0.3), transparent),
            radial-gradient(1px 1px at 72% 78%, rgba(244,241,234,0.45), transparent),
            radial-gradient(1.5px 1.5px at 85% 30%, rgba(244,241,234,0.35), transparent),
            radial-gradient(1px 1px at 94% 62%, rgba(244,241,234,0.3), transparent),
            radial-gradient(1.5px 1.5px at 6% 85%, rgba(244,241,234,0.35), transparent);
          opacity: 0.85;
        }
        .pc-blob { position: absolute; border-radius: 50%; filter: blur(70px); opacity: 0.5; }
        .pc-blob-a { width: 340px; height: 340px; top: -140px; right: -100px; background: radial-gradient(circle, rgba(227,169,74,0.55), transparent 70%); animation: pc-float-a 16s ease-in-out infinite; }
        .pc-blob-b { width: 300px; height: 300px; bottom: -120px; left: -80px; background: radial-gradient(circle, rgba(63,174,148,0.45), transparent 70%); animation: pc-float-b 18s ease-in-out infinite; }
        @keyframes pc-float-a { 0%, 100% { transform: translate(0, 0); } 50% { transform: translate(-20px, 25px); } }
        @keyframes pc-float-b { 0%, 100% { transform: translate(0, 0); } 50% { transform: translate(25px, -20px); } }
        @media (prefers-reduced-motion: reduce) { .pc-blob { animation: none !important; } }

        .pc-logo { position: relative; z-index: 1; display: inline-flex; align-items: center; gap: 10px; margin-bottom: 28px; }
        .pc-logo-mark { display: inline-flex; width: 34px; height: 34px; border-radius: 50%; overflow: hidden; flex-shrink: 0; }
        .pc-logo-text { font-family: 'Fraunces', serif; font-weight: 600; font-size: 18px; letter-spacing: 0.01em; color: var(--ink); }
        .pc-logo-accent { color: var(--gold); }

        .pc-head { position: relative; z-index: 1; display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin: 0 auto 20px; max-width: 1080px; flex-wrap: wrap; }
        .pc-eyebrow { display: block; font-size: 12px; letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold); font-weight: 600; margin-bottom: 8px; }
        .pc-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: clamp(28px, 4vw, 40px); margin: 0 0 8px; line-height: 1.05; }
        .pc-intro { font-size: 14.5px; color: rgba(244,241,234,0.62); max-width: 480px; line-height: 1.55; margin: 0; }
        .pc-count { font-size: 13px; color: var(--gold); font-weight: 600; white-space: nowrap; background: rgba(227,169,74,0.12); padding: 6px 12px; border-radius: 100px; }

        .pc-nav { position: relative; z-index: 1; max-width: 1080px; margin: 0 auto 28px; display: flex; flex-wrap: wrap; gap: 8px; padding-bottom: 20px; border-bottom: 1px solid var(--line); }
        .pc-pill { font-family: 'Work Sans', sans-serif; font-size: 12.5px; font-weight: 500; color: rgba(244,241,234,0.75); background: var(--panel); border: 1px solid var(--line); border-radius: 100px; padding: 7px 14px; cursor: pointer; transition: all 0.25s ease; }
        .pc-pill:hover { border-color: var(--gold); color: var(--ink); background: rgba(227,169,74,0.12); }
        .pc-pill.active { background: var(--gold); color: var(--btn-ink); border-color: var(--gold); }

        .pc-grid { position: relative; z-index: 1; max-width: 1080px; margin: 0 auto; display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: 130px; gap: 18px; }
        .pc-card { position: relative; overflow: hidden; border-radius: 16px; background: var(--teal-dark); isolation: isolate; grid-column: span 2; grid-row: span 2; opacity: 1; transition: transform 0.35s ease, box-shadow 0.35s ease; box-shadow: 0 0 0 rgba(0,0,0,0); }
        .pc-card.hero { grid-column: span 2; grid-row: span 3; }
        .pc-card:hover, .pc-card.pc-open { transform: translateY(-4px); box-shadow: 0 18px 32px -14px rgba(23,51,45,0.45); }
        .pc-card img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; transition: transform 0.7s cubic-bezier(0.16, 1, 0.3, 1); }
        .pc-card:hover img, .pc-card.pc-open img { transform: scale(1.08); }
        .pc-card::after { content: ""; position: absolute; inset: 0; background: linear-gradient(180deg, rgba(23,51,45,0) 30%, rgba(15,26,23,0.94) 100%); transition: background 0.4s ease; }
        .pc-card:hover::after, .pc-card.pc-open::after { background: linear-gradient(180deg, rgba(23,51,45,0.05) 20%, rgba(15,26,23,0.97) 100%); }
        .pc-stamp { position: absolute; top: 16px; left: 16px; z-index: 2; width: 34px; height: 34px; border-radius: 50%; background: rgba(247,244,238,0.92); color: var(--teal-dark); font-family: 'Fraunces', serif; font-weight: 600; font-size: 13px; display: flex; align-items: center; justify-content: center; transition: box-shadow 0.3s ease; }
        .pc-card:hover .pc-stamp, .pc-card.pc-open .pc-stamp { box-shadow: 0 0 0 6px rgba(201,154,62,0.28); }
        .pc-body { position: absolute; left: 0; right: 0; bottom: 0; z-index: 2; padding: 18px 20px; color: #f7f4ee; }
        .pc-name { font-family: 'Fraunces', serif; font-weight: 600; font-size: 19px; margin: 0 0 6px; position: relative; display: inline-block; }
        .pc-card.hero .pc-name { font-size: 25px; }
        .pc-rule { display: block; width: 22px; height: 2px; background: var(--gold); margin-bottom: 10px; transition: width 0.35s ease; }
        .pc-card:hover .pc-rule, .pc-card.pc-open .pc-rule { width: 46px; }
        .pc-desc { font-size: 13.2px; line-height: 1.5; color: rgba(247,244,238,0.88); max-height: 0; opacity: 0; overflow: hidden; transition: max-height 0.35s ease, opacity 0.3s ease; }
        .pc-card:hover .pc-desc, .pc-card:focus-within .pc-desc, .pc-card.pc-open .pc-desc { max-height: 110px; opacity: 1; }
        .pc-card button.pc-tap { position: absolute; inset: 0; width: 100%; height: 100%; background: transparent; border: 0; padding: 0; cursor: pointer; }

        .pc-footnote { position: relative; z-index: 1; max-width: 1080px; margin: 20px auto 0; font-size: 12.5px; color: rgba(244,241,234,0.4); text-align: right; }

        .pc-section { position: relative; z-index: 1; max-width: 1080px; margin: 56px auto 0; }
        .pc-section-head { margin-bottom: 22px; }
        .pc-section-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: clamp(22px, 3vw, 28px); margin: 0 0 6px; }
        .pc-section-sub { font-size: 14px; color: rgba(244,241,234,0.6); margin: 0; max-width: 520px; line-height: 1.5; }

        .pc-item-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
        .pc-item { display: flex; gap: 12px; align-items: flex-start; background: var(--panel); backdrop-filter: blur(6px); border: 1px solid var(--line); border-radius: 14px; padding: 16px; transition: border-color 0.25s ease, transform 0.25s ease, background 0.25s ease; }
        .pc-item:hover { border-color: var(--gold-soft); background: rgba(244,241,234,0.07); transform: translateY(-2px); }
        .pc-item-icon { flex-shrink: 0; width: 38px; height: 38px; border-radius: 10px; background: rgba(227,169,74,0.12); color: var(--gold); display: flex; align-items: center; justify-content: center; }
        .pc-item-text { min-width: 0; }
        .pc-item-name { font-family: 'Fraunces', serif; font-weight: 600; font-size: 15px; margin: 0 0 4px; color: var(--ink); }
        .pc-item-desc { font-size: 12.8px; line-height: 1.45; color: rgba(244,241,234,0.6); margin: 0; }
        .pc-item-desc:empty { display: none; }

        .pc-cta { position: relative; z-index: 1; max-width: 1080px; margin: 48px auto 0; background: linear-gradient(135deg, rgba(227,169,74,0.14), rgba(244,241,234,0.03)); border: 1px solid var(--line); border-radius: 18px; padding: 32px 36px; display: flex; align-items: center; justify-content: space-between; gap: 20px; flex-wrap: wrap; }
        .pc-cta-text h3 { font-family: 'Fraunces', serif; font-weight: 600; font-size: 22px; color: var(--ink); margin: 0 0 6px; }
        .pc-cta-text p { font-size: 13.5px; color: rgba(244,241,234,0.65); margin: 0; max-width: 420px; line-height: 1.5; }
        .pc-cta-btn { font-family: 'Work Sans', sans-serif; font-weight: 600; font-size: 14.5px; color: var(--btn-ink); background: var(--gold); border: none; border-radius: 100px; padding: 14px 30px; cursor: pointer; text-decoration: none; white-space: nowrap; transition: background 0.25s ease, transform 0.25s ease; display: inline-block; }
        .pc-cta-btn:hover { background: #ddb257; transform: translateY(-2px); }

        @media (max-width: 860px) {
          .pc-grid { grid-template-columns: repeat(2, 1fr); grid-auto-rows: 160px; }
          .pc-card, .pc-card.hero { grid-column: span 2; grid-row: span 2; }
          .pc-card.hero { grid-row: span 3; }
          .pc-item-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 520px) {
          .pc-wrap { padding: 32px 16px 48px; }
          .pc-grid { grid-template-columns: 1fr; grid-auto-rows: 220px; }
          .pc-card, .pc-card.hero { grid-column: span 1; grid-row: span 1; }
          .pc-item-grid { grid-template-columns: 1fr; }
          .pc-cta { flex-direction: column; align-items: flex-start; }
        }
        @media (prefers-reduced-motion: reduce) {
          .pc-card, .pc-card img, .pc-item, .pc-cta-btn { transition: none !important; }
        }
      `}</style>

      <div className="pc-bg" aria-hidden="true">
        <span className="pc-bg-grid" />
        <span className="pc-bg-stars" />
        <span className="pc-blob pc-blob-a" />
        <span className="pc-blob pc-blob-b" />
      </div>

      <Logo companyName={companyName} />

      <div className="pc-head">
        <div>
          <span className="pc-eyebrow">Places Covered</span>
          <h2 className="pc-title">Where {destination} takes you</h2>
          <p className="pc-intro">
            A quick look at every stop woven into this trip, in the order you'll actually visit them — tap a photo for the story behind it.
          </p>
        </div>
        <span className="pc-count">{places.length} stops</span>
      </div>

      <div className="pc-nav">
        {places.map((place, i) => (
          <button key={place.name} className={`pc-pill ${activeIdx === i ? "active" : ""}`} onClick={() => scrollToCard(i)}>
            {String(i + 1).padStart(2, "0")} · {place.name}
          </button>
        ))}
      </div>

      <div className="pc-grid">
        {places.map((place, i) => (
          <PlaceCard
            key={place.name}
            place={place}
            index={i}
            hero={i === 0}
            isOpen={activeIdx === i}
            onToggle={() => setActiveIdx(activeIdx === i ? null : i)}
            cardRef={(el) => (cardRefs.current[i] = el)}
          />
        ))}
      </div>

      <p className="pc-footnote">Route shown in visiting order, not distance.</p>

      {/* ---------- Getting Around (transport) ---------- */}
      {transport && transport.length > 0 && (
        <div className="pc-section">
          <div className="pc-section-head">
            <h3 className="pc-section-title">Getting around</h3>
            <p className="pc-section-sub">Every transfer between stops is arranged for you — nothing to book separately.</p>
          </div>
          <div className="pc-item-grid">
            {transport.map((raw, idx) => {
              const item = normalizeListItem(raw, idx, "car");
              return (
                <div className="pc-item" key={item.key}>
                  <span className="pc-item-icon"><Icon name={item.icon} /></span>
                  <div className="pc-item-text">
                    <p className="pc-item-name">{item.name}</p>
                    {item.description && <p className="pc-item-desc">{item.description}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ---------- What's Included ---------- */}
      {inclusions && inclusions.length > 0 && (
        <div className="pc-section">
          <div className="pc-section-head">
            <h3 className="pc-section-title">What's included</h3>
            <p className="pc-section-sub">The package price covers all of this — no hidden add-ons at checkout.</p>
          </div>
          <div className="pc-item-grid">
            {inclusions.map((raw, idx) => {
              const item = normalizeListItem(raw, idx, "ticket");
              return (
                <div className="pc-item" key={item.key}>
                  <span className="pc-item-icon"><Icon name={item.icon} /></span>
                  <div className="pc-item-text">
                    <p className="pc-item-name">{item.name}</p>
                    {item.description && <p className="pc-item-desc">{item.description}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ---------- Book Now CTA ---------- */}
      <div className="pc-cta">
        <div className="pc-cta-text">
          <h3>Ready to book {destination}?</h3>
          <p>Pick your dates and room on the next page — pricing updates live as you choose.</p>
        </div>
        <a href={bookNowHref} className="pc-cta-btn" onClick={handleBookNow}>Book now</a>
      </div>
    </section>
  );
}

function PlaceCard({ place, index, hero = false, isOpen, onToggle, cardRef }) {
  const label = String(index + 1).padStart(2, "0");
  return (
    <article ref={cardRef} className={`pc-card ${hero ? "hero" : ""} ${isOpen ? "pc-open" : ""}`}>
      <img src={place.image} alt={place.name} loading="lazy" />
      <span className="pc-stamp">{label}</span>
      <div className="pc-body">
        <span className="pc-rule" />
        <h3 className="pc-name">{place.name}</h3>
        <p className="pc-desc">{place.description}</p>
      </div>
      <button className="pc-tap" aria-expanded={isOpen} aria-label={`Toggle description for ${place.name}`} onClick={onToggle} />
    </article>
  );
}