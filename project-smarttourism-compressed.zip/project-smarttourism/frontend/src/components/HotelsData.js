// HotelsData.js
import PACKAGES_DATA from "./packagesData";

const HOTEL_NAMES = {
  india: "The Leela Palace",
  lakshadweep: "Coral Tide Lagoon Retreat",
  mauritius: "Le Morne Azure Resort & Spa",
  tamilnadu: "Taj Coromandel",
  russia: "Nevsky Imperial Hotel",
  saudiarabia: "AlUla Sandstone Lodge",
  scotland: "Highland Thistle Manor",
  portugal: "Ribeira Riverside Hotel",
  argentina: "Patagonia Fitz Roy Lodge",
  korea: "Hanok Myeongdong Suites",
  bali: "Ubud Rice Terrace Villas",
  switzerland: "Matterhorn View Chalet Hotel",
  vietnam: "Ha Long Pearl Cruise Hotel",
  kenya: "Mara Acacia Safari Camp",
  japan: "Sakura Shibuya Hotel",
  thailand: "Andaman Cove Beach Resort",
  singapore: "Marina Skyline Hotel",
  dubai: "Burj Vista Grand Hotel",
  maldives: "Azure Reef Overwater Resort",
  nepal: "Annapurna Lakeside Lodge",
  srilanka: "Sigiriya Heritage Hotel",
  kashmir: "Dal Lake Houseboat Retreat",
  andaman: "Radhanagar Beachfront Resort",
  turkey: "Cappadocia Cave Suites",
  greece: "Caldera Cliffside Hotel",
  italy: "Ponte Vecchio Grand Hotel",
  france: "Champ de Mars Boutique Hotel",
  iceland: "Aurora Glacier Lodge",
  newzealand: "Queenstown Lakeview Lodge",
  egypt: "Nile Pharaoh Cruise Hotel",
  morocco: "Marrakech Riad Palace",
  peru: "Sacred Valley Inca Lodge",
  bhutan: "Paro Valley Heritage Lodge",
};

function parseNights(duration) {
  const match = duration.match(/(\d+)\s*Nights?/i);
  return match ? parseInt(match[1], 10) : 1;
}

function parsePriceToNumber(price) {
  return parseInt(String(price).replace(/,/g, ""), 10);
}

function roundTo(num, step = 50) {
  return Math.round(num / step) * step;
}

// Turns a hotel name into a filename-safe slug:
// "Coral Tide Lagoon Retreat" -> "coraltidelagoonretreat"
function slugifyName(name) {
  return name
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]/g, "");
}

// Builds 3 room tiers off the package's derived per-night rate:
// Single (1 guest) < Double/Deluxe (2 guests, this is the "avg" shown on cards) < Suite (3-4 guests)
function buildRooms(basePerNight) {
  return [
    {
      id: "single",
      name: "Single Occupancy Room",
      type: "Single",
      occupancy: 1,
      maxGuests: 1,
      pricePerNight: roundTo(basePerNight * 0.62),
      description: "A cosy room for the solo traveller — one bed, full amenities, same great location.",
    },
    {
      id: "double",
      name: "Deluxe Double Room",
      type: "Double",
      occupancy: 2,
      maxGuests: 2,
      pricePerNight: basePerNight,
      description: "Our most-booked room — two guests, one or two beds, and the best view-to-price ratio in the property.",
      popular: true,
    },
    {
      id: "suite",
      name: "Premium Family Suite",
      type: "Suite",
      occupancy: 3,
      maxGuests: 4,
      pricePerNight: roundTo(basePerNight * 1.65),
      description: "A separate living area plus bedroom — built for families or small groups travelling together.",
    },
  ];
}

const HOTELS_DATA = PACKAGES_DATA.map((pkg) => {
  const nights = parseNights(pkg.duration);
  const totalPrice = parsePriceToNumber(pkg.price);
  const perNight = Math.max(1500, roundTo(totalPrice / nights));
  const rooms = buildRooms(perNight);

  const name = HOTEL_NAMES[pkg.id] || `${pkg.destination} Grand Hotel`;
  const slug = slugifyName(name);

  return {
    id: pkg.id,
    code: pkg.code,
    name,
    packageName: pkg.package_name,
    location: pkg.destination,
    rating: pkg.rating,
    tag: pkg.tag,
    price: perNight, // avg/night (double occupancy) — used on card
    nights,
    desc: pkg.tagline,
    images: [1, 2, 3].map((n) => `/${slug}${n}.jpg`),
    amenities: pkg.highlights,
    overview: pkg.overview,
    itinerary: pkg.itinerary,
    transport: pkg.transport,
    inclusions: pkg.inclusions,
    exclusions: pkg.exclusions,
    bestTime: pkg.bestTime,
    rooms, // NEW — [{id, name, type, occupancy, maxGuests, pricePerNight, description, popular}]
  };
});

export function getHotelById(id) {
  return HOTELS_DATA.find((h) => h.id === id);
}

export default HOTELS_DATA;