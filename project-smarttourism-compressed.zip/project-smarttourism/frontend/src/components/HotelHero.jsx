import React from "react";

export default function HotelHero() {
  return (
    <section className="hero">
      <div className="hero-rings" aria-hidden="true">
        <span></span>
        <span></span>
      </div>
      <div className="hero-inner">
        <span className="hero-eyebrow">Curated Global Portfolio</span>
        <h1 className="hero-title">
          Thirty rooms worth <em>changing time zones</em> for.
        </h1>
        <p className="hero-subtitle">
          From a sail-shaped tower over the Arabian Gulf to overwater villas
          on a private Maldivian reef, every address here earned its place
          for what it's actually like to wake up there — not just its star
          rating.
        </p>
        <div className="hero-stats">
          <div className="hero-stat">
            <span className="hero-stat-value">30</span>
            <span className="hero-stat-label">Properties</span>
          </div>
          <div className="hero-stat-divider"></div>
          <div className="hero-stat">
            <span className="hero-stat-value">15</span>
            <span className="hero-stat-label">Countries</span>
          </div>
          <div className="hero-stat-divider"></div>
          <div className="hero-stat">
            <span className="hero-stat-value">4.7</span>
            <span className="hero-stat-label">Avg. Rating</span>
          </div>
          <div className="hero-stat-divider"></div>
          <div className="hero-stat">
            <span className="hero-stat-value">₹18,500</span>
            <span className="hero-stat-label">From / Night</span>
          </div>
        </div>

        <div className="hero-cta">
          <a href="#hotelGrid" className="btn-hero-primary">
            Browse All Properties <i className="fa-solid fa-arrow-right"></i>
          </a>
        </div>

        <div className="hero-trust">
          <span><i className="fa-solid fa-circle-check"></i> Hand-vetted properties</span>
          <span><i className="fa-solid fa-circle-check"></i> Verified nightly rates</span>
          <span><i className="fa-solid fa-circle-check"></i> Refreshed for 2026</span>
        </div>
      </div>

      <a href="#hotelGrid" className="hero-scroll-cue">
        Scroll
        <i className="fa-solid fa-chevron-down"></i>
      </a>
    </section>
  );
}