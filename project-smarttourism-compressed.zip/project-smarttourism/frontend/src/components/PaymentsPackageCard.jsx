import React from "react";
import { useLocation } from "react-router-dom";

export default function PaymentsPackageCard({ pkg, travelDate, persons, status, totalAmount }) {
  const { state } = useLocation();

  // Prefer explicit props if a parent passed them. Otherwise fall back to
  // the exact state object RegisterBooking.jsx handed off via
  // navigate("/payments", { state: { pkg, checkIn, travellers, grandTotal, ... } })
  const resolvedPkg = pkg || state?.pkg;
  const resolvedTravelDate = travelDate || state?.checkIn || state?.date || "—";
  const resolvedPersons = persons ?? state?.travellers ?? 1;
  const resolvedStatus = status || "Pending";
  const resolvedAmount =
    totalAmount !== undefined && totalAmount !== null
      ? totalAmount
      : state?.grandTotal ?? 0;

  if (!resolvedPkg) {
    return (
      <div className="card">
        <div className="card-title">🌍 Package Details</div>
        <p style={{ fontSize: 13, opacity: 0.6 }}>
          No package data found. Please go back and start your booking again.
        </p>
      </div>
    );
  }

  return (
    <div className="card">
      <div className="card-title">🌍 Package Details</div>
      <div className="info-row">
        <span className="info-label">Package</span>
        <span className="info-val">{resolvedPkg.package_name}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Destination</span>
        <span className="info-val">{resolvedPkg.destination}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Travel Date</span>
        <span className="info-val">{resolvedTravelDate}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Persons</span>
        <span className="info-val">{resolvedPersons}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Status</span>
        <span className="info-val">
          <span className="status-badge">{resolvedStatus}</span>
        </span>
      </div>

      <div className="amount-box">
        <div className="amount-label">Total Amount Payable</div>
        <div className="amount-num">₹ {Number(resolvedAmount).toLocaleString("en-IN")}</div>
        <div className="amount-sub">Inclusive of all taxes &amp; fees</div>
      </div>
    </div>
  );
}