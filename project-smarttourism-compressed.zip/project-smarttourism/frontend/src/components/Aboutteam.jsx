const TEAM = [
  { img: "team1.jpg", initial: "A", grad: "linear-gradient(135deg,var(--ocean),var(--ocean-lite))", name: "Arjun Mehta", role: "Co-Founder & CEO", bio: "Arjun has backpacked through 45 countries and believes the best itinerary leaves room for the unexpected.", socials: ["linkedin-in", "instagram"] },
  { img: "team2.jpg", initial: "P", grad: "linear-gradient(135deg,var(--teal),#34c0b0)", name: "Priya Sharma", role: "Co-Founder & COO", bio: "Priya built our hotel partner network from scratch. If she hasn't stayed there personally, we don't list it.", socials: ["linkedin-in", "instagram"] },
  { img: "team3.jpg", initial: "R", grad: "linear-gradient(135deg,#7c5cdb,#a78bfa)", name: "Rahul Iyer", role: "Head of Destinations", bio: "Rahul spent three years living across Southeast Asia and the Middle East. He writes every destination guide we publish.", socials: ["linkedin-in", "x-twitter"] },
  { img: "team4.jpg", initial: "S", grad: "linear-gradient(135deg,var(--rose),#e98a7c)", name: "Sneha Kapoor", role: "Head of Guest Experience", bio: "Sneha leads our 24/7 support team. Her rule: every guest issue gets resolved within one hour, no exceptions.", socials: ["linkedin-in", "instagram"] },
];

const AWARDS = [
  { icon: "fa-trophy", year: 2024, title: "Best Travel Agency — India", org: "Travel + Leisure India Awards, voted by 200,000+ travellers nationwide." },
  { icon: "fa-medal", year: 2023, title: "Excellence in Sustainable Tourism", org: "Global Sustainable Tourism Council, recognising our carbon-offset programme." },
  { icon: "fa-star", year: 2023, title: "Top-Rated on Tripadvisor", org: "Travellers' Choice Award — 4.9 star average across 8,000+ reviews." },
  { icon: "fa-shield-halved", year: 2022, title: "ISO 9001:2015 Certified", org: "Quality management certification covering our full booking and support operations." },
  { icon: "fa-leaf", year: 2021, title: "Green Tourism Certification", org: "Certified by EarthCheck for our eco-partner hotel network and offset policy." },
  { icon: "fa-certificate", year: 2020, title: "Ministry of Tourism — Recognised Agency", org: "Approved and listed by the Government of India Ministry of Tourism as a preferred operator." },
];

const PARTNERS = ["Air India", "IndiGo", "Emirates", "Marriott", "Taj Hotels", "Accor", "Oberoi", "Hilton"];

export function Aboutteam() {
  return (
    <div className="sec">
      <div className="sec-head reveal">
        <p className="eyebrow" style={{ justifyContent: "center" }}>The People Behind Your Trip</p>
        <h2 className="sec-title">Meet Our Leadership</h2>
        <p className="sec-sub">
          Travellers, problem-solvers, and local experts — every one of them has personally visited
          the destinations they recommend.
        </p>
      </div>
      <div className="team-grid">
        {TEAM.map((m) => (
          <div className="team-card reveal" key={m.name}>
            <div className="team-photo">
              <img
                src={`/images/${m.img}`}
                alt={m.name}
                onError={(e) => {
                  e.target.style.display = "none";
                  e.target.nextElementSibling.style.display = "flex";
                }}
              />
              <div className="team-placeholder" style={{ display: "none", background: m.grad }}>
                {m.initial}
              </div>
              <div className="team-socials">
                {m.socials.map((s) => (
                  <a href="#" className="team-soc" key={s}>
                    <i className={`fa-brands fa-${s}`}></i>
                  </a>
                ))}
              </div>
            </div>
            <div className="team-body">
              <div className="team-name">{m.name}</div>
              <div className="team-role">{m.role}</div>
              <div className="team-bio">{m.bio}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Aboutawards() {
  return (
    <>
      <div className="sec">
        <div className="sec-head reveal">
          <p className="eyebrow" style={{ justifyContent: "center" }}>Recognition</p>
          <h2 className="sec-title">Awards & Certifications</h2>
          <p className="sec-sub">We don't travel for trophies, but these remind us we're on the right track.</p>
        </div>
        <div className="awards-grid">
          {AWARDS.map((a) => (
            <div className="award-card reveal" key={a.title}>
              <div className="award-icon"><i className={`fa-solid ${a.icon}`}></i></div>
              <div>
                <div className="award-year">{a.year}</div>
                <div className="award-title">{a.title}</div>
                <div className="award-org">{a.org}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="partners-strip">
        <p className="partners-label">Trusted Partners &amp; Airlines We Work With</p>
        <div className="partners-logos">
          {PARTNERS.map((p) => (
            <div className="partner-logo" key={p}>{p}</div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Aboutteam;