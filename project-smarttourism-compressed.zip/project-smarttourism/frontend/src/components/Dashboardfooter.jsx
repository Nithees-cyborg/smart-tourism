import { Mail, Phone, MapPin, Component } from "lucide-react";
import '../components/Dashboardfooter.css';
/**
 * Dashboardfooter.jsx
 * Social icons are inline SVGs (lucide-react no longer exports brand icons
 * like Facebook/Instagram/Twitter), so this avoids any import errors.
 */
const COMPANY_NAME = "Global Smart Tourism";

function FacebookIcon(props) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  );
}

function InstagramIcon(props) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

function TwitterIcon(props) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
    </svg>
  );
}

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="dash-footer">
      <div className="dash-footer__brand">
        <span className="dash-footer__mark">
          <img src="/logo.png" alt={COMPANY_NAME} className="dash-footer__logo-img" />
        </span>
        <span>{COMPANY_NAME}</span>
      </div>

      <nav className="dash-footer__links" aria-label="Footer">
        <a href="/privacy/">Privacy</a>
        <a href="/terms/">Terms</a>
        <a href="/contact/">Support</a>
        <a href="/careers/">Careers</a>
      </nav>

      <div className="dash-footer__contact">
        <a href="mailto:desk@globalsmarttourism.com">
          <Mail size={14} strokeWidth={2.25} /> desk@globalsmarttourism.com
        </a>
        <a href="tel:+911234567890">
          <Phone size={14} strokeWidth={2.25} /> +91 12345 67890
        </a>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <MapPin size={14} strokeWidth={2.25} /> Coimbatore, India
        </span>
      </div>

      <div className="dash-footer__social">
        <a href="#" aria-label="Facebook"><FacebookIcon /></a>
        <a href="#" aria-label="Instagram"><InstagramIcon /></a>
        <a href="#" aria-label="Twitter"><TwitterIcon /></a>
      </div>

      <span className="dash-footer__copy">© {year} {COMPANY_NAME}. All rights reserved.</span>
    </footer>
  );
}