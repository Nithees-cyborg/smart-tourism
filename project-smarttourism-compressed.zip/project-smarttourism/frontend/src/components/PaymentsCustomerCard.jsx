import React from "react";
import { useLocation } from "react-router-dom";

export default function PaymentsCustomerCard({ customer }) {
  const { state } = useLocation();

  // Same fallback pattern: use the prop if a parent already built it,
  // otherwise read straight from what RegisterBooking.jsx passed on.
  const c = customer || {
    full_name: state?.fullName,
    email: state?.email,
    phone: state?.phone,
    city: state?.city,
    country: state?.country,
  };

  return (
    <div className="card">
      <div className="card-title">👤 Customer Details</div>
      <div className="info-row">
        <span className="info-label">Full Name</span>
        <span className="info-val">{c.full_name || "—"}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Email</span>
        <span className="info-val">{c.email || "—"}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Phone</span>
        <span className="info-val">{c.phone || "—"}</span>
      </div>
      <div className="info-row">
        <span className="info-label">City</span>
        <span className="info-val">{c.city || "—"}</span>
      </div>
      <div className="info-row">
        <span className="info-label">Country</span>
        <span className="info-val">{c.country || "—"}</span>
      </div>
    </div>
  );
}