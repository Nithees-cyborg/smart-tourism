function Serviceshero() {
  return (
    <>
      <section className="svc-hero">
        <div className="svc-hero-inner">
          <p className="eyebrow on-dark">Worldwide Service Network</p>
          <h1>Every detail of your journey, arranged.</h1>
          <p>
            From check-in to check-out, four services keep your trip moving —
            stays, flights, itineraries, and guides — all confirmed before you pack.
          </p>
          <div className="svc-hero-actions">
            <a href="/contact/" className="btn-gold">Plan My Trip</a>
            <a href="/packages/" className="btn-ghost">View Packages</a>
          </div>
        </div>
        <div className="svc-scroll-cue">
          <span>SCROLL</span>
          <i className="fa-solid fa-chevron-down"></i>
        </div>
      </section>

      <div className="svc-tear-edge"></div>

      <div className="svc-ticket-strip-wrap">
        <div className="svc-ticket-strip reveal">
          <div className="svc-stat">
            <div className="num">150+</div>
            <div className="label">Destinations</div>
          </div>
          <div className="svc-stat">
            <div className="num">24/7</div>
            <div className="label">Support Desk</div>
          </div>
          <div className="svc-stat">
            <div className="num">1,200+</div>
            <div className="label">Verified Partners</div>
          </div>
          <div className="svc-stat">
            <div className="num">0</div>
            <div className="label">Hidden Fees</div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Serviceshero;