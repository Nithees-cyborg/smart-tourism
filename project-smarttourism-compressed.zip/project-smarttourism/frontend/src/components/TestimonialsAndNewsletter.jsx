import { useEffect, useState } from "react";
import { MapPin, Check, Send } from "lucide-react";
import { fetchTestimonials, subscribeNewsletter } from "../components/DashboardApi";

export default function TestimonialsAndNewsletter() {
  const [testimonials, setTestimonials] = useState([]);
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    fetchTestimonials().then((d) => alive && setTestimonials(d));
    return () => {
      alive = false;
    };
  }, []);

  const handleSubscribe = async () => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(email.trim())) {
      setError("Enter a valid email to subscribe.");
      return;
    }
    try {
      await subscribeNewsletter(email.trim());
      setError("");
      setSubscribed(true);
      setEmail("");
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <>
      <div className="testi-section">
        <p className="section-eyebrow">Traveller Stories</p>
        <h2 className="section-title">What Our Customers Say</h2>
        <div className="testi-grid">
          {testimonials.map((t, i) => (
            <div className="testi-card testi-card--glass" key={t.id} style={{ "--i": i }}>
              <div className="testi-stars">★★★★★</div>
              <p className="testi-text">"{t.text}"</p>
              <div className="testi-author">
                <img className="testi-avatar-img" src={t.image} alt={t.name} loading="lazy" />
                <div>
                  <div className="testi-name">{t.name}</div>
                  <div className="testi-loc">
                    <MapPin size={11} strokeWidth={2.5} style={{ color: "var(--ocean)", verticalAlign: -1 }} /> {t.location}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="cta-banner cta-banner--gradient">
        <div className="cta-text">
          <h2>Get Exclusive Travel Deals in Your Inbox</h2>
          <p>Subscribe for early access to new packages, seasonal discounts, and insider destination guides.</p>
        </div>
        <div>
          <div className="cta-form">
            <input
              type="email"
              placeholder="Your email address"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError("");
              }}
              onKeyDown={(e) => e.key === "Enter" && handleSubscribe()}
              aria-invalid={!!error}
            />
            <button type="button" onClick={handleSubscribe} disabled={subscribed}>
              {subscribed ? (
                <>
                  <Check size={15} strokeWidth={2.5} /> Subscribed!
                </>
              ) : (
                <>
                  <Send size={15} strokeWidth={2.5} /> Subscribe
                </>
              )}
            </button>
          </div>
          {error && <p style={{ color: "#ffd7d7", fontSize: 12, margin: "8px 0 0" }}>{error}</p>}
        </div>
      </div>
    </>
  );
}