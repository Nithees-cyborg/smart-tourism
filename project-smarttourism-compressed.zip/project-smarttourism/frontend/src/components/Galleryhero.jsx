import React from 'react';

const Galleryhero = () => {
  return (
    <section className="hero">
      <div className="hero-rings" aria-hidden="true"><span></span><span></span></div>
      <div className="hero-inner">
        <span className="hero-eyebrow">Visual Stories</span>
        <h1 className="hero-title">Thirty frames from <em>the road</em>.</h1>
        <p className="hero-subtitle">
          A running visual record of the places, properties, and moments that make up the
          Global Smart Tourism portfolio &mdash; captured, not staged.
        </p>
        <div className="hero-stats">
          <span className="hero-chip"><i className="fa-solid fa-image"></i> 30 Photos</span>
          <span className="hero-chip"><i className="fa-solid fa-tags"></i> 6 Categories</span>
          <span className="hero-chip"><i className="fa-solid fa-calendar"></i> Refreshed for 2026</span>
        </div>
      </div>
    </section>
  );
};

export default Galleryhero;