import React from "react";

/**
 * Contact_SuccessFooter.jsx
 * Small fallback line with phone + email, shown at the bottom of the card.
 * Paste into: src/components/Contact_SuccessFooter.jsx
 */
export default function Contact_SuccessFooter() {
  return (
    <p className="cs-fallback-line">
      Need this sooner? Call <a href="tel:+91 97845 45454">+91 97845 45454</a> or email{" "}
      <a href="mailto:support@globalsmarttourism.example">support@globalsmarttourism.example</a>
    </p>
  );
}