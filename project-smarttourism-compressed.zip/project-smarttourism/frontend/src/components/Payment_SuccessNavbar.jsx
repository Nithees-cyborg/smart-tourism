import React from "react";

export default function Payment_SuccessNavbar() {
  return (
    <nav className="navbar">
      <div className="nav-brand">
        <div className="nav-logo">✈</div>
        <h2>Global Smart Tourism</h2>
      </div>
      <div className="nav-status">✅ Booking Confirmed</div>
    </nav>
  );
}