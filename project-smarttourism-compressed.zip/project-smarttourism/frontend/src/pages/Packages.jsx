import React, { useEffect, useMemo, useState } from "react";
import Packagesnavbar from "../components/Packagesnavbar";
import Packageshero from "../components/Packageshero";
import Packagesstats from "../components/Packagesstats";
import Packagesgrid from "../components/Packagesgrid";
import PackageDetail from "../components/PackageDetail";
import BookingOverview from "../components/BookingOverview";
import Packageswhyus from "../components/Packageswhyus";
import Packagesfooter from "../components/Packagesfooter";
import PACKAGES_DATA from "../components/packagesData";
import PlacesCovered from "../components/PlacesCovered";
import "../components/Packages.css";

export default function Packages() {
  // ── Theme (persisted like the original inline <script>) ──
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  // ── Search / filter state ──
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setSearch(searchInput.trim());
  };

  const handleSelectChip = (keyword) => {
    setSearchInput(keyword);
    setSearch(keyword);
  };

  const handleClear = () => {
    setSearchInput("");
    setSearch("");
  };

  const filteredPackages = useMemo(() => {
    if (!search) return PACKAGES_DATA;
    const q = search.toLowerCase();
    return PACKAGES_DATA.filter(
      (p) =>
        p.destination.toLowerCase().includes(q) ||
        p.package_name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        (p.tag && p.tag.toLowerCase().includes(q)) ||
        p.highlights?.some((h) => h.toLowerCase().includes(q))
    );
  }, [search]);

  // ── Selected package (list view <-> detail view <-> booking overview) ──
  const [selectedId, setSelectedId] = useState(null);
  const selectedPackage = useMemo(
    () => PACKAGES_DATA.find((p) => p.id === selectedId) || null,
    [selectedId]
  );

  // "grid" | "detail" | "overview"
  // "overview" is the new in-between page shown after "Book Now" and
  // before hotel booking.
  const [stage, setStage] = useState("grid");

  const handleSelectPackage = (id) => {
    setSelectedId(id);
    setStage("detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBack = () => {
    setStage("grid");
    setSelectedId(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Passed down to PackageDetail — wire this to whatever "Book Now" /
  // pkg-cta-btn button already exists in PackageDetail.jsx so that it
  // calls this instead of navigating straight to /hotels.
  const handleBookNow = () => {
    setStage("overview");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBackToDetail = () => {
    setStage("detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Called when "Book Hotel" is clicked on the booking overview page.
  // Swap this for your real routing (react-router navigate, etc.) once
  // the hotel booking page/route exists.
  const handleBookHotel = () => {
    window.location.href = "/hotels";
  };

  return (
    <div className="pkg-root">
      <Packagesnavbar theme={theme} toggleTheme={toggleTheme} />

      {stage === "detail" && selectedPackage && (
        <PackageDetail
          pkg={selectedPackage}
          onBack={handleBack}
          onBookNow={handleBookNow}
        />
      )}

      {stage === "overview" && selectedPackage && (
        <BookingOverview
          pkg={selectedPackage}
          images={selectedPackage.gallery}
          onBack={handleBackToDetail}
          onBookHotel={handleBookHotel}
        />
      )}

      {stage === "grid" && (
        <>
          <Packageshero
            search={searchInput}
            onSearchChange={setSearchInput}
            onSearchSubmit={handleSearchSubmit}
          />

          <Packagesstats />

          <Packagesgrid
            packages={filteredPackages}
            search={search}
            onSelectChip={handleSelectChip}
            onClear={handleClear}
            onSelectPackage={handleSelectPackage}
          />

          <Packageswhyus />
        </>
      )}

      <Packagesfooter />
    </div>
  );
}