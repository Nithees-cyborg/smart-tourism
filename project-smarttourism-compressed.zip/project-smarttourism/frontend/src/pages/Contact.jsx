import { useEffect } from 'react';
import ContactNavbar from '../components/ContactNavbar';
import ContactHero from '../components/ContactHero';
import ContactFormSection from '../components/ContactFormSection';
import ContactEnquiry from '../components/ContactEnquiry';
import ContactGallery from '../components/ContactGallery';
import ContactMapFaq from '../components/ContactMapFaq';
import ContactFooter from '../components/ContactFooter';
import '../components/ContactPage.css';

export default function Contact() {
  useEffect(() => {
    const revealEls = document.querySelectorAll('.reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const siblings = [...entry.target.parentElement.querySelectorAll('.reveal:not(.visible)')];
          const idx = siblings.indexOf(entry.target);
          setTimeout(() => entry.target.classList.add('visible'), idx * 80);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealEls.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <ContactNavbar />
      <ContactHero />
      <ContactFormSection />
      <ContactEnquiry />
      <ContactGallery />
      <ContactMapFaq />
      <ContactFooter />
    </>
  );
}