import React, { useState, useMemo } from "react";
import { useParams, useLocation, useNavigate, Link } from "react-router-dom";
import HotelNavbar from "../components/HotelNavbar";
import HotelFooter from "../components/HotelFooter";
import HotelsData from "../components/HotelsData";

// Centralized Icon Assets
const ICONS = {
  check: "M4 12l5 5L20 6",
  close: "M6 6l12 12M18 6L6 18",
  star: "M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 16.9 6.4 20.1l1.4-6.3-4.8-4.3 6.4-.6L12 3Z",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21c0-4 3.6-7 8-7s8 3 8 7",
  users: "M9 12a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM17 12a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM2 20c0-3.3 3.1-6 7-6s7 2.7 7 6M14 14.5c3.4.3 6 2.7 6 5.5",
  calendar: "M4 8h16M7 3v4M17 3v4M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Z",
  map: "M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2Zm0 0v14m6-12v14",
  bed: "M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7M3 18v-2h18v2M3 16v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1M13 13a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1",
  shield: "M12 3l8 3v6c0 5-3.4 8.5-8 9-4.6-.5-8-4-8-9V6l8-3Z",
  back: "M15 6l-6 6 6 6",
  plane: "M12 3v7l7 4v2l-7-2-2 5H8l1-5-7 2v-2l7-4V5a2 2 0 0 1 4-2Z",
};

function Icon({ name, size = 18 }) {
  const d = ICONS[name] || ICONS.check;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

export default function HotelOverview() {
  const { hotelId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  // Find targeted hotel item data
  const hotel = useMemo(() => HotelsData.find((h) => h.id === hotelId), [hotelId]);

  // Fallback initial values if data structure routes safely
  const initialRoomId = location.state?.roomId || hotel?.rooms.find((r) => r.popular)?.id || hotel?.rooms[0]?.id;

  const [roomId, setRoomId] = useState(initialRoomId);
  const [guests, setGuests] = useState(location.state?.guests || 2);
  const [rooms, setRooms] = useState(1);

  // Synchronized state tracker for chosen room profile details
  const selectedRoom = useMemo(() => {
    if (!hotel) return null;
    return hotel.rooms.find((r) => r.id === roomId) || hotel.rooms[0];
  }, [hotel, roomId]);

  if (!hotel) {
    return (
      <>
        <HotelNavbar />
        <div className="ho-empty-state">
          <div className="ho-empty-card">
            <h2>Hotel Profile Not Found</h2>
            <p>The explicit destination link may have expired or changed.</p>
            <Link to="/hotels" className="ho-back-btn-primary">← Browse All Hotels</Link>
          </div>
        </div>
        <HotelFooter />
      </>
    );
  }

  // Cost and Invoice Calculations
  const roomTotal = selectedRoom ? selectedRoom.pricePerNight * hotel.nights * rooms : 0;
  const taxes = Math.round(roomTotal * 0.12);
  const grandTotal = roomTotal + taxes;

  // Selected hotel package to carry forward to Transports -> Overallview
  const hotelSelection = selectedRoom
    ? {
        id: hotel.id,
        name: hotel.name,
        location: hotel.location,
        image: hotel.images?.[0],
        roomName: selectedRoom.name,
        pricePerNight: selectedRoom.pricePerNight,
        nights: hotel.nights,
        roomsCount: rooms,
        guests,
        roomTotal,
        taxes,
        grandTotal,
      }
    : null;

  function goToFlights() {
    console.log("[HotelOverview] hotelSelection being sent:", hotelSelection);
    navigate("/transports", {
      state: {
        hotelId: hotel.id,
        destination: hotel.location,
        hotel: hotelSelection,
      },
    });
  }

  // Safe handler wrapper to ensure guest counts never violate room capacities
  const handleRoomChange = (id) => {
    const targetRoom = hotel.rooms.find((r) => r.id === id);
    setRoomId(id);
    if (targetRoom && guests > targetRoom.maxGuests) {
      setGuests(targetRoom.maxGuests);
    }
  };

  return (
    <>
      <HotelNavbar />

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Work+Sans:wght@300;400;500;600;700&display=swap');

        /* System Variables & Smooth Base Animations */
        .ho-wrap {
          --ink: #f8f6f0; 
          --navy: #0e1324; 
          --navy-deep: #060913; 
          --navy-soft: #141c36;
          --panel: rgba(248, 246, 240, 0.04); 
          --panel-hover: rgba(248, 246, 240, 0.07);
          --panel-active: rgba(227, 169, 74, 0.06);
          --gold: #e8b459; 
          --gold-hover: #f1c77a;
          --gold-soft: rgba(232, 180, 89, 0.15);
          --line: rgba(248, 246, 240, 0.1); 
          --btn-ink: #060913; 
          --muted: rgba(248, 246, 240, 0.65);
          --radius-lg: 16px;
          --radius-md: 10px;
          --transition: all 0.25s cubic-bezier(0.25, 0.46, 0.45, 0.94);

          font-family: 'Work Sans', -apple-system, sans-serif;
          color: var(--ink);
          background: linear-gradient(180deg, var(--navy-deep) 0%, var(--navy) 40%, var(--navy-soft) 100%);
          min-height: 100vh;
          padding: 40px 48px 96px;
          animation: hoFadeIn 0.5s ease-out;
        }

        @keyframes hoFadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Nav & Action Headings */
        .ho-back {
          display: inline-flex; align-items: center; gap: 8px; color: var(--muted); font-size: 14px;
          text-decoration: none; margin-bottom: 24px; cursor: pointer; background: none; border: none;
          padding: 6px 12px; border-radius: var(--radius-md); transition: var(--transition);
          margin-left: -12px;
        }
        .ho-back:hover { color: var(--gold); background: var(--panel); transform: translateX(-4px); }

        /* Hero Image Gallery Collage Layout */
        .ho-hero { 
          display: grid; grid-template-columns: 2.2fr 1fr; gap: 12px; 
          max-width: 1240px; margin: 0 auto 32px; border-radius: var(--radius-lg); 
          overflow: hidden; height: 420px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }
        .ho-hero-main { overflow: hidden; position: relative; }
        .ho-hero-main img, .ho-hero-side img { 
          width: 100%; height: 100%; object-fit: cover; display: block; 
          transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .ho-hero-main:hover img, .ho-hero-side-item:hover img { transform: scale(1.03); }
        .ho-hero-side { display: grid; grid-template-rows: 1fr 1fr; gap: 12px; }
        .ho-hero-side-item { overflow: hidden; position: relative; }

        /* Meta Descriptions */
        .ho-eyebrow { 
          display: inline-flex; align-items: center; gap: 8px; font-size: 11.5px; 
          letter-spacing: 0.15em; text-transform: uppercase; color: var(--gold); 
          font-weight: 700; margin-bottom: 12px; max-width: 1240px; 
        }
        .ho-title-row { 
          max-width: 1240px; margin: 0 auto; display: flex; 
          align-items: flex-start; justify-content: space-between; gap: 24px; flex-wrap: wrap; 
        }
        .ho-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: clamp(28px, 4vw, 42px); margin: 0 0 10px; letter-spacing: -0.01em; }
        .ho-location { font-size: 14.5px; color: var(--muted); display: flex; align-items: center; gap: 8px; margin: 0; }
        .ho-location svg { color: var(--gold); }
        .ho-rating-badge { 
          display: inline-flex; align-items: center; gap: 6px; background: var(--gold); 
          color: var(--btn-ink); padding: 8px 16px; border-radius: var(--radius-md); 
          font-weight: 700; font-size: 15px; box-shadow: 0 4px 14px rgba(232, 180, 89, 0.2);
        }

        /* Main Workspace Framework Splitter Grid */
        .ho-layout { max-width: 1240px; margin: 40px auto 0; display: grid; grid-template-columns: 1fr 380px; gap: 40px; align-items: start; }
        .ho-section { margin-bottom: 40px; background: rgba(248, 246, 240, 0.01); padding: 4px 0 24px; border-bottom: 1px solid var(--line); }
        .ho-section:last-of-type { border-bottom: none; }
        .ho-section-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: 22px; margin: 0 0 8px; letter-spacing: -0.005em; }
        .ho-section-sub { font-size: 13.5px; color: var(--muted); margin: 0 0 20px; }
        .ho-overview { font-size: 15px; line-height: 1.75; color: rgba(248, 246, 240, 0.85); text-align: justify; }

        /* Pill Badge Amenities */
        .ho-tags { display: flex; flex-wrap: wrap; gap: 10px; }
        .ho-tag { 
          background: var(--panel); border: 1px solid var(--line); color: rgba(248, 246, 240, 0.9); 
          padding: 8px 16px; border-radius: 100px; font-size: 13px; font-weight: 500; 
          display: inline-flex; align-items: center; gap: 8px; transition: var(--transition);
        }
        .ho-tag:hover { background: var(--panel-hover); border-color: rgba(248, 246, 240, 0.25); transform: translateY(-1px); }
        .ho-tag svg { color: var(--gold); }

        /* Room Selection Cards */
        .ho-rooms { display: flex; flex-direction: column; gap: 14px; }
        .ho-room-card { 
          display: grid; grid-template-columns: auto 1fr auto; gap: 20px; align-items: center; 
          background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius-lg); 
          padding: 20px; cursor: pointer; transition: var(--transition); position: relative;
        }
        .ho-room-card:hover { background: var(--panel-hover); border-color: rgba(248, 246, 240, 0.2); transform: translateY(-2px); }
        .ho-room-card.selected { border-color: var(--gold); background: var(--panel-active); box-shadow: 0 0 0 1px var(--gold-soft); }
        
        .ho-room-radio { width: 22px; height: 22px; border-radius: 50%; border: 2px solid var(--line); display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: var(--transition); }
        .ho-room-card.selected .ho-room-radio { border-color: var(--gold); }
        .ho-room-radio-dot { width: 12px; height: 12px; border-radius: 50%; background: var(--gold); opacity: 0; transform: scale(0.5); transition: var(--transition); }
        .ho-room-card.selected .ho-room-radio-dot { opacity: 1; transform: scale(1); }
        
        .ho-room-name { font-family: 'Fraunces', serif; font-weight: 600; font-size: 17px; color: #fff; }
        .ho-room-occupancy { font-size: 12.5px; color: var(--gold); display: inline-flex; align-items: center; gap: 6px; margin: 6px 0 8px; font-weight: 500; background: var(--gold-soft); padding: 2px 8px; border-radius: 4px; }
        .ho-room-desc { font-size: 13px; color: var(--muted); margin: 0; line-height: 1.5; }
        .ho-room-price-value { font-family: 'Fraunces', serif; font-size: 21px; font-weight: 600; color: var(--gold); display: block; text-align: right; }
        .ho-room-price-unit { display: block; font-size: 12px; color: var(--muted); text-align: right; margin-top: 2px; }

        /* Compare Matrix Lists */
        .ho-compare { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; }
        .ho-compare-title { font-size: 12.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
        .ho-compare-title.in { color: #50e3c2; }
        .ho-compare-title.out { color: rgba(248, 246, 240, 0.4); }
        .ho-compare-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 12px; }
        .ho-compare-list li { display: flex; gap: 10px; align-items: flex-start; font-size: 14px; line-height: 1.4; }
        .ho-compare-list.in li { color: rgba(248, 246, 240, 0.85); }
        .ho-compare-list.out li { color: rgba(248, 246, 240, 0.45); }
        .ho-compare-list.in svg { color: #50e3c2; margin-top: 2px; flex-shrink: 0; }
        .ho-compare-list.out svg { color: rgba(248, 246, 240, 0.3); margin-top: 2px; flex-shrink: 0; }

        /* Timeline Itinerary Structures */
        .ho-itinerary { display: flex; flex-direction: column; padding-top: 8px; }
        .ho-day { display: grid; grid-template-columns: 46px 1fr; gap: 18px; padding-bottom: 24px; position: relative; }
        .ho-day::before { content: ''; position: absolute; left: 23px; top: 40px; bottom: -4px; width: 2px; background: var(--line); }
        .ho-day:last-child::before { display: none; }
        .ho-day-num { 
          width: 44px; height: 44px; border-radius: 50%; background: var(--navy-deep); 
          border: 2px solid var(--gold); color: var(--gold); font-family: 'Fraunces', serif; 
          font-weight: 600; font-size: 14px; display: flex; align-items: center; 
          justify-content: center; flex-shrink: 0; z-index: 2; box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }
        .ho-day-title { font-weight: 600; font-size: 15.5px; margin: 4px 0 6px; color: #fff; }
        .ho-day-detail { font-size: 13.5px; color: var(--muted); margin: 0; line-height: 1.6; }

        /* Sidebar Interface Panel */
        .ho-sidebar { 
          position: sticky; top: 40px; background: rgba(248, 246, 240, 0.03); 
          backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
          border: 1px solid var(--line); border-radius: var(--radius-lg); 
          padding: 28px; display: flex; flex-direction: column; gap: 20px;
          box-shadow: 0 16px 32px rgba(0,0,0,0.25);
        }
        .ho-sidebar-title { font-family: 'Fraunces', serif; font-weight: 600; font-size: 19px; margin: 0; border-bottom: 1px solid var(--line); padding-bottom: 12px; }

        .ho-field { display: flex; flex-direction: column; gap: 8px; }
        .ho-field label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .ho-field select, .ho-field input {
          background: rgba(6, 9, 19, 0.4); border: 1px solid var(--line); color: var(--ink); border-radius: var(--radius-md);
          padding: 12px 14px; font-size: 14px; font-family: 'Work Sans', sans-serif; transition: var(--transition); outline: none;
        }
        .ho-field select:focus, .ho-field input:focus { border-color: var(--gold); background: rgba(6, 9, 19, 0.7); }

        /* Interactive Counter Adjusters */
        .ho-stepper { display: flex; align-items: center; justify-content: space-between; background: rgba(6, 9, 19, 0.4); border: 1px solid var(--line); border-radius: var(--radius-md); padding: 8px 10px; }
        .ho-stepper-btn { width: 32px; height: 32px; border-radius: 50%; border: 1px solid var(--line); background: transparent; color: var(--ink); font-size: 18px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: var(--transition); line-height: 1; }
        .ho-stepper-btn:hover { border-color: var(--gold); color: var(--gold); background: rgba(248, 246, 240, 0.05); }
        .ho-stepper-count { font-weight: 600; font-size: 15px; text-align: center; width: 40px; }

        /* Dynamic Invoice Statements */
        .ho-price-breakdown { border-top: 1px dashed var(--line); border-bottom: 1px dashed var(--line); padding: 16px 0; display: flex; flex-direction: column; gap: 12px; }
        .ho-price-row { display: flex; justify-content: space-between; font-size: 13.5px; color: var(--muted); align-items: flex-start; }
        .ho-price-row span { max-width: 70%; line-height: 1.4; }
        .ho-price-row strong { color: var(--ink); font-weight: 600; font-family: 'Work Sans', sans-serif; }
        .ho-price-row.total { font-size: 15px; margin-top: 4px; padding-top: 4px; }
        .ho-price-row.total span { color: #fff; font-weight: 600; }
        .ho-price-row.total strong { color: var(--gold); font-size: 20px; font-family: 'Fraunces', serif; }

        /* Primary Call-to-Actions */
        .ho-confirm-btn { 
          font-family: 'Work Sans', sans-serif; font-weight: 700; font-size: 15px; 
          color: var(--btn-ink); background: var(--gold); border: none; border-radius: var(--radius-md); 
          padding: 16px; cursor: pointer; width: 100%; transition: var(--transition); 
          box-shadow: 0 4px 15px rgba(232, 180, 89, 0.25);
        }
        .ho-confirm-btn:hover { background: var(--gold-hover); transform: translateY(-1.5px); box-shadow: 0 6px 20px rgba(232, 180, 89, 0.35); }
        .ho-confirm-btn:active { transform: translateY(0); }
        
        .ho-secure-note { font-size: 12px; color: var(--muted); text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 4px; }
        .ho-secure-note svg { color: #50e3c2; }

        /* Sidebar Back / Book Flights row (replaces the old checkout button) */
        .ho-sidebar-actions {
          display: flex; gap: 12px;
        }
        .ho-sidebar-actions .ho-bottom-btn {
          flex: 1; min-width: 0; padding: 14px 16px; font-size: 14px;
        }

        .ho-bottom-btn {
          display: inline-flex; align-items: center; justify-content: center; gap: 10px;
          font-family: 'Work Sans', sans-serif; font-weight: 700; font-size: 15px;
          padding: 15px 32px; border-radius: var(--radius-md); cursor: pointer;
          transition: var(--transition); border: 1px solid transparent; min-width: 220px;
        }
        .ho-bottom-btn.primary {
          background: var(--gold); color: var(--btn-ink);
          box-shadow: 0 4px 15px rgba(232, 180, 89, 0.25);
        }
        .ho-bottom-btn.primary:hover { background: var(--gold-hover); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(232, 180, 89, 0.35); }
        .ho-bottom-btn.secondary {
          background: var(--panel); color: var(--ink); border-color: var(--line);
        }
        .ho-bottom-btn.secondary:hover { background: var(--panel-hover); border-color: rgba(248,246,240,0.25); transform: translateY(-2px); }

        /* Blank Fallback States */
        .ho-empty-state { display: flex; align-items: center; justify-content: center; min-height: 70vh; background: var(--navy-deep); padding: 40px; }
        .ho-empty-card { background: var(--panel); border: 1px solid var(--line); padding: 48px 32px; border-radius: var(--radius-lg); text-align: center; max-width: 460px; width: 100%; }
        .ho-empty-card h2 { font-family: 'Fraunces', serif; font-size: 24px; margin: 0 0 12px; }
        .ho-empty-card p { color: var(--muted); font-size: 14.5px; margin: 0 0 28px; line-height: 1.5; }
        .ho-back-btn-primary { display: inline-block; background: var(--gold); color: var(--btn-ink); font-weight: 600; padding: 12px 24px; border-radius: var(--radius-md); text-decoration: none; font-size: 14px; transition: var(--transition); }
        .ho-back-btn-primary:hover { background: var(--gold-hover); transform: translateY(-1px); }

        /* Adaptive Responsive Breakpoints */
        @media (max-width: 1024px) {
          .ho-wrap { padding: 32px 24px 80px; }
          .ho-layout { grid-template-columns: 1fr; gap: 40px; }
          .ho-sidebar { position: static; max-width: 500px; width: 100%; margin: 0 auto; }
        }
        @media (max-width: 768px) {
          .ho-hero { grid-template-columns: 1fr; height: 280px; }
          .ho-hero-side { display: none; }
          .ho-compare { grid-template-columns: 1fr; gap: 24px; }
          .ho-room-card { grid-template-columns: auto 1fr; gap: 16px; }
          .ho-room-card > div:last-child { grid-column: 2; text-align: left; }
          .ho-room-price-value, .ho-room-price-unit { text-align: left; display: inline; }
          .ho-room-price-unit { margin-left: 6px; }
          .ho-sidebar-actions { flex-direction: column; }
          .ho-sidebar-actions .ho-bottom-btn { width: 100%; }
        }
      `}</style>

      <div className="ho-wrap">
        <button className="ho-back" onClick={() => navigate(-1)}>
          <Icon name="back" size={14} /> Back to Dashboard
        </button>

        <div className="ho-hero">
          <div className="ho-hero-main">
            <img src={hotel.images[0]} alt={hotel.name} />
          </div>
          <div className="ho-hero-side">
            <div className="ho-hero-side-item">
              <img src={hotel.images[1] || hotel.images[0]} alt={`${hotel.name} Interior view`} />
            </div>
            <div className="ho-hero-side-item">
              <img src={hotel.images[2] || hotel.images[0]} alt={`${hotel.name} Amenity view`} />
            </div>
          </div>
        </div>

        <span className="ho-eyebrow">{hotel.code} · Accommodation Summary</span>
        <div className="ho-title-row">
          <div>
            <h1 className="ho-title">{hotel.name}</h1>
            <p className="ho-location">
              <Icon name="map" size={14} /> {hotel.location} &bull; Feature venue in {hotel.packageName}
            </p>
          </div>
          <span className="ho-rating-badge">
            <Icon name="star" size={14} /> {hotel.rating}
          </span>
        </div>

        <div className="ho-layout">
          {/* Main Informational Column */}
          <div>
            <div className="ho-section">
              <h3 className="ho-section-title">Property Overview</h3>
              <p className="ho-overview">{hotel.overview}</p>
              {hotel.amenities?.length > 0 && (
                <div className="ho-tags" style={{ marginTop: 20 }}>
                  {hotel.amenities.map((item) => (
                    <span className="ho-tag" key={item}>
                      <Icon name="star" size={12} /> {item}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="ho-section">
              <h3 className="ho-section-title">Select Tier Category</h3>
              <p className="ho-section-sub">Adjusted allocations available for singles, couples, and premium suites.</p>
              <div className="ho-rooms">
                {hotel.rooms.map((room) => (
                  <div
                    key={room.id}
                    className={`ho-room-card ${roomId === room.id ? "selected" : ""}`}
                    onClick={() => handleRoomChange(room.id)}
                  >
                    <span className="ho-room-radio">
                      <span className="ho-room-radio-dot" />
                    </span>
                    <div>
                      <span className="ho-room-name">{room.name}</span>
                      <div>
                        <span className="ho-room-occupancy">
                          <Icon name={room.maxGuests === 1 ? "user" : "users"} size={12} />
                          Accommodates up to {room.maxGuests} {room.maxGuests === 1 ? "guest" : "guests"}
                        </span>
                      </div>
                      <p className="ho-room-desc">{room.description}</p>
                    </div>
                    <div>
                      <span className="ho-room-price-value">₹{room.pricePerNight.toLocaleString("en-IN")}</span>
                      <span className="ho-room-price-unit">/ night</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="ho-section">
              <h3 className="ho-section-title">Curated Itinerary Segment</h3>
              <p className="ho-section-sub">Expedition schedule designed around your check-in timeline.</p>
              <div className="ho-itinerary">
                {hotel.itinerary.map((d) => (
                  <div className="ho-day" key={d.day}>
                    <div className="ho-day-num">{String(d.day).padStart(2, "0")}</div>
                    <div>
                      <p className="ho-day-title">{d.title}</p>
                      <p className="ho-day-detail">{d.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="ho-section">
              <h3 className="ho-section-title">Coverage Checklists</h3>
              <div className="ho-compare">
                <div>
                  <div className="ho-compare-title in"><Icon name="check" size={13} /> Complimentary Inclusions</div>
                  <ul className="ho-compare-list in">
                    {hotel.inclusions.map((item) => (
                      <li key={item}><Icon name="check" size={14} /> {item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="ho-compare-title out"><Icon name="close" size={13} /> Excluded Fees & Add-ons</div>
                  <ul className="ho-compare-list out">
                    {hotel.exclusions.map((item) => (
                      <li key={item}><Icon name="close" size={14} /> {item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Calculation Sticky Sidebar */}
          <aside className="ho-sidebar">
            <h3 className="ho-sidebar-title">Reservation Control</h3>

            <div className="ho-field">
              <label><Icon name="bed" size={12} /> Assigned Room Profile</label>
              <select value={roomId} onChange={(e) => handleRoomChange(e.target.value)}>
                {hotel.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} — ₹{r.pricePerNight.toLocaleString("en-IN")}
                  </option>
                ))}
              </select>
            </div>

            <div className="ho-field">
              <label><Icon name="users" size={12} /> Total Checked Guests</label>
              <div className="ho-stepper">
                <button className="ho-stepper-btn" onClick={() => setGuests((g) => Math.max(1, g - 1))}>−</button>
                <span className="ho-stepper-count">{guests}</span>
                <button 
                  className="ho-stepper-btn" 
                  onClick={() => setGuests((g) => Math.min(selectedRoom?.maxGuests || 1, g + 1))}
                >
                  +
                </button>
              </div>
            </div>

            <div className="ho-field">
              <label><Icon name="bed" size={12} /> Quantity of Rooms Needed</label>
              <div className="ho-stepper">
                <button className="ho-stepper-btn" onClick={() => setRooms((r) => Math.max(1, r - 1))}>−</button>
                <span className="ho-stepper-count">{rooms}</span>
                <button className="ho-stepper-btn" onClick={() => setRooms((r) => r + 1)}>+</button>
              </div>
            </div>

            <div className="ho-field">
              <label><Icon name="calendar" size={12} /> Total Trip Duration</label>
              <input value={`${hotel.nights} Nights Stay`} disabled />
            </div>

            <div className="ho-price-breakdown">
              <div className="ho-price-row">
                <span>Base Total (₹{(selectedRoom?.pricePerNight || 0).toLocaleString("en-IN")} &times; {hotel.nights} nights &times; {rooms} room)</span>
                <strong>₹{roomTotal.toLocaleString("en-IN")}</strong>
              </div>
              <div className="ho-price-row">
                <span>Integrated Regulatory GST & Service Fees (12%)</span>
                <strong>₹{taxes.toLocaleString("en-IN")}</strong>
              </div>
              <div className="ho-price-row total">
                <span>Grand Aggregate Balance</span>
                <strong>₹{grandTotal.toLocaleString("en-IN")}</strong>
              </div>
            </div>

            <div className="ho-checkout-section">
              <div className="ho-sidebar-actions">
                <button className="ho-bottom-btn secondary" onClick={() => navigate(-1)}>
                  <Icon name="back" size={16} /> Back
                </button>
                <button className="ho-bottom-btn primary" onClick={goToFlights}>
                  <Icon name="plane" size={16} /> Book Transports
                </button>
              </div>
              <span className="ho-secure-note">
                <Icon name="shield" size={13} /> Encrypted Gateway &bull; Flex Cancel Policy
              </span>
            </div>
          </aside>
        </div>
      </div>

      <HotelFooter />
    </>
  );
}
