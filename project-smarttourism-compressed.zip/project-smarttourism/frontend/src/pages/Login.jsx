import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import Loginbackground from "../components/Loginbackground";
import Logincard from "../components/Logincard";
import "../components/Login.css";

export default function Login() {
  const navigate = useNavigate();

  const [darkMode, setDarkMode] = useState(false);
  const [errors, setErrors] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [toast, setToast] = useState({
    show: false,
    message: "",
    isError: false,
  });

  useEffect(() => {
    if (!toast.show) return;

    const timer = setTimeout(() => {
      setToast((prev) => ({ ...prev, show: false }));
    }, 3000);

    return () => clearTimeout(timer);
  }, [toast.show]);

  const showToast = (message, isError = false) => {
    setToast({
      show: true,
      message,
      isError,
    });
  };

  const handleSubmit = async (e, { username, password }) => {
    e.preventDefault();

    setErrors([]);

    if (!username || !password) {
      showToast("Please enter username and password.", true);
      return;
    }

    setIsSubmitting(true);

    try {
      console.log("Sending Login Request...");

      // Uses the shared `api` instance (src/api.js) instead of raw axios.
      // That instance already sets withCredentials, a relative baseURL
      // ("/api/") that goes through the Vite proxy, and — critically —
      // an interceptor that attaches the X-CSRFToken header from the
      // csrftoken cookie on every unsafe request. Calling plain axios.post
      // here skipped all of that, which is what was causing the 403.
      const response = await api.post("login/", {
        username,
        password,
      });

      console.log("Django Response:", response.data);

      if (response.data.success) {
        showToast("Login Successful");

        localStorage.setItem("username", response.data.username);

        setTimeout(() => {
          navigate("/dashboard");
        }, 1000);
      } else {
        setErrors([response.data.message]);
        showToast(response.data.message, true);
      }
    } catch (error) {
      console.log("FULL ERROR", error);

      if (error.response) {
        console.log("Status:", error.response.status);
        console.log("Data:", error.response.data);
      }

      showToast("Login Failed", true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={`login-root ${darkMode ? "dark-mode" : ""}`}>
      <Loginbackground />

      <div
        className={`toast ${toast.show ? "show" : ""} ${
          toast.isError ? "error" : ""
        }`}
      >
        {toast.message}
      </div>

      <Logincard
        darkMode={darkMode}
        onToggleTheme={() => setDarkMode(!darkMode)}
        errors={errors}
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
      />
    </div>
  );
}