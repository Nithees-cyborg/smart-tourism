import React from "react";
import SettingsNavbar from "../components/SettingsNavbar";
import SettingsSections from "../components/SettingsSections";
import "../components/Settings.css";

export default function Settings() {
  return (
    <div className="settings-page">
      <SettingsNavbar />
      <SettingsSections />
    </div>
  );
}