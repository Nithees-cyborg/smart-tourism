import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import Hero, { TrustBar, OfferBand } from "../components/Hero";
import { DestinationsSection, HowItWorks, ToursSection, Marquee } from "../components/DestinationsAndTours";
import { WhyUs, InspirationSection } from "../components/WhyUsAndInspiration";
import { Testimonials, FAQ, Newsletter } from "../components/TestimonialsFAQNewsletter";
import { Footer, ScrollProgress, ToTopBtn } from "../components/Footer";
import { useReveal, useTiltCards } from "../components/helpers";
import "../components/Global.css";

export default function Home() {
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });

  const [searchState, setSearchState] = useState({ dest: "", dur: "", type: "" });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  const handleSearch = () => {
    let url = "/packages?";
    if (searchState.dest) url += "search=" + encodeURIComponent(searchState.dest) + "&";
    if (searchState.dur)  url += "duration=" + encodeURIComponent(searchState.dur) + "&";
    if (searchState.type) url += "type=" + encodeURIComponent(searchState.type);
    window.location.href = url;
  };

  useReveal();
  useTiltCards();

  return (
    <>
      <ScrollProgress />
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      <Hero searchState={searchState} setSearchState={setSearchState} onSearch={handleSearch} />
      <TrustBar />
      <OfferBand />
      <DestinationsSection />
      <HowItWorks />
      <ToursSection />
      <Marquee />
      <WhyUs />
      <InspirationSection />
      <Testimonials />
      <FAQ />
      <Newsletter />
      <Footer />
      <ToTopBtn />
      <a href="/contact" className="chat-bubble" aria-label="Chat with us">
        <i className="fa-solid fa-comment-dots"></i>
      </a>
    </>
  );
}