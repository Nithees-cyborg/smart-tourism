import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import Signupbackground from "../components/Signupbackground";
import Signupheader from "../components/Signupheader";
import Signupcard from "../components/Signupcard";
import Signupform from "../components/Signupform";
import Signupsocial from "../components/Signupsocial";
import Signupfooter from "../components/Signupfooter";

import "../components/Signup.css";

export default function Signup() {
  const navigate = useNavigate();

  const [step, setStep] = useState(1);

  const [toast, setToast] = useState({
    show: false,
    msg: "",
    ok: true,
  });

  const showToast = (msg, ok = true) => {
    setToast({
      show: true,
      msg,
      ok,
    });

    setTimeout(() => {
      setToast((prev) => ({
        ...prev,
        show: false,
      }));
    }, 3000);
  };

  return (
    <Signupbackground>
      <div
        className={`toast ${toast.show ? "show" : ""}`}
        style={{
          background: toast.ok ? "#003366" : "#dc2626",
        }}
      >
        {toast.msg}
      </div>

      <Signupcard>
        <Signupheader step={step} />

        <Signupform
          step={step}
          setStep={setStep}
          showToast={showToast}
          navigate={navigate}
        />

        <Signupsocial />

        <Signupfooter />
      </Signupcard>
    </Signupbackground>
  );
}