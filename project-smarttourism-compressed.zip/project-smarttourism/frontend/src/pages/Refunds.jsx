import React from "react";
import "../components/Refunds.css";

// Place logo.png and refund.jpg inside your project's /public folder
// (e.g. frontend/public/logo.png, frontend/public/refund.jpg).
// Referencing them as plain string paths (not imports) means Vite
// won't fail the build even if the files aren't there yet.
const logo = "/logo.png";
const refundImg = "/refund.jpg";

const steps = [
  {
    title: "Locate your booking",
    desc: "Sign in to your Global Smart Tourism account and open “My Bookings.” Select the trip or service you'd like refunded.",
  },
  {
    title: "Submit a refund request",
    desc: "Click “Request Refund” on the booking details page, choose a reason, and add any supporting notes or documents.",
  },
  {
    title: "Verification",
    desc: "Our support team reviews your request against the refund policy and booking terms, typically within 2–3 business days.",
  },
  {
    title: "Confirmation & payout",
    desc: "Once approved, you'll receive an email confirmation. Funds are returned to your original payment method within 5–10 business days.",
  },
];

const policy = [
  {
    title: "Eligibility Window",
    body: "Refund requests must be submitted within 14 days of the original booking date, or before the service/trip start date, whichever comes first.",
  },
  {
    title: "Cancellation Charges",
    list: [
      "Cancelled 7+ days before travel: full refund minus a 5% processing fee.",
      "Cancelled 3–6 days before travel: 50% refund of the booking value.",
      "Cancelled within 48 hours of travel: non-refundable, unless due to a covered emergency.",
    ],
  },
  {
    title: "Non-Refundable Items",
    body: "Special-rate promotional packages, visa processing fees, and third-party partner charges marked “non-refundable” at checkout are excluded from this policy.",
  },
  {
    title: "Service Issues",
    body: "If a booked service was not delivered as described (cancelled tour, unavailable accommodation, etc.), you are entitled to a full refund regardless of the cancellation window.",
  },
  {
    title: "Payment Method",
    body: "Refunds are issued to the original payment method only. Processing times vary by bank or payment provider, typically 5–10 business days.",
  },
  {
    title: "Disputes",
    body: "If you disagree with a refund decision, you may escalate the case to our support team for a secondary review within 30 days of the original decision.",
  },
];

export default function Refunds() {
  return (
    <div className="refunds-page">
      <nav className="refunds-navbar">
        <div className="refunds-nav-left">
          <img src={logo} alt="Global Smart Tourism logo" className="refunds-logo" />
          <span className="refunds-brand">Global Smart Tourism</span>
        </div>
        <div className="refunds-nav-right">
          <ul className="refunds-nav-links">
            <li><a href="#how-to">How to Refund</a></li>
            <li><a href="#policy">Refund Policy</a></li>
          </ul>
          <button
            type="button"
            className="refunds-back-btn"
            onClick={() => window.history.back()}
            aria-label="Go back to previous page"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Back
          </button>
        </div>
      </nav>

      <section className="refunds-hero">
        <div className="refunds-hero-inner">
          <div className="refunds-hero-text">
            <div className="refunds-eyebrow">Customer Care</div>
            <h1>Refunds, made simple and transparent.</h1>
            <p>Plans change. If your booking with Global Smart Tourism didn't work out, here's exactly how to request a refund and what to expect at every step.</p>
          </div>
          <div className="refunds-hero-img-wrap">
            <img src={refundImg} alt="Refund process illustration" />
          </div>
        </div>
      </section>

      <main className="refunds-content">
        <div id="how-to">
          <div className="refunds-section-title">
            <span className="refunds-tag">Step by step</span>
            <h2>How to Request a Refund</h2>
          </div>

          <ol className="refunds-steps">
            {steps.map((step, i) => (
              <li className="refunds-step" key={step.title}>
                <span className="refunds-step-num">{i + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.desc}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div id="policy" className="refunds-policy-block">
          <div className="refunds-section-title">
            <span className="refunds-tag">Terms</span>
            <h2>Refund Policy</h2>
          </div>

          {policy.map((item) => (
            <div className="refunds-policy-item" key={item.title}>
              <h3>{item.title}</h3>
              {item.body && <p>{item.body}</p>}
              {item.list && (
                <ul>
                  {item.list.map((li) => (
                    <li key={li}>{li}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>

        <div className="refunds-callout">
          <div>
            <h3>Still need help?</h3>
            <p>Our support team is here for any questions about your refund.</p>
          </div>
          <button
            type="button"
            className="refunds-callout-btn"
            onClick={() => { window.location.href = "mailto:support@globalsmarttourism.com"; }}
          >
            Contact Support
          </button>
        </div>
      </main>

      <footer className="refunds-footer">
        &copy; 2026 Global Smart Tourism. All rights reserved.
      </footer>
    </div>
  );
}