import React, { useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import "../components/RegisterBooking.css";

function getCookie(name) {
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : null;
}

async function findBackendPackageId(pkg) {
  const res = await fetch("/api/packages/", { credentials: "include" });
  const packages = await res.json();
  const match = packages.find(
    (p) => p.package_name === pkg.package_name || p.destination === pkg.destination
  );
  if (!match) throw new Error("This package isn't in the backend yet.");
  return match.id;
}

function toNumber(price) {
  return Number(String(price).replace(/,/g, "")) || 0;
}

export default function RegisterBooking() {
  const { id } = useParams();
  const { state } = useLocation();
  const navigate = useNavigate();

  // Everything Overallview.jsx hands off: pkg, flight, hotel (optional), origin, date
  const pkg = state?.pkg || null;
  const flight = state?.flight || null;
  const hotel = state?.hotel || null;
  const origin = state?.origin || null;
  const date = state?.date || null;

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    city: "",
    country: "",
    checkIn: "",
    travellers: 1, // default: pricing always starts from a single traveller
  });

  const [errorMessage, setErrorMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === "travellers" ? Number(value) : value,
    }));
  };

  // ---- Live price breakdown -------------------------------------------
  // Package & flight fares are per-traveller costs, so they scale with the
  // "Travellers" field. Hotel cost is a fixed stay total (rooms x nights),
  // already computed on the hotel page, so it does not scale per head.
  const packagePricePerPerson = pkg ? toNumber(pkg.price) : 0;
  const flightPricePerPerson = flight ? flight.price : 0;
  const hotelTotal = hotel ? hotel.grandTotal : 0;

  const perPersonSubtotal = packagePricePerPerson + flightPricePerPerson;
  const travellers = Math.max(1, Number(formData.travellers) || 1);
  const travellersSubtotal = perPersonSubtotal * travellers;
  const grandTotal = travellersSubtotal + hotelTotal;

  const heroImage =
    hotel?.image || pkg?.image || "https://images.unsplash.com/photo-1501785888041-af3ef285b470";

  const handleConfirm = async (e) => {
    e.preventDefault();
    setErrorMessage("");

    if (!formData.fullName || !formData.email || !formData.phone || !formData.checkIn) {
      alert("Please fill all required fields.");
      return;
    }

    if (!pkg) {
      setErrorMessage("Package data is missing — please start again from the packages page.");
      return;
    }

    setSubmitting(true);

    try {
      // Make sure the csrftoken cookie actually exists before we try to read
      // it below. If the user landed straight on this page (no prior visit
      // to an endpoint that sets the cookie), getCookie("csrftoken") would
      // return null and Django's CSRF middleware would 403 the POST.
      await fetch("/api/csrf/", { credentials: "include" });

      const packageId = await findBackendPackageId(pkg);

      const res = await fetch("/api/bookings/", {
        method: "POST",
        credentials: "include", // sends the session cookie
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"), // required by Django's CSRF middleware
        },
        body: JSON.stringify({
          package_id: packageId,
          travel_date: formData.checkIn,
          persons: travellers,
          full_name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          city: formData.city,
          country: formData.country,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setErrorMessage(data.message || "Could not create the booking. Please try again.");
        setSubmitting(false);
        return;
      }

      navigate("/payments", {
        state: {
          pkg,
          flight,
          hotel,
          origin,
          date,
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          city: formData.city,
          country: formData.country,
          checkIn: formData.checkIn,
          travellers,
          packagePricePerPerson,
          flightPricePerPerson,
          hotelTotal,
          travellersSubtotal,
          grandTotal,
          bookingId: data.booking.id, // real DB row id, useful on the Payments page
        },
      });
    } catch (err) {
      setErrorMessage(err.message || "Something went wrong. Please try again.");
      setSubmitting(false);
    }
  };

  if (!pkg) {
    return (
      <div className="rb-empty">
        <p>No package selected. Please go back and choose a package.</p>
        <button onClick={() => navigate("/packages")} className="rb-back-btn">
          <i className="fa-solid fa-arrow-left"></i> Back to Packages
        </button>
      </div>
    );
  }

  return (
    <div className="rb-page">
      {/* LEFT: Hero */}
      <div className="rb-hero" style={{ backgroundImage: `url(${heroImage})` }}>
        <div className="rb-hero-overlay"></div>

        <div className="rb-hero-top">
          <span className="rb-secure-badge">
            <i className="fa-solid fa-shield-halved"></i> SECURE BOOKING
          </span>
        </div>

        <div className="rb-hero-content">
          <p className="rb-hero-location">
            <i className="fa-solid fa-location-dot"></i> {pkg.destination}
          </p>
          <h1 className="rb-hero-title">{pkg.package_name}</h1>

          <div className="rb-hero-meta">
            <span>
              <i className="fa-solid fa-star"></i> {pkg.rating} · {pkg.duration}
            </span>
            {hotel && (
              <span>
                <i className="fa-solid fa-bed"></i> {hotel.name}
              </span>
            )}
            {flight && (
              <span>
                <i className="fa-solid fa-plane"></i> {flight.airline}
              </span>
            )}
          </div>

          {/* Trip components list */}
          <div className="rb-item-list">
            <div className="rb-item-row">
              <span className="rb-item-name">
                <i className="fa-solid fa-suitcase-rolling"></i> Package ({pkg.duration})
              </span>
              <span className="rb-item-price">
                ₹{packagePricePerPerson.toLocaleString("en-IN")}
                <span className="rb-item-unit">/traveller</span>
              </span>
            </div>

            <div className="rb-item-row">
              <span className="rb-item-name">
                <i className="fa-solid fa-plane"></i>{" "}
                {flight ? `${flight.airline} · ${flight.flightNumber}` : "Flight"}
              </span>
              <span className="rb-item-price">
                {flight ? (
                  <>
                    ₹{flightPricePerPerson.toLocaleString("en-IN")}
                    <span className="rb-item-unit">/traveller</span>
                  </>
                ) : (
                  "—"
                )}
              </span>
            </div>

            <div className="rb-item-row">
              <span className="rb-item-name">
                <i className="fa-solid fa-bed"></i>{" "}
                {hotel ? `${hotel.name} · ${hotel.roomName}` : "Hotel"}
              </span>
              <span className="rb-item-price">
                {hotel ? (
                  <>
                    ₹{hotelTotal.toLocaleString("en-IN")}
                    <span className="rb-item-unit">fixed</span>
                  </>
                ) : (
                  "—"
                )}
              </span>
            </div>
          </div>

          {/* Live traveller-scaled price card */}
          <div className="rb-price-card">
            <span className="rb-price-label">
              PRICE FOR {travellers} {travellers === 1 ? "TRAVELLER" : "TRAVELLERS"}
            </span>
            <div className="rb-price-value">
              ₹{grandTotal.toLocaleString("en-IN")}
              <span className="rb-price-unit">total</span>
            </div>

            <div className="rb-price-breakdown">
              <div className="rb-price-breakdown-row">
                <span>
                  Package + Flight (₹{perPersonSubtotal.toLocaleString("en-IN")} × {travellers})
                </span>
                <span>₹{travellersSubtotal.toLocaleString("en-IN")}</span>
              </div>
              {hotel && (
                <div className="rb-price-breakdown-row">
                  <span>Hotel (fixed)</span>
                  <span>₹{hotelTotal.toLocaleString("en-IN")}</span>
                </div>
              )}
            </div>

            <span className="rb-price-tag">
              <i className="fa-solid fa-tag"></i> Updates as you change travellers
            </span>
          </div>
        </div>
      </div>

      {/* RIGHT: Form */}
      <div className="rb-form-panel">
        <div className="rb-steps">
          <div className="rb-step active">
            <span className="rb-step-icon">
              <i className="fa-solid fa-user"></i>
            </span>
            Your Details
          </div>
          <div className="rb-step">
            <span className="rb-step-icon">
              <i className="fa-solid fa-map"></i>
            </span>
            Travel Plan
          </div>
          <div className="rb-step">
            <span className="rb-step-icon">
              <i className="fa-solid fa-credit-card"></i>
            </span>
            Payment
          </div>
        </div>

        <p className="rb-quick-tag">
          <i className="fa-solid fa-bolt"></i> QUICK BOOKING
        </p>
        <h2 className="rb-form-heading">Confirm Your Stay</h2>
        <p className="rb-form-sub">
          Fill in your details below — takes less than 2 minutes. Our team confirms within 24
          hours.
        </p>

        {errorMessage && (
          <p style={{ color: "#dc2626", fontSize: "13px", marginBottom: "10px" }}>
            {errorMessage}
          </p>
        )}

        <form onSubmit={handleConfirm} className="rb-form">
          <p className="rb-section-label">PERSONAL INFORMATION</p>

          <div className="rb-row">
            <div className="rb-field">
              <label>
                <i className="fa-solid fa-user"></i> FULL NAME
              </label>
              <input
                type="text"
                name="fullName"
                placeholder="Enter Your Name"
                value={formData.fullName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="rb-field">
              <label>
                <i className="fa-solid fa-envelope"></i> EMAIL
              </label>
              <input
                type="email"
                name="email"
                placeholder="Enter Your Email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="rb-row">
            <div className="rb-field">
              <label>
                <i className="fa-solid fa-phone"></i> PHONE NUMBER
              </label>
              <input
                type="tel"
                name="phone"
                placeholder="Enter Your Number"
                value={formData.phone}
                onChange={handleChange}
                required
              />
            </div>

            <div className="rb-field">
              <label>
                <i className="fa-solid fa-building"></i> CITY
              </label>
              <input
                type="text"
                name="city"
                placeholder="City Name"
                value={formData.city}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="rb-field">
            <label>
              <i className="fa-solid fa-flag"></i> COUNTRY
            </label>
            <input
              type="text"
              name="country"
              placeholder="Country Name"
              value={formData.country}
              onChange={handleChange}
              required
            />
          </div>

          <p className="rb-section-label">TRAVEL DETAILS</p>

          <div className="rb-row">
            <div className="rb-field">
              <label>
                <i className="fa-solid fa-calendar"></i> CHECK-IN DATE
              </label>
              <input
                type="date"
                name="checkIn"
                value={formData.checkIn}
                onChange={handleChange}
                required
              />
            </div>

            <div className="rb-field">
              <label>
                <i className="fa-solid fa-users"></i> TRAVELLERS
              </label>
              <select
                name="travellers"
                value={formData.travellers}
                onChange={handleChange}
                required
              >
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n}>
                    {n} {n === 1 ? "Person" : "People"}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Compact live total, mirrors the hero card, visible near the submit button too */}
          <div className="rb-form-total-row">
            <span>
              Total for {travellers} {travellers === 1 ? "traveller" : "travellers"}
            </span>
            <span className="rb-form-total-value">₹{grandTotal.toLocaleString("en-IN")}</span>
          </div>

          <button type="submit" className="rb-confirm-btn" disabled={submitting}>
            {submitting ? "Booking..." : "Confirm & Proceed to Payment"}
            <i className="fa-solid fa-arrow-right"></i>
          </button>
        </form>
      </div>
    </div>
  );
}