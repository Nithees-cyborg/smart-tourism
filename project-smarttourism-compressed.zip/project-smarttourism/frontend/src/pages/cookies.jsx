import React from "react";
import "../components/cookies.css";

import CookiesNavbar from "../components/cookiesnavbar";
import CookiesHero from "../components/cookieshero";
import CookiesInfo from "../components/cookiesinfo";
import CookiesCards from "../components/cookiescards";
import CookiesTable from "../components/cookiestable";
import CookiesFooter from "../components/cookiesfooter";
import CookiesBanner from "../components/cookiesbanner";
import CookiesModal from "../components/cookiesmodal";
import useCookieConsent from "../components/usecookieconsent";

export default function Cookies() {
  const {
    consent,
    bannerVisible,
    floatBtnVisible,
    modalOpen,
    openModal,
    closeModal,
    acceptAllCookies,
    rejectAllCookies,
    savePreferences,
  } = useCookieConsent();

  return (
    <div className="cookies-page">
      <CookiesNavbar />

      <CookiesHero onManagePreferences={openModal} />

      <div className="page-container">
        <CookiesInfo />
        <CookiesCards consent={consent} />
        <CookiesTable onManagePreferences={openModal} />
      </div>

      <CookiesFooter onManagePreferences={openModal} />

      <CookiesBanner
        bannerVisible={bannerVisible}
        floatBtnVisible={floatBtnVisible}
        onManagePreferences={openModal}
        onRejectAll={rejectAllCookies}
        onAcceptAll={acceptAllCookies}
      />

      <CookiesModal
        modalOpen={modalOpen}
        consent={consent}
        onClose={closeModal}
        onAcceptAll={acceptAllCookies}
        onRejectAll={rejectAllCookies}
        onSave={savePreferences}
      />
    </div>
  );
}
