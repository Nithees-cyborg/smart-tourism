import React, { useRef, useState } from "react";
import { useLocation, useNavigate, Navigate } from "react-router-dom";
import "../components/Invoice.css";
import logo from "/logo.png"; // same path used in SuccessNavbar

// Point this at your backend's invoice-email endpoint.
const EMAIL_INVOICE_ENDPOINT = "/api/invoice/send-email";

export default function Invoice() {
  const location = useLocation();
  const navigate = useNavigate();
  const booking = location.state?.booking;
  const payment = location.state?.payment; // may be undefined — that's OK now
  const printRef = useRef(null);

  // "idle" | "sending" | "sent" | "error"
  const [emailStatus, setEmailStatus] = useState("idle");

  // Only bail out if we have NO booking at all — a missing/incomplete
  // payment is a valid state to render (shows "Payment Pending" instead).
  if (!booking) {
    return <Navigate to="/" replace />;
  }

  // Build a safe "payment" object even if none was passed in, so the rest
  // of the JSX below doesn't need dozens of payment?.field checks.
  const displayPayment = payment || {
    status: "Pending",
    payment_method: "—",
    payment_date: "—",
    amount: booking.total_amount,
  };

  const isPaid = displayPayment.status === "Completed" || displayPayment.status === "Paid";

  const handleDownload = () => {
    window.print();
  };

  const handleEmailInvoice = async () => {
    setEmailStatus("sending");
    try {
      const res = await fetch(EMAIL_INVOICE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: booking.customer.email,
          bookingId: booking.id,
          booking,
          payment: displayPayment,
        }),
      });

      if (!res.ok) throw new Error("Request failed");
      setEmailStatus("sent");
    } catch (err) {
      console.error("Failed to email invoice:", err);
      setEmailStatus("error");
    }
  };

  const today = new Date().toLocaleDateString("en-IN", {
    day: "2-digit", month: "short", year: "numeric",
  });

  return (
    <div className="invoice-page">
      <div className="invoice-controls no-print">
        <button className="btn-back" onClick={() => navigate(-1)}>
          ← Back to Confirmation
        </button>
        <button className="btn-download" onClick={handleDownload}>
          ⬇ Download Invoice (PDF)
        </button>
        <button
          className="btn-email"
          onClick={handleEmailInvoice}
          disabled={emailStatus === "sending"}
        >
          {emailStatus === "sending" ? "Sending…" : "✉ Email Invoice"}
        </button>
        {emailStatus === "sent" && (
          <span className="email-status email-status-success">
            Sent to {booking.customer.email}
          </span>
        )}
        {emailStatus === "error" && (
          <span className="email-status email-status-error">
            Couldn't send invoice. Please try again.
          </span>
        )}
      </div>

      {!isPaid && (
        <div className="invoice-pending-banner no-print">
          Payment for this booking hasn't been completed yet. You can still
          view and download this invoice — it will update automatically
          once payment is confirmed.
        </div>
      )}

      <div className="invoice-sheet" ref={printRef}>
        <div className="invoice-header">
          <div className="invoice-brand">
            <img src={logo} alt="Global Smart Tourism" className="invoice-logo" />
            <div>
              <h1>Global Smart Tourism</h1>
              <p>Travel & Tour Booking Services</p>
            </div>
          </div>
          <div className="invoice-meta">
            <h2>INVOICE</h2>
            <div className="meta-row"><span>Invoice No.</span><b>#GST-{booking.id}</b></div>
            <div className="meta-row"><span>Date Issued</span><b>{today}</b></div>
            <div className="meta-row">
              <span>Status</span>
              <b className={isPaid ? "badge-paid" : "badge-pending"}>
                {displayPayment.status}
              </b>
            </div>
          </div>
        </div>

        <hr />

        <div className="invoice-grid">
          <div>
            <h3>Billed To</h3>
            <p><b>{booking.customer.full_name}</b></p>
            <p>{booking.customer.email}</p>
            <p>{booking.customer.phone}</p>
            <p>{booking.customer.city}, {booking.customer.country}</p>
          </div>
          <div>
            <h3>Booking Details</h3>
            <p><b>Reference:</b> #GST-{booking.id}</p>
            <p><b>Travel Date:</b> {booking.travel_date}</p>
            <p><b>Persons:</b> {booking.persons}</p>
            <p><b>Booking Status:</b> {booking.status}</p>
          </div>
        </div>

        <table className="invoice-table">
          <thead>
            <tr>
              <th>Description</th>
              <th>Destination</th>
              <th>Duration</th>
              <th>Persons</th>
              <th>Price / Person</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{booking.package.package_name}</td>
              <td>{booking.package.destination}</td>
              <td>{booking.package.duration}</td>
              <td>{booking.persons}</td>
              <td>₹ {booking.package.price}</td>
              <td>₹ {booking.total_amount}</td>
            </tr>
          </tbody>
        </table>

        <div className="invoice-totals">
          <div className="total-line"><span>Subtotal</span><span>₹ {booking.total_amount}</span></div>
          <div className="total-line grand">
            <span>{isPaid ? "Total Paid" : "Amount Due"}</span>
            <span>₹ {displayPayment.amount}</span>
          </div>
        </div>

        <hr />

        <div className="invoice-grid">
          <div>
            <h3>Payment Details</h3>
            <p><b>Method:</b> {displayPayment.payment_method}</p>
            <p><b>Payment Date:</b> {displayPayment.payment_date}</p>
            <p><b>Amount {isPaid ? "Paid" : "Due"}:</b> ₹ {displayPayment.amount}</p>
            <p>
              <b>Status:</b>{" "}
              <span className={isPaid ? "badge-paid" : "badge-pending"}>
                {displayPayment.status}
              </span>
            </p>
          </div>
          <div>
            <h3>Package Description</h3>
            <p className="muted">{booking.package.description}</p>
          </div>
        </div>

        <hr />

        <p className="invoice-footer-note">
          This is a system-generated invoice for your booking with Global Smart Tourism.
          For queries, contact support@globaltourism.com or call +91 98765 00000.
        </p>
      </div>
    </div>
  );
}