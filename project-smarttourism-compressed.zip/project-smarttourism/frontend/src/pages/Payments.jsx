import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../components/RegisterBooking.css";

const PAYMENT_METHODS = [
  { id: "card", label: "Card", icon: "fa-solid fa-credit-card" },
  { id: "upi", label: "UPI", icon: "fa-solid fa-mobile-screen" },
  { id: "netbanking", label: "Net Banking", icon: "fa-solid fa-building-columns" },
  { id: "wallet", label: "Wallet", icon: "fa-solid fa-wallet" },
];

const BANKS = [
  "State Bank of India",
  "HDFC Bank",
  "ICICI Bank",
  "Axis Bank",
  "Punjab National Bank",
  "Kotak Mahindra Bank",
];

export default function Payments() {
  const { state } = useLocation();
  const navigate = useNavigate();

  const [method, setMethod] = useState("card");

  const [cardData, setCardData] = useState({
    cardName: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
  });

  const [upiId, setUpiId] = useState("");
  const [bank, setBank] = useState("");
  const [walletProvider, setWalletProvider] = useState("paytm");
  const [walletPhone, setWalletPhone] = useState("");

  const [isPaying, setIsPaying] = useState(false);
  const [payError, setPayError] = useState("");

  if (!state?.hotel) {
    return (
      <div className="rb-empty">
        <p>No booking details found. Please start your booking again.</p>
        <button onClick={() => navigate("/hotels")} className="rb-back-btn">
          <i className="fa-solid fa-arrow-left"></i> Back to Hotels
        </button>
      </div>
    );
  }

  // Pull EVERYTHING RegisterBooking.jsx already sent, including the real
  // computed total — do not recompute price from hotel.price (that field
  // doesn't exist; RegisterBooking uses hotel.grandTotal, which is already
  // folded into grandTotal below).
  const {
    pkg,
    hotel,
    fullName,
    email,
    phone,
    checkIn,
    travellers,
    packagePricePerPerson = 0,
    flightPricePerPerson = 0,
    hotelTotal = 0,
    travellersSubtotal = 0,
    grandTotal = 0,
  } = state;

  const handleCardChange = (e) => {
    const { name, value } = e.target;
    setCardData((prev) => ({ ...prev, [name]: value }));
  };

  const validatePaymentDetails = () => {
    if (method === "card") {
      if (!cardData.cardName || !cardData.cardNumber || !cardData.expiry || !cardData.cvv) {
        return "Please fill in all card details.";
      }
    } else if (method === "upi") {
      if (!upiId || !upiId.includes("@")) {
        return "Please enter a valid UPI ID (e.g. name@bank).";
      }
    } else if (method === "netbanking") {
      if (!bank) {
        return "Please select your bank.";
      }
    } else if (method === "wallet") {
      if (!walletPhone || walletPhone.length < 10) {
        return "Please enter a valid wallet-linked phone number.";
      }
    }
    return "";
  };

  // No backend calls here anymore. We validate the payment details
  // locally, build a mock booking/confirmation object from the data
  // already carried in route state, and go straight to the success page.
  const handlePay = (e) => {
    e.preventDefault();
    setPayError("");

    const validationError = validatePaymentDetails();
    if (validationError) {
      alert(validationError);
      return;
    }

    setIsPaying(true);

    // Use the real total handed off from RegisterBooking.jsx — not a
    // recalculation from a field that doesn't exist on `hotel`.
    const totalAmount = grandTotal;

    const bookingForSuccess = {
      id: `${Date.now()}`,
      customer: {
        full_name: fullName,
        email: email,
        phone: phone,
        city: state.city,
        country: state.country,
      },
      package: {
        package_name: pkg?.package_name || hotel.name,
        destination: pkg?.destination || hotel.location,
        duration: pkg?.duration || hotel.duration || "1 Night",
        price: packagePricePerPerson,
        description: pkg?.description || `Stay at ${hotel.name}, ${hotel.location}.`,
      },
      travel_date: checkIn,
      persons: travellers,
      status: "Confirmed",
      total_amount: totalAmount,
    };

    const paymentForSuccess = {
      amount: totalAmount,
      payment_method: method,
      payment_date: new Date().toISOString().slice(0, 10),
      status: "Paid",
    };

    // Persist so the dashboard's "Payments & Invoices" quick action can
    // jump straight back to this invoice later — Invoice.jsx only reads
    // from router state, there's no backend bookings endpoint to fetch by id.
    try {
      localStorage.setItem(
        "lastBooking",
        JSON.stringify({ booking: bookingForSuccess, payment: paymentForSuccess })
      );
    } catch (err) {
      console.error("Failed to save last booking:", err);
    }

    navigate("/success", {
      state: {
        booking: bookingForSuccess,
        payment: paymentForSuccess,
      },
    });
  };

  return (
    <div className="rb-page">
      {/* LEFT: Booking summary */}
      <div
        className="rb-hero"
        style={{ backgroundImage: `url(${hotel.images?.[0] || hotel.image})` }}
      >
        <div className="rb-hero-overlay"></div>

        <div className="rb-hero-top">
          <span className="rb-secure-badge">
            <i className="fa-solid fa-shield-halved"></i> SECURE PAYMENT
          </span>
        </div>

        <div className="rb-hero-content">
          <p className="rb-hero-location">
            <i className="fa-solid fa-location-dot"></i> {hotel.location}
          </p>
          <h1 className="rb-hero-title">{hotel.name}</h1>

          <div className="rb-hero-meta">
            <span>
              <i className="fa-solid fa-calendar"></i> {checkIn}
            </span>
            <span>
              <i className="fa-solid fa-users"></i> {travellers}{" "}
              {Number(travellers) === 1 ? "Traveller" : "Travellers"}
            </span>
          </div>

          <div className="rb-price-card">
            <span className="rb-price-label">TOTAL AMOUNT</span>
            <div className="rb-price-value">
              ₹{Number(grandTotal).toLocaleString("en-IN")}
            </div>

            {/* Breakdown so the traveller-scaled total is transparent here too */}
            <div className="rb-price-breakdown">
              <div className="rb-price-breakdown-row">
                <span>
                  Package + Flight (₹{(packagePricePerPerson + flightPricePerPerson).toLocaleString("en-IN")} × {travellers})
                </span>
                <span>₹{Number(travellersSubtotal).toLocaleString("en-IN")}</span>
              </div>
              <div className="rb-price-breakdown-row">
                <span>Hotel (fixed)</span>
                <span>₹{Number(hotelTotal).toLocaleString("en-IN")}</span>
              </div>
            </div>

            <span className="rb-price-tag">
              <i className="fa-solid fa-tag"></i> Best price guaranteed
            </span>
          </div>

          <div className="rb-included">
            <p className="rb-included-title">BOOKED BY</p>
            <p className="rb-included-item">
              <i className="fa-solid fa-user"></i> {fullName}
            </p>
            <p className="rb-included-item">
              <i className="fa-solid fa-envelope"></i> {email}
            </p>
            <p className="rb-included-item">
              <i className="fa-solid fa-phone"></i> {phone}
            </p>
          </div>
        </div>
      </div>

      {/* RIGHT: Payment form */}
      <div className="rb-form-panel">
        <div className="rb-steps">
          <div className="rb-step">
            <span className="rb-step-icon">
              <i className="fa-solid fa-user"></i>
            </span>
            Your Details
          </div>
          <div className="rb-step">
            <span className="rb-step-icon">
              <i className="fa-solid fa-map"></i>
            </span>
            Travel Plan
          </div>
          <div className="rb-step active">
            <span className="rb-step-icon">
              <i className="fa-solid fa-credit-card"></i>
            </span>
            Payment
          </div>
        </div>

        <p className="rb-quick-tag">
          <i className="fa-solid fa-lock"></i> PAYMENT
        </p>
        <h2 className="rb-form-heading">Complete Your Payment</h2>
        <p className="rb-form-sub">
          Choose how you'd like to pay for your stay at {hotel.name}.
        </p>

        {payError && (
          <p style={{ color: "#dc2626", fontSize: "13px", marginBottom: "10px" }}>
            {payError}
          </p>
        )}

        {/* Payment method selector */}
        <div
          style={{
            display: "flex",
            gap: "10px",
            flexWrap: "wrap",
            marginBottom: "20px",
          }}
        >
          {PAYMENT_METHODS.map((m) => {
            const active = method === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                style={{
                  flex: "1 1 130px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "6px",
                  padding: "12px 10px",
                  borderRadius: "10px",
                  border: active ? "2px solid #111827" : "1px solid #d1d5db",
                  background: active ? "#111827" : "#fff",
                  color: active ? "#fff" : "#111827",
                  cursor: "pointer",
                  fontSize: "13px",
                  fontWeight: 600,
                  transition: "all 0.15s ease",
                }}
              >
                <i className={m.icon} style={{ fontSize: "18px" }}></i>
                {m.label}
              </button>
            );
          })}
        </div>

        <form onSubmit={handlePay} className="rb-form">
          {/* ---------- CARD ---------- */}
          {method === "card" && (
            <>
              <p className="rb-section-label">CARD DETAILS</p>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-user"></i> NAME ON CARD
                </label>
                <input
                  type="text"
                  name="cardName"
                  placeholder="Full name as on card"
                  value={cardData.cardName}
                  onChange={handleCardChange}
                  required
                />
              </div>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-credit-card"></i> CARD NUMBER
                </label>
                <input
                  type="text"
                  name="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardData.cardNumber}
                  onChange={handleCardChange}
                  maxLength={19}
                  required
                />
              </div>

              <div className="rb-row">
                <div className="rb-field">
                  <label>
                    <i className="fa-solid fa-calendar"></i> EXPIRY
                  </label>
                  <input
                    type="text"
                    name="expiry"
                    placeholder="MM/YY"
                    value={cardData.expiry}
                    onChange={handleCardChange}
                    maxLength={5}
                    required
                  />
                </div>

                <div className="rb-field">
                  <label>
                    <i className="fa-solid fa-lock"></i> CVV
                  </label>
                  <input
                    type="password"
                    name="cvv"
                    placeholder="***"
                    value={cardData.cvv}
                    onChange={handleCardChange}
                    maxLength={4}
                    required
                  />
                </div>
              </div>
            </>
          )}

          {/* ---------- UPI ---------- */}
          {method === "upi" && (
            <>
              <p className="rb-section-label">UPI DETAILS</p>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-mobile-screen"></i> UPI ID
                </label>
                <input
                  type="text"
                  name="upiId"
                  placeholder="yourname@bank"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  required
                />
              </div>
              <p style={{ fontSize: "12px", color: "#6b7280", marginTop: "-6px" }}>
                You'll get a payment request on your UPI app to approve.
              </p>
            </>
          )}

          {/* ---------- NET BANKING ---------- */}
          {method === "netbanking" && (
            <>
              <p className="rb-section-label">NET BANKING</p>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-building-columns"></i> SELECT BANK
                </label>
                <select
                  name="bank"
                  value={bank}
                  onChange={(e) => setBank(e.target.value)}
                  required
                >
                  <option value="">Choose your bank</option>
                  {BANKS.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </div>
              <p style={{ fontSize: "12px", color: "#6b7280", marginTop: "-6px" }}>
                You'll be redirected to your bank's secure login page.
              </p>
            </>
          )}

          {/* ---------- WALLET ---------- */}
          {method === "wallet" && (
            <>
              <p className="rb-section-label">WALLET</p>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-wallet"></i> WALLET PROVIDER
                </label>
                <select
                  name="walletProvider"
                  value={walletProvider}
                  onChange={(e) => setWalletProvider(e.target.value)}
                  required
                >
                  <option value="paytm">Paytm</option>
                  <option value="phonepe">PhonePe</option>
                  <option value="amazonpay">Amazon Pay</option>
                  <option value="mobikwik">MobiKwik</option>
                </select>
              </div>

              <div className="rb-field">
                <label>
                  <i className="fa-solid fa-phone"></i> LINKED PHONE NUMBER
                </label>
                <input
                  type="tel"
                  name="walletPhone"
                  placeholder="10-digit mobile number"
                  value={walletPhone}
                  onChange={(e) => setWalletPhone(e.target.value)}
                  maxLength={10}
                  required
                />
              </div>
            </>
          )}

          <button type="submit" className="rb-confirm-btn" disabled={isPaying}>
            {isPaying ? "Processing..." : `Pay ₹${Number(grandTotal).toLocaleString("en-IN")}`}
            <i className="fa-solid fa-arrow-right"></i>
          </button>
        </form>
      </div>
    </div>
  );
}