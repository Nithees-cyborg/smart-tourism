import TermsNavbar from "../components/TermsNavbar";
import TermsHero from "../components/TermsHero";
import TermsContent from "../components/TermsContent";
import TermsFooter from "../components/TermsFooter";
import "../components/Terms.css";

export default function Terms() {
  return (
    <>
      <TermsNavbar />
      <TermsHero />
      <TermsContent />
      <TermsFooter />
    </>
  );
}