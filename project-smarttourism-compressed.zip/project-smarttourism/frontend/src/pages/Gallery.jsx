import React, { useState, useEffect } from 'react';
import Gallerynavbar from '../components/Gallerynavbar';
import Galleryhero from '../components/Galleryhero';
import Galleryshowcase from '../components/Galleryshowcase';
import Galleryfilters from '../components/Galleryfilters';
import Gallerygrid from '../components/Gallerygrid';
import Gallerylightbox from '../components/Gallerylightbox';
import Galleryfooter from '../components/Galleryfooter';
import '../components/Gallery.css';

// ---- Data ----
const galleryImages = Array.from({ length: 30 }, (_, i) => `/images/gallery${i + 1}.jpg`);

const galleryCategories = [
  'Architecture', 'Landscapes', 'Culture', 'Cuisine', 'Lifestyle', 'Details',
  'Architecture', 'Landscapes', 'Culture', 'Cuisine', 'Lifestyle', 'Details',
  'Architecture', 'Landscapes', 'Culture', 'Cuisine', 'Lifestyle', 'Details',
  'Architecture', 'Landscapes', 'Culture', 'Cuisine', 'Lifestyle', 'Details',
  'Architecture', 'Landscapes', 'Culture', 'Cuisine', 'Lifestyle', 'Details',
];

const FAV_KEY = 'gst_gallery_favorites';

const Gallery = () => {
  const [favorites, setFavorites] = useState(new Set());
  const [currentCategory, setCurrentCategory] = useState('all');
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Load favorites from localStorage on mount
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(FAV_KEY) || '[]');
      setFavorites(new Set(stored));
    } catch (e) {
      setFavorites(new Set());
    }
  }, []);

  const toggleFavorite = (idx) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      try {
        localStorage.setItem(FAV_KEY, JSON.stringify(Array.from(next)));
      } catch (e) {
        /* ignore storage errors */
      }
      return next;
    });
  };

  const openLightbox = (idx) => {
    setCurrentIndex(idx);
    setLightboxOpen(true);
  };

  const closeLightbox = () => setLightboxOpen(false);

  return (
    <>
      <Gallerynavbar />
      <Galleryhero />
      <Galleryshowcase />

      <div className="page-container">
        <div className="section-heading">
          <h2>The Collection</h2>
          <p>Filter by category, save your favorites, and tap any photo to view it full-size.</p>
        </div>

        <Galleryfilters
          currentCategory={currentCategory}
          setCurrentCategory={setCurrentCategory}
          favoritesOnly={favoritesOnly}
          setFavoritesOnly={setFavoritesOnly}
          favCount={favorites.size}
        />

        <Gallerygrid
          images={galleryImages}
          categories={galleryCategories}
          currentCategory={currentCategory}
          favoritesOnly={favoritesOnly}
          favorites={favorites}
          toggleFavorite={toggleFavorite}
          openLightbox={openLightbox}
        />
      </div>

      <Galleryfooter />

      <Gallerylightbox
        images={galleryImages}
        categories={galleryCategories}
        currentIndex={currentIndex}
        setCurrentIndex={setCurrentIndex}
        isOpen={lightboxOpen}
        closeLightbox={closeLightbox}
        favorites={favorites}
        toggleFavorite={toggleFavorite}
      />
    </>
  );
};

export default Gallery;