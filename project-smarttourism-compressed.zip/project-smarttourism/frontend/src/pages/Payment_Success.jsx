import React from "react";
import { useLocation, Navigate } from "react-router-dom";
import "../components/Payment_Success.css";

import Payment_SuccessNavbar from "../components/Payment_SuccessNavbar";
import Payment_SuccessHero from "../components/Payment_SuccessHero";
import Payment_SuccessBookingCard from "../components/Payment_SuccessBookingCard";
import Payment_SuccessCustomerCard from "../components/Payment_SuccessCustomerCard";
import Payment_SuccessWhatsNext from "../components/Payment_SuccessWhatsNext";
import Payment_SuccessFooter from "../components/Payment_SuccessFooter";

export default function Payment_Success() {
  const location = useLocation();
  const booking = location.state?.booking;
  const paymentMethod = location.state?.paymentMethod;

  // If someone lands here directly (refresh, typed URL) with no booking
  // data in state, bounce them back home instead of showing a broken page.
  if (!booking) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="payment-success-page">
      <Payment_SuccessNavbar />
      <Payment_SuccessHero />

      <div className="container">
        <Payment_SuccessBookingCard booking={booking} />
        <Payment_SuccessCustomerCard booking={booking} paymentMethod={paymentMethod} />
        <Payment_SuccessWhatsNext booking={booking} />
      </div>

      <Payment_SuccessFooter />
    </div>
  );
}