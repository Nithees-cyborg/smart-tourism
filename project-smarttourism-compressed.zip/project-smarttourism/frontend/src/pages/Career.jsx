import React from "react";
import CareerNavbar from "../components/CareerNavbar";
import CareerHero from "../components/CareerHero";
import CareerContent from "../components/CareerContent";
import CareerFooter from "../components/CareerFooter";
import "../components/Career.css";

export default function Career() {
  return (
    <>
      <CareerNavbar />
      <CareerHero />
      <CareerContent />
      <CareerFooter />
    </>
  );
}