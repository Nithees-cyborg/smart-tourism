import { useState, useEffect, useRef } from "react";
import Navbar from "../components/Dashboardnavbar";
import Hero from "../components/Dashboardhero";
import StatsCards from "../components/StatsCards";
import QuickActionsAndDestinations from "../components/Quickactionsanddestinations";
import Sidebar from "../components/Sidebar";
import PopularDestinations from "../components/PopularDestinations";
import Features from "../components/Features";
import TestimonialsAndNewsletter from "../components/TestimonialsAndNewsletter";
import { Footer } from "../components/Dashboardfooter";
import { fetchStats } from "../components/DashboardApi";
import "../components/Dashboard.css";

export default function Dashboard() {
  const [searchState, setSearchState] = useState({ dest: "", dur: "", type: "" });
  const [stats, setStats] = useState(null);
  const [statsError, setStatsError] = useState(false);

  const [theme, setTheme] = useState(() => {
    if (typeof window === "undefined") return "light";
    try {
      return localStorage.getItem("gst-theme") || "light";
    } catch {
      return "light";
    }
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem("gst-theme", theme);
    } catch {
      // storage unavailable — theme just won't persist
    }
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "light" ? "dark" : "light"));

  const videoRef = useRef(null);
  useEffect(() => {
    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced && videoRef.current) videoRef.current.pause();
  }, []);

  useEffect(() => {
    let alive = true;
    fetchStats()
      .then((data) => alive && setStats(data))
      .catch(() => alive && setStatsError(true));
    return () => {
      alive = false;
    };
  }, []);

  const handleSearch = () => {
    console.log("Searching with:", searchState);
  };

  return (
    <>
      <video
        ref={videoRef}
        className="dash-bg-video"
        src="/travel-background.mp4"
        poster="/travel-background-poster.jpg"
        autoPlay
        muted
        loop
        playsInline
      />
      <div className="dash-bg-overlay" aria-hidden="true" />

      <div className="dash-shell">
        <Navbar currentPath="/" theme={theme} onToggleTheme={toggleTheme} />

        <div className="dash-main">
          <div className="dash-content">
            <Hero
              searchState={searchState}
              setSearchState={setSearchState}
              onSearch={handleSearch}
              onlineCount={stats?.travelers_online}
              bookingsToday={stats?.bookings_today}
              revenueToday={stats?.revenue_today}
            />

            {statsError ? (
              <p className="dash-fetch-error">Couldn't reach the backend for live stats — check the Django server is running.</p>
            ) : (
              <StatsCards
                customerCount={stats?.customer_count ?? "—"}
                packageCount={stats?.package_count ?? "—"}
                bookingCount={stats?.booking_count ?? "—"}
                hotelCount={stats?.hotel_count ?? "—"}
                totalRevenue={stats?.total_revenue ?? "—"}
              />
            )}

            {/* Flattened: all panels are now direct children of .main-grid so
                the masonry CSS (column-count) can balance their heights and
                avoid the big empty gap that showed up when the left/right
                columns were independent flex containers of unequal height. */}
            <div className="main-grid">
              <QuickActionsAndDestinations />
              <Sidebar totalRevenue={stats?.total_revenue ?? "—"} bookingCount={stats?.booking_count ?? "—"} />
            </div>

            <PopularDestinations />
            <Features />
            <TestimonialsAndNewsletter />
          </div>

          <Footer />
        </div>
      </div>
    </>
  );
}