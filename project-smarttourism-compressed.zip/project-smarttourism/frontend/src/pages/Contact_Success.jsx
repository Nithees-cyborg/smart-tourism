import React, { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";

import Contact_SuccessNavbar from "../components/Contact_SuccessNavbar";
import Contact_SuccessHero from "../components/Contact_SuccessHero";
import Contact_SuccessCard from "../components/Contact_SuccessCard";
import Contact_SuccessFooter from "../components/Contact_SuccessFooter";

import "../components/Contact_Success.css";

/**
 * pages/Contact_Success.jsx
 *
 * Shown after the contact form on the site successfully POSTs to the
 * Django backend. The form component should navigate here like:
 *
 *   navigate("/contact-success", { state: { refId: data.ref_id, submittedOn: data.created_at } });
 *
 * If the page is opened directly (no state), it falls back to a locally
 * generated reference id so the page still looks correct in dev.
 */
export default function Contact_Success() {
  const location = useLocation();
  const refId = location.state?.refId;
  const submittedOn = location.state?.submittedOn;
  const confettiRef = useRef(null);

  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion || !confettiRef.current) return;

    const colors = ["#C9A45C", "#F3EEE4", "#34C77B", "#DEC07F"];
    const layer = confettiRef.current;
    const pieceCount = 28;

    for (let i = 0; i < pieceCount; i++) {
      const piece = document.createElement("span");
      piece.className = "cs-confetti-piece";

      const angle = Math.random() * Math.PI * 2;
      const distance = 120 + Math.random() * 180;
      const tx = Math.cos(angle) * distance;
      const ty = Math.sin(angle) * distance - 40;
      const rot = Math.random() * 720 - 360 + "deg";
      const delay = Math.random() * 0.15;
      const color = colors[Math.floor(Math.random() * colors.length)];
      const size = 6 + Math.random() * 6;

      piece.style.setProperty("--tx", tx + "px");
      piece.style.setProperty("--ty", ty + "px");
      piece.style.setProperty("--rot", rot);
      piece.style.background = color;
      piece.style.width = size + "px";
      piece.style.height = size + "px";
      piece.style.animationDelay = delay + "s";

      layer.appendChild(piece);
    }

    const clearTimer = setTimeout(() => {
      layer.innerHTML = "";
    }, 2200);

    return () => clearTimeout(clearTimer);
  }, []);

  return (
    <div
      className="cs-page"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: "100vw",
        height: "100vh",
        margin: 0,
      }}
    >
      <div className="cs-bg-photo" aria-hidden="true"></div>
      <div className="cs-bg-overlay" aria-hidden="true"></div>
      <div className="cs-confetti-layer" ref={confettiRef} aria-hidden="true"></div>

      <Contact_SuccessNavbar />

      <div className="cs-success-box">
        <Contact_SuccessHero refId={refId} submittedOn={submittedOn} />
        <Contact_SuccessCard />
        <Contact_SuccessFooter />
      </div>
    </div>
  );
}