import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Trophy, Star, Gift, Plane, Hotel, Percent,
  Users, Sparkles, ArrowRight, Award, CheckCircle2,
  Clock, ShieldCheck, Info, XCircle,
} from "lucide-react";
import "../components/Rewards.css";

const USER_POINTS = 3450;
const TIER_THRESHOLDS = [
  { name: "Bronze", min: 0, icon: Award, color: "#b08968", perk: "Standard earn rate on every booking" },
  { name: "Silver", min: 1500, icon: Award, color: "#94a3b8", perk: "1.25x points + priority email support" },
  { name: "Gold", min: 3000, icon: Trophy, color: "#eab308", perk: "1.5x points + free date changes" },
  { name: "Platinum", min: 6000, icon: Sparkles, color: "#8b5cf6", perk: "2x points + dedicated trip concierge" },
];

function getCurrentTier(points) {
  let current = TIER_THRESHOLDS[0];
  for (const tier of TIER_THRESHOLDS) if (points >= tier.min) current = tier;
  return current;
}
function getNextTier(points) {
  return TIER_THRESHOLDS.find((t) => t.min > points) || null;
}

const earnMethods = [
  { Icon: Plane, title: "Book a Trip", desc: "Earn 1 point for every ₹100 spent on any package." },
  { Icon: Users, title: "Refer a Friend", desc: "Get 500 bonus points when they complete their first booking." },
  { Icon: Star, title: "Leave a Review", desc: "Earn 100 points for every verified trip review you share." },
  { Icon: Gift, title: "Birthday Bonus", desc: "Automatic 250 points credited every year on your birthday." },
];

const rewardCatalog = [
  { img: "/reward1.jpg", title: "Free Hotel Night", desc: "Redeem 2,000 points for a complimentary night at any partner hotel.", points: "2,000 pts" },
  { img: "/reward2.jpg", title: "Flight Seat Upgrade", desc: "Use 3,500 points to upgrade your next flight to premium economy.", points: "3,500 pts" },
  { img: "/reward3.jpg", title: "₹5,000 Trip Voucher", desc: "Redeem 5,000 points for a voucher toward your next package.", points: "5,000 pts" },
];

const steps = [
  { n: "01", title: "Book & Travel", desc: "Every confirmed booking automatically starts earning points." },
  { n: "02", title: "Watch Points Grow", desc: "Track your balance and tier progress right here, anytime." },
  { n: "03", title: "Redeem Freely", desc: "Trade points for hotel nights, upgrades, or vouchers — no blackout dates." },
];

const policyPoints = [
  { Icon: Clock, title: "Point Validity", desc: "Points stay active for 24 months from the date they're earned, then expire automatically if unused." },
  { Icon: ShieldCheck, title: "Tier Protection", desc: "Once you reach Gold or Platinum, your tier is locked in for 12 months regardless of future spend." },
  { Icon: Info, title: "Redemption Rule", desc: "Points can be redeemed in blocks of 500 and combined with ongoing offers, but not with other point promotions." },
  { Icon: XCircle, title: "Cancellations", desc: "Points earned on a booking are reversed if that booking is cancelled or fully refunded." },
];

// Small floating sparkle field for the hero background
function SparkleField() {
  const sparkles = Array.from({ length: 14 });
  return (
    <div className="sparkle-field" aria-hidden="true">
      {sparkles.map((_, i) => (
        <span
          key={i}
          className="sparkle-dot"
          style={{
            left: `${(i * 37) % 100}%`,
            top: `${(i * 53) % 100}%`,
            animationDelay: `${(i % 7) * 0.6}s`,
            animationDuration: `${3 + (i % 4)}s`,
          }}
        />
      ))}
    </div>
  );
}

export default function Rewards() {
  const [animatedPoints, setAnimatedPoints] = useState(0);
  const currentTier = getCurrentTier(USER_POINTS);
  const nextTier = getNextTier(USER_POINTS);
  const progressPct = nextTier
    ? Math.min(100, ((USER_POINTS - currentTier.min) / (nextTier.min - currentTier.min)) * 100)
    : 100;

  useEffect(() => {
    let frame;
    const duration = 1200;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min(1, (now - start) / duration);
      setAnimatedPoints(Math.floor(progress * USER_POINTS));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <div className="rewards-page">
      {/* Hero */}
      <section className="rewards-hero">
        <div className="rewards-hero-glow" />
        <SparkleField />
        <div className="rewards-hero-content">
          <span className="rewards-eyebrow"><Sparkles size={13} strokeWidth={2.5} /> Voyager Rewards</span>
          <h1>Every Trip Earns You Something Back</h1>
          <p>Collect points on every booking and unlock hotel nights, upgrades, and vouchers.</p>

          <div className="points-card">
            <div className="points-shimmer" />
            <div className="points-card-left">
              <span className="points-label">Your Balance</span>
              <span className="points-value">{animatedPoints.toLocaleString("en-IN")} <small>pts</small></span>
            </div>

            <div className="points-card-right">
              <div className="tier-badge tier-badge--glow" style={{ "--tier-color": currentTier.color }}>
                <currentTier.icon size={18} strokeWidth={2.25} />
                {currentTier.name}
              </div>
              {nextTier ? (
                <>
                  <div className="tier-progress-track">
                    <div className="tier-progress-fill" style={{ width: `${progressPct}%` }} />
                  </div>
                  <span className="tier-progress-label">
                    {(nextTier.min - USER_POINTS).toLocaleString("en-IN")} pts to {nextTier.name}
                  </span>
                </>
              ) : (
                <span className="tier-progress-label">You've reached the top tier 🎉</span>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* About Rewards */}
      <section className="rewards-section">
        <div className="about-wrap">
          <div className="about-copy">
            <h2 className="section-title section-title--left">About Voyager Rewards</h2>
            <p>
              Voyager Rewards is Global Smart Tourism's loyalty program, built for travellers who explore
              often. Every rupee spent on a package, hotel add-on, or transport booking converts directly
              into points — no separate sign-up fee, no hidden conditions.
            </p>
            <p>
              As your balance grows, you move up through four membership tiers, each unlocking faster
              earning, flexible date changes, and dedicated support. It's our way of saying thank you for
              choosing us trip after trip.
            </p>
            <div className="about-badges">
              <span className="about-badge"><CheckCircle2 size={14} strokeWidth={2.5} /> No annual fee</span>
              <span className="about-badge"><CheckCircle2 size={14} strokeWidth={2.5} /> No blackout dates</span>
              <span className="about-badge"><CheckCircle2 size={14} strokeWidth={2.5} /> Points never split across trips</span>
            </div>
          </div>
          <div className="about-tier-preview">
            {TIER_THRESHOLDS.map((t) => (
              <div className="about-tier-row" key={t.name} style={{ "--tier-color": t.color }}>
                <t.icon size={18} strokeWidth={2.25} />
                <div>
                  <b>{t.name}</b>
                  <span>{t.perk}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="rewards-section rewards-section--alt">
        <h2 className="section-title">How It Works</h2>
        <div className="steps-row">
          {steps.map((s) => (
            <div className="step-card" key={s.n}>
              <span className="step-number">{s.n}</span>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ways to earn */}
      <section className="rewards-section">
        <h2 className="section-title">Ways to Earn Points</h2>
        <div className="earn-grid">
          {earnMethods.map((m, i) => (
            <div className="earn-card" key={m.title} style={{ "--delay": `${i * 0.08}s` }}>
              <div className="earn-icon"><m.Icon size={20} strokeWidth={2.15} /></div>
              <h3>{m.title}</h3>
              <p>{m.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Reward catalog */}
      <section className="rewards-section rewards-section--alt">
        <h2 className="section-title">Popular Rewards</h2>
        <div className="reward-catalog-grid">
          {rewardCatalog.map((r, i) => (
            <div className="reward-catalog-card" key={r.title} style={{ "--delay": `${i * 0.1}s` }}>
              <div className="reward-catalog-imgwrap">
                <img src={r.img} alt={r.title} loading="lazy" />
                <span className="reward-catalog-points">{r.points}</span>
              </div>
              <h3>{r.title}</h3>
              <p>{r.desc}</p>
              <button className="reward-redeem-btn">
                Redeem <ArrowRight size={14} strokeWidth={2.5} />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Tier ladder */}
      <section className="rewards-section">
        <h2 className="section-title">Membership Tiers</h2>
        <div className="tier-ladder">
          {TIER_THRESHOLDS.map((t) => {
            const isCurrent = t.name === currentTier.name;
            return (
              <div
                className={`tier-ladder-card ${isCurrent ? "tier-ladder-card--active" : ""}`}
                key={t.name}
                style={{ "--tier-color": t.color }}
              >
                <t.icon size={22} strokeWidth={2.15} />
                <h3>{t.name}</h3>
                <p>{t.min.toLocaleString("en-IN")}+ pts</p>
                {isCurrent && <span className="tier-current-tag"><CheckCircle2 size={12} strokeWidth={2.5} /> Current</span>}
              </div>
            );
          })}
        </div>
      </section>

      {/* Rewards Policy */}
      <section className="rewards-section rewards-section--alt">
        <h2 className="section-title">Rewards Policy & Terms</h2>
        <div className="policy-grid">
          {policyPoints.map((p) => (
            <div className="policy-card" key={p.title}>
              <div className="policy-icon"><p.Icon size={18} strokeWidth={2.15} /></div>
              <div>
                <h3>{p.title}</h3>
                <p>{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="policy-footnote">
          Global Smart Tourism reserves the right to update these terms at any time. Continued use of
          Voyager Rewards after changes are posted means you accept the revised terms.
        </p>
      </section>

      {/* CTA */}
      <section className="rewards-cta">
        <Percent size={26} strokeWidth={2} />
        <h2>Ready to earn on your next trip?</h2>
        <p>Browse packages and start collecting points today.</p>
        <Link to="/packages/" className="rewards-cta-btn">
          Explore Packages <ArrowRight size={16} strokeWidth={2.5} />
        </Link>
      </section>
    </div>
  );
}