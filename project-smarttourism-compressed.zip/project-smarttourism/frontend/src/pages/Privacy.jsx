import React from "react";
import PrivacyNavbar from "../components/PrivacyNavbar";
import PrivacyHero from "../components/PrivacyHero";
import PrivacyContent from "../components/PrivacyContent";
import PrivacyFooter from "../components/PrivacyFooter";
import "../components/Privacy.css";

export default function Privacy() {
  return (
    <>
      <PrivacyNavbar />
      <PrivacyHero />
      <PrivacyContent />
      <PrivacyFooter />
    </>
  );
}