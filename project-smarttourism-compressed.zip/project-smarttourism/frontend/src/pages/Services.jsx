import { useEffect } from "react";

import Servicesnavbar from "../components/Servicesnavbar";
import Serviceshero from "../components/Serviceshero";
import Servicescards from "../components/Servicescards";
import Serviceswhyus from "../components/Serviceswhyus";
import Serviceshowitworks from "../components/Serviceshowitworks";
import Servicesgallery from "../components/Servicesgallery";
import Servicestestimonialsfaq from "../components/Servicestestimonialsfaq";
import Servicesfooter from "../components/Servicesfooter";
import "../components/Services.css";

function Services() {
  // scroll-reveal animation, replaces the old {% static 'js/main.js' %} IntersectionObserver
  useEffect(() => {
    const reveals = document.querySelectorAll(".services-page .reveal");

    if ("IntersectionObserver" in window) {
      const obs = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("visible");
              obs.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12 }
      );
      reveals.forEach((el) => obs.observe(el));
      return () => obs.disconnect();
    } else {
      reveals.forEach((el) => el.classList.add("visible"));
    }
  }, []);

  return (
    <div className="services-page">
      <Servicesnavbar />
      <Serviceshero />
      <Servicescards />
      <Serviceswhyus />
      <Serviceshowitworks />
      <Servicesgallery />
      <Servicestestimonialsfaq />
      <Servicesfooter />
    </div>
  );
}

export default Services;