// Transports.jsx  (src/components/Transports.jsx)
// Ground-transport booking page (Cabs & Buses) for getting around within
// the selected package's destination. Pickup point is drawn from the
// package's own places (arrangement point), and the travel date supports
// an optional "to" date for multi-day hire.
//
// IMAGES NEEDED in /public:
//   /flight1.jpg, /flight2.jpg, /flight3.jpg  — banners
//   /car1.jpg .. /car4.jpg   — cab model photos
//   /bus1.jpg .. /bus6.jpg   — bus model photos

import { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { MapPin, CalendarDays, Car, ChevronLeft, ShieldCheck, Star } from "lucide-react";
import {
  getDestinations,
  getPackageById,
  getArrangementPoints,
  generateTransportOptions,
} from "../components/TransportsData";
import TransportCard from "../components/TransportCard";
import "../components/Transports.css";

const STEPS = ["Destination", "Trip details", "Choose transport"];

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export default function Transports() {
  const navigate = useNavigate();
  const location = useLocation();
  const incomingHotel = location.state?.hotel || null;

  const destinations = useMemo(() => getDestinations(), []);

  const [step, setStep] = useState(0);
  const [query, setQuery] = useState("");
  const [destinationId, setDestinationId] = useState(null);

  const [pickupPoint, setPickupPoint] = useState("");
  const [fromDate, setFromDate] = useState(todayISO());
  const [useDateRange, setUseDateRange] = useState(false);
  const [toDate, setToDate] = useState("");

  const [transportMode, setTransportMode] = useState("cab"); // "cab" | "bus"
  const [selectedOptionId, setSelectedOptionId] = useState(null);

  const selectedDestination = destinations.find((d) => d.id === destinationId) || null;
  const pkg = destinationId ? getPackageById(destinationId) : null;

  // Arrangement/pickup points come from the selected package's own places
  const arrangementPoints = useMemo(() => getArrangementPoints(pkg), [pkg]);

  useEffect(() => {
    if (arrangementPoints.length > 0) {
      setPickupPoint(arrangementPoints[0]);
    }
  }, [arrangementPoints]);

  const transportOptions = useMemo(() => {
    if (!selectedDestination || !pickupPoint) return [];
    return generateTransportOptions({
      origin: pickupPoint,
      destinationCode: selectedDestination.code,
      date: fromDate,
      toDate: useDateRange ? toDate : null,
      mode: transportMode,
    });
  }, [selectedDestination, pickupPoint, fromDate, toDate, useDateRange, transportMode]);

  const selectedOption = transportOptions.find((o) => o.id === selectedOptionId) || null;

  const filteredDestinations = destinations.filter((d) =>
    `${d.destination} ${d.country}`.toLowerCase().includes(query.toLowerCase())
  );

  function goToDetails(destId) {
    setDestinationId(destId);
    setSelectedOptionId(null);
    setStep(1);
  }

  function goToTransport() {
    setSelectedOptionId(null);
    setStep(2);
  }

  function handleContinue() {
    if (!pkg || !selectedOption) return;
    const payload = {
      pkg,
      transport: selectedOption,
      pickupPoint,
      fromDate,
      toDate: useDateRange ? toDate : null,
      hotel: incomingHotel,
    };
    navigate(`/overview/${pkg.id}`, { state: payload });
  }

  function handleSkip() {
    if (!pkg) return;
    const payload = {
      pkg,
      transport: null,
      pickupPoint,
      fromDate,
      toDate: useDateRange ? toDate : null,
      hotel: incomingHotel,
    };
    navigate(`/overview/${pkg.id}`, { state: payload });
  }

  return (
    <div className="tr-page">
      {/* ---------------- HERO ---------------- */}
      <div className="tr-hero" style={{ backgroundImage: "url(/flight1.jpg)" }}>
        <div className="tr-hero-overlay" />
        <div className="tr-hero-inner">
          <div className="tr-eyebrow">
            <Car size={18} />
            Book your ride
          </div>
          <h1 className="tr-hero-title">
            Get around in style. Cabs and buses matched to your package, in a few taps.
          </h1>
          <div className="tr-hero-badges">
            <span>
              <ShieldCheck size={16} color="#34d399" /> Verified operators
            </span>
            <span>
              <Star size={16} color="#fbbf24" /> Handpicked rides
            </span>
          </div>
        </div>
      </div>

      {/* step indicator */}
      <div className="tr-steps">
        <div className="tr-steps-inner">
          {STEPS.map((label, i) => (
            <div className="tr-step" key={label}>
              <span className={`tr-step-num ${i <= step ? "active" : ""}`}>{i + 1}</span>
              <span className={`tr-step-label ${i <= step ? "active" : ""}`}>{label}</span>
              {i < STEPS.length - 1 && <span className="tr-step-divider" />}
            </div>
          ))}
        </div>
      </div>

      <div className="tr-body">
        {/* STEP 0 — pick destination from packages */}
        {step === 0 && (
          <section>
            <h2 className="tr-h2">Where are you headed?</h2>
            <p className="tr-sub">Choose a destination from your booked packages.</p>

            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search destination or country..."
              className="tr-search"
            />

            <div className="tr-grid">
              {filteredDestinations.map((d) => (
                <button key={d.id} className="tr-card" onClick={() => goToDetails(d.id)}>
                  <div className="tr-card-photo" style={{ backgroundImage: `url(${d.image})` }}>
                    <span className="tr-card-name">{d.destination}</span>
                    <span className="tr-card-code">{d.airportCode}</span>
                  </div>
                  <div className="tr-card-body">
                    <div className="tr-card-country">
                      <MapPin size={12} />
                      {d.country}
                    </div>
                    <div className="tr-card-row">
                      <span className="tr-card-duration">{d.duration}</span>
                      <span className="tr-card-price">from ₹{d.price}</span>
                    </div>
                  </div>
                </button>
              ))}
              {filteredDestinations.length === 0 && (
                <p className="tr-empty">No destinations match "{query}".</p>
              )}
            </div>
          </section>
        )}

        {/* STEP 1 — trip details */}
        {step === 1 && selectedDestination && (
          <section>
            <button className="tr-back" onClick={() => setStep(0)}>
              <ChevronLeft size={16} /> Back to destinations
            </button>

            <div className="tr-details-grid">
              <div>
                <h2 className="tr-h2">Getting around in {selectedDestination.destination}</h2>
                <p className="tr-sub">
                  {selectedDestination.packageName} · {selectedDestination.country}
                </p>

                <div className="tr-form-grid">
                  <label>
                    <span className="tr-label">Pickup point</span>
                    <select
                      className="tr-select"
                      value={pickupPoint}
                      onChange={(e) => setPickupPoint(e.target.value)}
                    >
                      {arrangementPoints.map((point) => (
                        <option key={point} value={point}>
                          {point}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label>
                    <span className="tr-label tr-label-icon">
                      <CalendarDays size={14} /> From date
                    </span>
                    <input
                      type="date"
                      className="tr-input"
                      value={fromDate}
                      min={todayISO()}
                      onChange={(e) => setFromDate(e.target.value)}
                    />
                  </label>
                </div>

                <label className="tr-range-toggle">
                  <input
                    type="checkbox"
                    checked={useDateRange}
                    onChange={(e) => {
                      setUseDateRange(e.target.checked);
                      if (e.target.checked && !toDate) setToDate(fromDate);
                    }}
                  />
                  <span>Need it for more than one day? Add a return/end date</span>
                </label>

                {useDateRange && (
                  <div className="tr-form-grid" style={{ marginTop: 10 }}>
                    <label>
                      <span className="tr-label tr-label-icon">
                        <CalendarDays size={14} /> To date
                      </span>
                      <input
                        type="date"
                        className="tr-input"
                        value={toDate}
                        min={fromDate}
                        onChange={(e) => setToDate(e.target.value)}
                      />
                    </label>
                  </div>
                )}

                <button className="tr-btn-primary" onClick={goToTransport}>
                  Show cabs & buses
                </button>
              </div>

              <div className="tr-details-image" style={{ backgroundImage: "url(/flight2.jpg)" }} />
            </div>
          </section>
        )}

        {/* STEP 2 — browse + select cab or bus (optional) */}
        {step === 2 && selectedDestination && (
          <section>
            <button className="tr-back" onClick={() => setStep(1)}>
              <ChevronLeft size={16} /> Edit trip details
            </button>

            <div className="tr-route-banner" style={{ backgroundImage: "url(/flight3.jpg)" }}>
              <div>
                <h2 className="tr-route-title">
                  {pickupPoint} → {selectedDestination.destination}
                </h2>
                <p className="tr-route-sub">
                  {fromDate}
                  {useDateRange && toDate ? ` – ${toDate}` : ""} · Ground transport in{" "}
                  {selectedDestination.destination}, {selectedDestination.country}
                </p>
              </div>
            </div>

            <div className="tc-mode-tabs">
              <button
                className={`tc-mode-tab ${transportMode === "cab" ? "active" : ""}`}
                onClick={() => {
                  setTransportMode("cab");
                  setSelectedOptionId(null);
                }}
              >
                <Car size={16} /> Cabs
              </button>
              <button
                className={`tc-mode-tab ${transportMode === "bus" ? "active" : ""}`}
                onClick={() => {
                  setTransportMode("bus");
                  setSelectedOptionId(null);
                }}
              >
                Buses
              </button>
            </div>

            <div className="tr-flight-list">
              {transportOptions.map((option) => (
                <TransportCard
                  key={option.id}
                  option={option}
                  selected={selectedOptionId === option.id}
                  onSelect={setSelectedOptionId}
                />
              ))}
            </div>

            <div className="tr-sticky-bar">
              <div className="tr-sticky-summary">
                {selectedOption ? (
                  <>
                    Package <b>₹{pkg?.price}</b> + {transportMode === "cab" ? "Cab" : "Bus"}{" "}
                    <b>₹{selectedOption.price.toLocaleString("en-IN")}</b>
                    {selectedOption.dayCount > 1 && ` (${selectedOption.dayCount} days)`}
                  </>
                ) : (
                  `Transport is optional — select a ${transportMode} or skip`
                )}
              </div>
              <div className="tr-sticky-actions">
                <button className="tr-btn-skip" onClick={handleSkip}>
                  Skip for now
                </button>
                <button
                  className={selectedOption ? "tr-btn-accent" : "tr-btn-disabled"}
                  disabled={!selectedOption}
                  onClick={handleContinue}
                >
                  Continue to overview
                </button>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}