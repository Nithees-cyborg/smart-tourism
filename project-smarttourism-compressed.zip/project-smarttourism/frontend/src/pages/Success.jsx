import React from "react";
import { useLocation, Navigate } from "react-router-dom";
import SuccessNavbar from "../components/SuccessNavbar";
import SuccessHero from "../components/SuccessHero";
import SuccessInfoCards from "../components/SuccessInfoCards";
import SuccessNextSteps from "../components/SuccessNextSteps";
import SuccessFooter from "../components/SuccessFooter";
import "../components/Success.css";

export default function Success() {
  const location = useLocation();
  const booking = location.state?.booking;
  const payment = location.state?.payment;

  // If someone lands here directly (refresh, typed URL, back button)
  // with no real booking/payment data passed in, bounce them home
  // instead of showing stale placeholder details.
  if (!booking || !payment) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="success-page">
      <SuccessNavbar />
      <SuccessHero />

      <div className="page-wrap">
        <SuccessInfoCards booking={booking} payment={payment} />
        <SuccessNextSteps booking={booking} payment={payment} />
      </div>

      <SuccessFooter />
    </div>
  );
}