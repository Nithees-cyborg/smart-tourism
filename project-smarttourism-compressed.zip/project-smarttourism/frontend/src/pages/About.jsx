import { useEffect } from "react";
import Aboutnavbar from "../components/Aboutnavbar";
import Abouthero from "../components/Abouthero";
import Aboutstory from "../components/Aboutstory";
import { Aboutstats, Aboutjourney } from "../components/Aboutstats";
import { Aboutvalues, Aboutwhyus } from "../components/Aboutvalues";
import { Aboutteam, Aboutawards } from "../components/Aboutteam";
import { Aboutcta, Aboutfooter } from "../components/Aboutfooter";
import "../components/About.css";

export default function About() {
  // Shared scroll-reveal animation for every ".reveal" element on this page
  useEffect(() => {
    const revealEls = document.querySelectorAll(".reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const siblings = [...entry.target.parentElement.querySelectorAll(".reveal:not(.visible)")];
            const idx = siblings.indexOf(entry.target);
            setTimeout(() => entry.target.classList.add("visible"), idx * 80);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealEls.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <Aboutnavbar />
      <Abouthero />
      <Aboutstory />
      <Aboutstats />
      <Aboutjourney />
      <Aboutvalues />
      <Aboutwhyus />
      <Aboutteam />
      <Aboutawards />
      <Aboutcta />
      <Aboutfooter />
    </>
  );
}