// Overallview.jsx
// Shown after a destination + transport (cab/bus, optional) are picked in
// Transports.jsx. Reads { pkg, transport, pickupPoint, fromDate, toDate,
// hotel } from route state (passed via navigate(`/overview/${pkg.id}`,
// { state: payload }) in Transports.jsx).
//
// Uses plain CSS (Overallview.css) — no Tailwind dependency.
//
// If someone lands here directly (no state — e.g. page refresh), we fall
// back to looking the package up by :packageId so the page still shows
// something useful, with a prompt to go pick a cab/bus.

import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  Car,
  Bus as BusIcon,
  Clock,
  MapPin,
  ChevronLeft,
  CalendarDays,
  BadgeCheck,
  Star,
  Compass,
  ListChecks,
  BedDouble,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { getPackageById } from "../components/TransportsData";
import "../components/Overallview.css";

function toNumber(price) {
  return Number(String(price).replace(/,/g, "")) || 0;
}

export default function Overallview() {
  const { state } = useLocation();
  const { packageId } = useParams();
  const navigate = useNavigate();

  const pkg = state?.pkg || getPackageById(packageId);
  const transport = state?.transport || null;
  const pickupPoint = state?.pickupPoint || null;
  const fromDate = state?.fromDate || null;
  const toDate = state?.toDate || null;
  const hotel = state?.hotel || null;

  if (!pkg) {
    return (
      <div className="ov-notfound">
        <div>
          <p style={{ color: "#6b7686" }}>We couldn't find that package.</p>
          <button className="ov-link-btn" onClick={() => navigate("/packages")}>
            Browse packages
          </button>
        </div>
      </div>
    );
  }

  const packagePrice = toNumber(pkg.price);
  const transportPrice = transport ? transport.price : 0;
  const hotelPrice = hotel ? hotel.grandTotal : 0;
  const total = packagePrice + transportPrice + hotelPrice;

  const isCab = transport?.mode === "cab";

  const stayInclusion = pkg.inclusions?.find(
    (i) => /night|stay|hotel|resort|villa|houseboat|camp/i.test(i)
  );
  const itineraryPreview = (pkg.itinerary || []).slice(0, 4);
  const remainingDays = (pkg.itinerary?.length || 0) - itineraryPreview.length;

  return (
    <div className="ov-page">
      {/* top bar */}
      <div className="ov-topbar">
        <div className="ov-topbar-inner">
          <button className="ov-back" onClick={() => navigate(-1)}>
            <ChevronLeft size={16} /> Back
          </button>
          <span className="ov-crumb-sep">/</span>
          <span className="ov-crumb-current">Trip overview</span>
        </div>
      </div>

      {/* hero */}
      <div className="ov-hero" style={{ backgroundImage: `url(${pkg.image})` }}>
        <div className="ov-hero-inner">
          {pkg.tag && (
            <span className="ov-hero-badge">
              <Star size={12} /> {pkg.tag}
            </span>
          )}
          <h1 className="ov-hero-title">{pkg.package_name}</h1>
          <p className="ov-hero-tagline">{pkg.tagline}</p>
          <div className="ov-hero-stats">
            <span className="ov-hero-stat">
              <MapPin size={13} /> {pkg.destination}
            </span>
            <span className="ov-hero-stat">
              <Clock size={13} /> {pkg.duration}
            </span>
            <span className="ov-hero-stat">
              <Star size={13} /> {pkg.rating} rating
            </span>
            <span className="ov-hero-stat">Best time: {pkg.bestTime}</span>
          </div>
        </div>
      </div>

      <div className="ov-body">
        {/* ---------------- LEFT COLUMN ---------------- */}
        <div className="ov-col-left">
          {/* highlights + overview */}
          <div className="ov-card">
            <h2 className="ov-card-title">
              <Compass size={17} /> Trip at a glance
            </h2>
            <div className="ov-chips">
              {pkg.highlights?.map((h) => (
                <span key={h} className="ov-chip">
                  {h}
                </span>
              ))}
            </div>
            <p className="ov-overview-text" style={{ marginTop: 14 }}>
              {pkg.overview || pkg.description}
            </p>
          </div>

          {/* places covered gallery */}
          {pkg.placesCovered?.length > 0 && (
            <div className="ov-card">
              <h2 className="ov-card-title">
                <MapPin size={17} /> Places you'll cover
              </h2>
              <div className="ov-gallery">
                {pkg.placesCovered.map((place) => (
                  <div key={place.name} className="ov-gallery-item" title={place.description}>
                    <div className="ov-gallery-bg" style={{ backgroundImage: `url(${place.image})` }} />
                    <span className="ov-gallery-name">{place.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* itinerary preview */}
          {itineraryPreview.length > 0 && (
            <div className="ov-card">
              <h2 className="ov-card-title">
                <ListChecks size={17} /> Itinerary preview
              </h2>
              <div className="ov-itinerary">
                {itineraryPreview.map((day) => (
                  <div key={day.day} className="ov-itin-row">
                    <span className="ov-itin-day">D{day.day}</span>
                    <div className="ov-itin-text">
                      <div className="ov-itin-title">{day.title}</div>
                      <div className="ov-itin-detail">{day.detail}</div>
                    </div>
                  </div>
                ))}
              </div>
              {remainingDays > 0 && (
                <div className="ov-itin-more">+ {remainingDays} more day{remainingDays > 1 ? "s" : ""} in the full itinerary</div>
              )}
            </div>
          )}

          {/* inclusions / exclusions */}
          {(pkg.inclusions?.length > 0 || pkg.exclusions?.length > 0) && (
            <div className="ov-card">
              <h2 className="ov-card-title">
                <BadgeCheck size={17} /> What's included
              </h2>
              <div className="ov-two-col">
                <div>
                  <div className="ov-list-label included">Included</div>
                  <ul className="ov-list">
                    {pkg.inclusions?.map((item) => (
                      <li key={item}>
                        <CheckCircle2 size={15} className="ov-tick yes" /> {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="ov-list-label excluded">Not included</div>
                  <ul className="ov-list">
                    {pkg.exclusions?.map((item) => (
                      <li key={item}>
                        <XCircle size={15} className="ov-tick no" /> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* stay summary */}
          {(hotel || stayInclusion) && (
            <div className="ov-card">
              <h2 className="ov-card-title">
                <BedDouble size={17} /> Your stay
              </h2>

              {hotel ? (
                <>
                  <div className="ov-stay-row">
                    {hotel.image && (
                      <div
                        className="ov-stay-icon ov-stay-photo"
                        style={{ backgroundImage: `url(${hotel.image})` }}
                      />
                    )}
                    <div>
                      <div className="ov-stay-title">{hotel.name}</div>
                      <div className="ov-stay-sub">
                        {hotel.roomName} · {hotel.location}
                      </div>
                    </div>
                  </div>

                  <div className="ov-stay-breakdown">
                    <div className="ov-stay-row-line">
                      <span>
                        ₹{hotel.pricePerNight.toLocaleString("en-IN")} × {hotel.nights} nights ×{" "}
                        {hotel.roomsCount} room{hotel.roomsCount > 1 ? "s" : ""}
                      </span>
                      <span>₹{hotel.roomTotal.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="ov-stay-row-line">
                      <span>Taxes & fees</span>
                      <span>₹{hotel.taxes.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="ov-stay-row-line total">
                      <span>Stay total</span>
                      <span>₹{hotel.grandTotal.toLocaleString("en-IN")}</span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="ov-stay-row">
                  <div className="ov-stay-icon">
                    <BedDouble size={20} />
                  </div>
                  <div>
                    <div className="ov-stay-title">{stayInclusion}</div>
                    <div className="ov-stay-sub">Included in your {pkg.package_name} package</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* transport (cab / bus) — optional */}
          <div className="ov-card">
            <h2 className="ov-card-title">
              {isCab ? <Car size={17} /> : <BusIcon size={17} />} Your transport
            </h2>

            {transport ? (
              <>
                <div className="ov-flight-summary">
                  <div>
                    <div className="ov-flight-airline">{isCab ? transport.provider : transport.operator}</div>
                    <div className="ov-flight-num">{isCab ? transport.vehicleType : transport.busType}</div>
                  </div>
                  <span className="ov-flight-price">₹{transport.price.toLocaleString("en-IN")}</span>
                </div>

                {isCab ? (
                  <div className="ov-flight-meta-row" style={{ marginTop: 10 }}>
                    <span>
                      <Clock size={13} style={{ verticalAlign: "-2px", marginRight: 4 }} />
                      Pickup in {transport.etaMins} mins
                    </span>
                    <span className="ov-flight-cabin">
                      {transport.duration} trip
                      {transport.dayCount > 1 ? ` · ${transport.dayCount} days` : ""}
                    </span>
                  </div>
                ) : (
                  <div className="ov-flight-route">
                    <div className="ov-flight-time">
                      <div className="ov-flight-time-val">{transport.departTime}</div>
                      <div className="ov-flight-time-code">{transport.boardingPoint}</div>
                    </div>
                    <div className="ov-flight-mid">
                      <div className="ov-flight-mid-line" />
                      <div className="ov-flight-mid-meta">{transport.duration}</div>
                    </div>
                    <div className="ov-flight-time">
                      <div className="ov-flight-time-val">{transport.arriveTime}</div>
                      <div className="ov-flight-time-code">{transport.destinationCity}</div>
                    </div>
                  </div>
                )}

                <div className="ov-flight-meta-row">
                  {fromDate && (
                    <span>
                      <CalendarDays size={13} style={{ verticalAlign: "-2px", marginRight: 4 }} />
                      {fromDate}
                      {toDate ? ` – ${toDate}` : ""}
                    </span>
                  )}
                  <span className="ov-flight-cabin">{transport.amenities?.join(" · ")}</span>
                </div>

                <div style={{ marginTop: 12 }}>
                  <button
                    className="ov-link-btn"
                    onClick={() => navigate("/transports", { state: { hotel } })}
                  >
                    Change transport
                  </button>
                </div>
              </>
            ) : (
              <div className="ov-empty-flight">
                No transport selected yet — this is optional.{" "}
                <button
                  className="ov-link-btn"
                  onClick={() => navigate("/transports", { state: { hotel } })}
                >
                  Choose a cab or bus
                </button>
              </div>
            )}
          </div>
        </div>

        {/* ---------------- RIGHT: PRICE SUMMARY ---------------- */}
        <div className="ov-summary">
          <h2 className="ov-summary-title">
            <BadgeCheck size={18} /> Price summary
          </h2>

          <div className="ov-summary-row">
            <span>Package ({pkg.duration})</span>
            <span>₹{packagePrice.toLocaleString("en-IN")}</span>
          </div>
          <div className="ov-summary-row">
            <span>Hotel {hotel ? `(${hotel.nights}N)` : ""}</span>
            <span>{hotel ? `₹${hotelPrice.toLocaleString("en-IN")}` : "—"}</span>
          </div>
          <div className="ov-summary-row">
            <span>Transport</span>
            <span>{transport ? `₹${transportPrice.toLocaleString("en-IN")}` : "—"}</span>
          </div>
          <div className="ov-summary-total">
            <span>Total</span>
            <span>₹{total.toLocaleString("en-IN")}</span>
          </div>
          <p className="ov-summary-note">Taxes and fees included where applicable. Transport is optional.</p>

          <button
            className="ov-btn-accent"
            onClick={() =>
              navigate(`/register_booking/${pkg.id}`, {
                state: { pkg, transport, hotel, pickupPoint, fromDate, toDate, total },
              })
            }
          >
            Proceed to booking
          </button>
        </div>
      </div>
    </div>
  );
}