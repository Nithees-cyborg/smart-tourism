import React, { useMemo, useState } from "react";
import HotelNavbar from "../components/HotelNavbar";
import HotelHero from "../components/HotelHero";
import HotelControls from "../components/HotelControls";
import HotelGrid from "../components/HotelGrid";
import HotelModal from "../components/HotelModal";
import HotelFooter from "../components/HotelFooter";
import HotelsData from "../components/HotelsData";
import "../components/Hotels.css";

export default function Hotels() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState("");
  const [priceFilter, setPriceFilter] = useState("");
  const [selectedHotel, setSelectedHotel] = useState(null);

  const visibleHotels = useMemo(() => {
    let result = HotelsData.filter((hotel) => {
      const query = searchTerm.trim().toLowerCase();
      const matchesQuery =
        !query ||
        hotel.name.toLowerCase().includes(query) ||
        hotel.location.toLowerCase().includes(query);

      const matchesPrice =
        !priceFilter ||
        (priceFilter === "budget" && hotel.price <= 8000) ||
        (priceFilter === "luxury" && hotel.price > 8000);

      return matchesQuery && matchesPrice;
    });

    if (sortOrder === "high") {
      result = [...result].sort((a, b) => b.rating - a.rating);
    } else if (sortOrder === "low") {
      result = [...result].sort((a, b) => a.rating - b.rating);
    }

    return result;
  }, [searchTerm, sortOrder, priceFilter]);

  return (
    <>
      <HotelNavbar />
      <HotelHero total={HotelsData.length} />

      <div className="page-container">
        <div className="section-heading">
          <h2>Explore the Collection</h2>
          <p>Search, sort, and filter all {HotelsData.length} properties below.</p>
        </div>

        <HotelControls
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          sortOrder={sortOrder}
          onSortChange={setSortOrder}
          priceFilter={priceFilter}
          onPriceChange={setPriceFilter}
        />

        <HotelGrid hotels={visibleHotels} onSelectHotel={setSelectedHotel} />
      </div>

      <HotelFooter />

      <HotelModal hotel={selectedHotel} onClose={() => setSelectedHotel(null)} />
    </>
  );
}