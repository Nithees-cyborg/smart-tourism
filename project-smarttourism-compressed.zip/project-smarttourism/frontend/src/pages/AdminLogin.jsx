import { useEffect } from "react";

export default function AdminLogin() {
  useEffect(() => {
    window.location.href = "http://127.0.0.1:8000/admin/";
  }, []);

  return (
    <div
      style={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "22px",
        fontWeight: "600",
      }}
    >
      Redirecting to Django Admin...
    </div>
  );
}